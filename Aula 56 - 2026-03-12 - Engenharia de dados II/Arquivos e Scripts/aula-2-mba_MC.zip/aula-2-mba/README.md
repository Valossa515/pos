# Lakehouse (Delta Lake, Hive e Trino)

Nesta aula, vamos simular uma arquitetura completa de um Lakehouse focado na gestão do estoque de uma loja de tênis.

## Arquitetura
- **Storage (MinIO)**: Funciona como o nosso S3 local (Object Store). Onde os arquivos físicos (.parquet formam as tabelas Delta) serão guardados.
- **Catálogo de Dados (Hive Metastore com Postgres)**: Guarda os metadados. Ele serve como o mapa do nosso Lakehouse, sabendo onde estão os arquivos no MinIO e que colunas cada tabela tem.
- **Processing (Jupyter Notebook / Apache Spark)**: Motor de ingestão e transformação. Ele vai ler arquivos brutos (CSV, JSON, Parquet) que chegam na pasta `raw_data`, tratar e enviar para o MinIO formato Delta, registrando na tabela do Hive.
- **Engine de Consulta (Trino)**: Um motor SQL massivamente paralelo, configurado para conectar no Hive Metastore, descobrir as tabelas e consultar diretamente no MinIO a camada Delta com extrema velocidade.

## Pré-requisitos
- Docker e Docker Compose instalados.

## 🚀 Como Executar a Aula

### 1. Subir a Infraestrutura
Abra seu terminal na pasta do projeto e execute:
```bash
docker compose up -d
```
*Aguarde alguns minutos para que todos os serviços fiquem de pé. O Hive Metastore iniciará seu banco de dados e o script do MinIO criará os "buckets" virtuais.*

### 2. Acessar o Jupyter Lab (Spark)
O Spark rodará junto com o Jupyter na porta 8888. Como removemos o token, basta acessar pelo navegador:
👉 [http://localhost:8888](http://localhost:8888)

### 3. Execução dos Notebooks Didáticos
Na interface do Jupyter, acesse a pasta `workspace` e rode os notebooks na sequência:
- **`01_gerar_dados.ipynb`**: Execute-o para criar os arquivos `CSV` (Nike), `JSON` (Adidas) e `Parquet` (Puma) que simulam os sistemas legado da loja de tênis.

- **`02_carga_delta.ipynb`**: Execute célula a célula, lendo os comentários. Ele mostrará o Spark unindo os dados e enviando tudo no formato `Delta` para nosso Object Store, catalogando no Hive Metastore.

- **`03_query_trino.ipynb`**: Um notebook extra para conectar usando a API do Trino (Python) e realizar queries ultravelozes diretamente da tabela Delta.

### 4. Consultar o Trino via Terminal (Opcional)
Você pode usar a CLI do próprio Trino que está rodando no Docker para fazer selects:
```bash
docker exec -it lakehouse-trino trino --catalog delta --schema loja_tenis

# Exemplo de consulta dentro do console do trino:
# trino:loja_tenis> SELECT * FROM estoque WHERE quantidade < 10;
```

### 5. Verificar o MinIO (Acesso Visual)
Acesse a interface visual do MinIO pelo navegador para ver seus arquivos físicos do Lakehouse e o delta log:
👉 [http://localhost:9001](http://localhost:9001)  
- **Usuário:** admin  
- **Senha:** password  

---
**Desligando o ambiente:** `docker compose down`
