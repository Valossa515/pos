import json
import os

def create_notebook(filename, cells):
    nb = {
        "cells": [],
        "metadata": {
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3"
            }
        },
        "nbformat": 4,
        "nbformat_minor": 4
    }
    
    for c_type, source in cells:
        if c_type == "markdown":
            nb["cells"].append({
                "cell_type": "markdown",
                "metadata": {},
                "source": [line + "\n" for line in source.split("\n")]
            })
        else:
            nb["cells"].append({
                "cell_type": "code",
                "execution_count": None,
                "metadata": {},
                "outputs": [],
                "source": [line + "\n" for line in source.split("\n")]
            })
            
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(nb, f, indent=1)

# Notebook 1: Gerar Dados
cells_1 = [
    ("markdown", "# Passo 1: Gerar Dados Fictícios do Estoque\nNesta aula, vamos simular que somos uma loja de tênis e recebemos dados de estoque de 3 fornecedoras diferentes em formatos diferentes:\n- **Nike**: CSV\n- **Adidas**: JSON\n- **Puma**: Parquet\n\nVamos usar a biblioteca Pandas para gerar esses arquivos localmente na pasta `raw_data`."),
    ("code", "import pandas as pd\nimport os\nimport numpy as np\n\n# Criar diretório\nos.makedirs('./raw_data', exist_ok=True)\n\n# 1. Dados da Nike (CSV)\nnike_data = pd.DataFrame({\n    'marca': ['Nike'] * 5,\n    'modelo': ['Air Max', 'Air Force 1', 'Jordan 1', 'Pegasus', 'Dunk'],\n    'tamanho': [40, 41, 42, 39, 43],\n    'quantidade': [10, 15, 5, 20, 8],\n    'preco': [500.0, 600.0, 1200.0, 450.0, 800.0]\n})\nnike_data.to_csv('./raw_data/nike_estoque.csv', index=False)\nprint('Arquivo CSV da Nike gerado com sucesso!')"),
    ("code", "# 2. Dados da Adidas (JSON)\nadidas_data = pd.DataFrame({\n    'marca': ['Adidas'] * 5,\n    'modelo': ['Ultraboost', 'NMD', 'Superstar', 'Stan Smith', 'Yeezy'],\n    'tamanho': [41, 40, 39, 42, 41],\n    'quantidade': [12, 8, 30, 25, 3],\n    'preco': [800.0, 700.0, 350.0, 400.0, 1500.0]\n})\nadidas_data.to_json('./raw_data/adidas_estoque.json', orient='records', lines=True)\nprint('Arquivo JSON da Adidas gerado com sucesso!')"),
    ("code", "# 3. Dados da Puma (Parquet)\npuma_data = pd.DataFrame({\n    'marca': ['Puma'] * 5,\n    'modelo': ['Suede', 'RS-X', 'Cali', 'Future Rider', 'Mayze'],\n    'tamanho': [39, 42, 38, 41, 40],\n    'quantidade': [18, 10, 22, 14, 20],\n    'preco': [300.0, 450.0, 380.0, 420.0, 500.0]\n})\npuma_data.to_parquet('./raw_data/puma_estoque.parquet', index=False)\nprint('Arquivo Parquet da Puma gerado com sucesso!')\nprint('Todos os dados foram gerados em ./raw_data/')")
]

# Notebook 2: Carga Delta Lake
cells_2 = [
    ("markdown", "# Passo 2: Construir o Lakehouse (Ingestão para Delta Lake)\nNeste notebook, vamos:\n1. Iniciar o Spark configurado com as bibliotecas do Delta Lake, integração com MinIO (S3) e Hive Metastore.\n2. Ler os arquivos CSV, JSON e Parquet gerados anteriormente.\n3. Unificar todos esses dados de estoque.\n4. Salvar tudo no nosso Object Store (MinIO) no formato Delta e registrar no Data Catalog (Hive Metastore)."),
    ("code", "from pyspark.sql import SparkSession\nfrom delta import *\n\n# Vamos configurar o Spark Session explicando cada parte:\n# 1. Pacotes do Delta Spark e AWS (para ler/escrever no S3/MinIO)\n# 2. Configurações de catalogação apontando para o DeltaCatalog\n# 3. Credenciais do MinIO\n# 4. URI do Hive Metastore\n\nbuilder = SparkSession.builder.appName('Lakehouse-Aula') \\\n    .config('spark.sql.extensions', 'io.delta.sql.DeltaSparkSessionExtension') \\\n    .config('spark.sql.catalog.spark_catalog', 'org.apache.spark.sql.delta.catalog.DeltaCatalog') \\\n    .config('spark.hadoop.fs.s3a.endpoint', 'http://minio:9000') \\\n    .config('spark.hadoop.fs.s3a.access.key', 'admin') \\\n    .config('spark.hadoop.fs.s3a.secret.key', 'password') \\\n    .config('spark.hadoop.fs.s3a.path.style.access', 'true') \\\n    .config('spark.hadoop.fs.s3a.impl', 'org.apache.hadoop.fs.s3a.S3AFileSystem') \\\n    .config('spark.hadoop.fs.s3a.connection.ssl.enabled', 'false') \\\n    .config('spark.sql.warehouse.dir', 's3a://lakehouse/warehouse') \\\n    .config('hive.metastore.uris', 'thrift://hive-metastore:9083') \\\n    .config('spark.sql.catalogImplementation', 'hive')\n\n# delta_spark.configure_spark_with_delta_pip embute as dependências do delta no nosso builder\nspark = configure_spark_with_delta_pip(builder, extra_packages=['org.apache.hadoop:hadoop-aws:3.3.4,com.amazonaws:aws-java-sdk-bundle:1.12.262']).enableHiveSupport().getOrCreate()\n\nprint('Spark Session iniciada com sucesso!')"),
    ("code", "# Agora vamos ler cada fonte de dados usando o Spark\ndf_nike = spark.read.csv('./raw_data/nike_estoque.csv', header=True, inferSchema=True)\ndf_adidas = spark.read.json('./raw_data/adidas_estoque.json')\ndf_puma = spark.read.parquet('./raw_data/puma_estoque.parquet')\n\nprint('Leitura concluída:')\ndf_nike.show(2)"),
    ("code", "# Vamos unificar os dataframes usando unionByName (útil caso as colunas estivessem em ordens diferentes)\ndf_estoque = df_nike.unionByName(df_adidas).unionByName(df_puma)\n\nprint('Estoque unificado!')\ndf_estoque.show(15)"),
    ("code", "# Cria o banco de dados (schema) no Hive Metastore caso não exista\nspark.sql('CREATE DATABASE IF NOT EXISTS loja_tenis')\nspark.sql('USE loja_tenis')\n\n# Salvar no formato Delta Lake no MinIO e registrar a tabela no Hive\nprint('Iniciando a carga para o Delta Lake (MinIO)...')\n\n# O comando saveAsTable já escreve os arquivos de dados (parquet + log delta)\n# no warehouse.dir configurado (s3a://lakehouse/warehouse/loja_tenis.db/estoque)\n# E avisa o Hive Metastore que a tabela 'estoque' existe!\n\ndf_estoque.write.format('delta') \\\n    .mode('overwrite') \\\n    .saveAsTable('loja_tenis.estoque')\n\nprint('Tabela Delta salva com sucesso!')"),
    ("code", "# Exibindo o catálogo do Hive para ver que a tabela está lá e que o spark a reconhece!\nprint('Tabelas no Catálogo Hive:')\nspark.sql('SHOW TABLES IN loja_tenis').show(truncate=False)\n\nprint('Consultando usando SQL puro:')\nspark.sql('SELECT marca, sum(quantidade) as total_pares FROM loja_tenis.estoque GROUP BY marca').show()")
]

# Notebook 3: Query Trino
cells_3 = [
    ("markdown", "# Passo 3: Consultando com a Engine Trino\nO Trino é um motor de query distribuído de alta performance. Ele está conectado ao nosso Hive Metastore e ao MinIO.\nVocê pode rodar queries pelo terminal: `docker exec -it lakehouse-trino trino`\n\nOu conectar via Python usando a biblioteca oficial do Trino."),
    ("code", "import trino\nimport pandas as pd\n\n# Conectando no Trino que está exposto na porta 8080\n# User pode ser qualquer nome no Trino auth padrão\n# Catalog: 'delta' (foi o que configuramos)\n# Schema: 'loja_tenis'\n\nconn = trino.dbapi.connect(\n    host='lakehouse-trino',\n    port=8080,\n    user='aluno',\n    catalog='delta',\n    schema='loja_tenis',\n)\n\ncur = conn.cursor()\n\n# Mágica: O trino pede ao Hive Metastore os dados da tabela, \n# ele diz que estão no s3a://lakehouse/warehouse/loja_tenis.db/estoque\n# O trino vai no Minio e processa os dados Delta ultra rápido.\ncur.execute('SELECT marca, modelo, tamanho, quantidade FROM estoque ORDER BY quantidade DESC LIMIT 5')\n\nrows = cur.fetchall()\ndf_resultado = pd.DataFrame(rows, columns=['marca', 'modelo', 'tamanho', 'quantidade'])\n\ndf_resultado")
]

create_notebook("/Users/guilhermelima/Desktop/aula-2-mba/workspace/01_gerar_dados.ipynb", cells_1)
create_notebook("/Users/guilhermelima/Desktop/aula-2-mba/workspace/02_carga_delta.ipynb", cells_2)
create_notebook("/Users/guilhermelima/Desktop/aula-2-mba/workspace/03_query_trino.ipynb", cells_3)

print("Notebooks criados com sucesso!")
