from domain.__seedwork.use_case_interface import UseCaseInterface
from domain.cliente.cliente_repository_interface import ClienteRepositoryInterface
from application.cliente.listar_clientes.listar_clientes_dto import (
    ListarClientesOutputDto,
    ClienteOutputDto,
)


class ListarClientesUseCase(UseCaseInterface):

    def __init__(self, cliente_repository: ClienteRepositoryInterface):
        self.cliente_repository = cliente_repository

    def executar(self, input: None = None) -> ListarClientesOutputDto:
        clientes = self.cliente_repository.listar_clientes()
        return ListarClientesOutputDto(
            clientes=[
                ClienteOutputDto(
                    id=c.id, nome=c.nome, email=c.email.valor, ativo=c.ativo
                )
                for c in clientes
            ]
        )
