from domain.__seedwork.use_case_interface import UseCaseInterface
from domain.cliente.cliente_repository_interface import ClienteRepositoryInterface
from application.cliente.excluir_cliente.excluir_cliente_dto import (
    ExcluirClienteInputDto,
    ExcluirClienteOutputDto,
)


class ExcluirClienteUseCase(UseCaseInterface):

    def __init__(self, cliente_repository: ClienteRepositoryInterface):
        self.cliente_repository = cliente_repository

    def executar(self, input: ExcluirClienteInputDto) -> ExcluirClienteOutputDto:
        cliente = self.cliente_repository.encontrar_cliente(input.id)
        if not cliente:
            raise ValueError("Cliente não encontrado.")

        self.cliente_repository.excluir_cliente(input.id)
        return ExcluirClienteOutputDto(mensagem="Cliente excluído com sucesso.")
