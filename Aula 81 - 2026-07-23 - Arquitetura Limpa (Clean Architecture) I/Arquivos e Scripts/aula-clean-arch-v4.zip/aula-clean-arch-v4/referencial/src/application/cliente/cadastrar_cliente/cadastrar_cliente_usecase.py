import uuid
from domain.__seedwork.use_case_interface import UseCaseInterface
from domain.cliente.cliente_repository_interface import ClienteRepositoryInterface
from domain.cliente.cliente_entity import Cliente
from application.cliente.cadastrar_cliente.cadastrar_cliente_dto import (
    CadastrarClienteInputDto,
    CadastrarClienteOutputDto,
)
from domain.cliente.email_vo import Email


class CadastrarClienteUseCase(UseCaseInterface):

    def __init__(self, cliente_repository: ClienteRepositoryInterface):
        self.cliente_repository = cliente_repository

    def executar(self, input: CadastrarClienteInputDto) -> CadastrarClienteOutputDto:
        cliente = Cliente(id=uuid.uuid4(), nome=input.nome, email=Email(input.email))

        self.cliente_repository.cadastrar_cliente(cliente)

        return CadastrarClienteOutputDto(
            id=cliente.id,
            nome=cliente.nome,
            email=cliente.email.valor,
            ativo=cliente.ativo,
        )
