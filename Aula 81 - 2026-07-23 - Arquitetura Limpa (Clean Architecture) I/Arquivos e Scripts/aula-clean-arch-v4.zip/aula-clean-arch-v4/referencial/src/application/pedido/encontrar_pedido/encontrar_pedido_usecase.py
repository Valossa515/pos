from domain.__seedwork.use_case_interface import UseCaseInterface
from domain.pedido.pedido_repository_interface import PedidoRepositoryInterface
from application.pedido.encontrar_pedido.encontrar_pedido_dto import (
    EncontrarPedidoInputDto,
    EncontrarPedidoOutputDto,
    ItemPedidoOutputDto,
)


class EncontrarPedidoUseCase(UseCaseInterface):

    def __init__(self, pedido_repository: PedidoRepositoryInterface):
        self.pedido_repository = pedido_repository

    def executar(self, input: EncontrarPedidoInputDto) -> EncontrarPedidoOutputDto:
        pedido = self.pedido_repository.encontrar_pedido(input.id)
        if not pedido:
            raise ValueError("Pedido não encontrado.")

        itens_dto = [
            ItemPedidoOutputDto(
                produto_id=item.produto_id,
                preco_unitario=item.preco_unitario,
                quantidade=item.quantidade,
                total=item.calcular_total(),
            )
            for item in pedido.itens
        ]

        return EncontrarPedidoOutputDto(
            id=pedido.id,
            cliente_id=pedido.cliente_id,
            status=pedido.status.value,
            total=pedido.calcular_total(),
            criado_em=pedido.criado_em.strftime("%Y-%m-%d %H:%M:%S"),
            itens=itens_dto,
        )
