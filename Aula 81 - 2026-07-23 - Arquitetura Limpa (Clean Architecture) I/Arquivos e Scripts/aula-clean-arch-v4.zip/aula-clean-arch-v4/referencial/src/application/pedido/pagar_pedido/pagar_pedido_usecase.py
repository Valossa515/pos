from domain.__seedwork.use_case_interface import UseCaseInterface
from domain.pedido.pedido_repository_interface import PedidoRepositoryInterface
from domain.produto.produto_repository_interface import ProdutoRepositoryInterface
from application.pedido.pagar_pedido.pagar_pedido_dto import (
    PagarPedidoInputDto,
    PagarPedidoOutputDto,
)


class PagarPedidoUseCase(UseCaseInterface):

    def __init__(
        self,
        pedido_repository: PedidoRepositoryInterface,
        produto_repository: ProdutoRepositoryInterface,
    ):
        self.pedido_repository = pedido_repository
        self.produto_repository = produto_repository

    def executar(self, input: PagarPedidoInputDto) -> PagarPedidoOutputDto:
        pedido = self.pedido_repository.encontrar_pedido(input.pedido_id)
        if not pedido:
            raise ValueError("Pedido não encontrado.")

        pedido.pagar(valor_pago=input.valor_pago)

        for item in pedido.itens:
            produto = self.produto_repository.encontrar_produto(item.produto_id)
            if produto:
                produto.diminuir_estoque(item.quantidade)
                self.produto_repository.atualizar_produto(produto)

        self.pedido_repository.atualizar_pedido(pedido)

        return PagarPedidoOutputDto(
            pedido_id=pedido.id,
            status=pedido.status.value,
            total=pedido.calcular_total(),
        )
