import uuid
from domain.__seedwork.use_case_interface import UseCaseInterface
from domain.pedido.pedido_repository_interface import PedidoRepositoryInterface
from domain.cliente.cliente_repository_interface import ClienteRepositoryInterface
from domain.produto.produto_repository_interface import ProdutoRepositoryInterface
from domain.pedido.pedido_entity import Pedido
from domain.pedido.item_pedido_entity import ItemPedido
from application.pedido.criar_pedido.criar_pedido_dto import (
    CriarPedidoInputDto,
    CriarPedidoOutputDto,
    ItemPedidoOutputDto,
)


class CriarPedidoUseCase(UseCaseInterface):

    def __init__(
        self,
        pedido_repository: PedidoRepositoryInterface,
        cliente_repository: ClienteRepositoryInterface,
        produto_repository: ProdutoRepositoryInterface,
    ):
        self.pedido_repository = pedido_repository
        self.cliente_repository = cliente_repository
        self.produto_repository = produto_repository

    def executar(self, input: CriarPedidoInputDto) -> CriarPedidoOutputDto:
        cliente = self.cliente_repository.encontrar_cliente(input.cliente_id)
        if not cliente:
            raise ValueError("Cliente não encontrado.")
        if not cliente.ativo:
            raise ValueError("Clientes inativos não podem realizar novos pedidos.")

        pedido = Pedido(id=str(uuid.uuid4()), cliente_id=cliente.id)

        for item_dto in input.itens:
            produto = self.produto_repository.encontrar_produto(item_dto.produto_id)
            if not produto:
                raise ValueError(f"Produto '{item_dto.produto_id}' não foi encontrado.")

            item = ItemPedido(
                produto_id=produto.id,
                preco_unitario=produto.preco,
                quantidade=item_dto.quantidade,
            )
            pedido.adicionar_item(item)

        self.pedido_repository.criar_pedido(pedido)

        return CriarPedidoOutputDto(
            id=pedido.id,
            cliente_id=pedido.cliente_id,
            status=pedido.status.value,
            total=pedido.calcular_total(),
            itens=[
                ItemPedidoOutputDto(
                    produto_id=i.produto_id,
                    preco_unitario=i.preco_unitario,
                    quantidade=i.quantidade,
                    total=i.calcular_total(),
                )
                for i in pedido.itens
            ],
        )
