from uuid import UUID
from pydantic import BaseModel
from typing import List


class ItemPedidoInputDto(BaseModel):
    produto_id: UUID
    quantidade: int


class ItemPedidoOutputDto(BaseModel):
    produto_id: UUID
    preco_unitario: float
    quantidade: int
    total: float


class CriarPedidoInputDto(BaseModel):
    cliente_id: UUID
    itens: List[ItemPedidoInputDto]


class CriarPedidoOutputDto(BaseModel):
    id: UUID
    cliente_id: UUID
    status: str
    total: float
    itens: List[ItemPedidoOutputDto]
