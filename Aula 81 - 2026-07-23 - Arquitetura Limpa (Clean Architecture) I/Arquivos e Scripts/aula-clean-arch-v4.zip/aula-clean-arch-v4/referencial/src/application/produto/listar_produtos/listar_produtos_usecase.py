from domain.__seedwork.use_case_interface import UseCaseInterface
from domain.produto.produto_repository_interface import ProdutoRepositoryInterface
from application.produto.listar_produtos.listar_produtos_dto import (
    ListarProdutosInputDto,
    ListarProdutosOutputDto,
    ProdutoOutputDto,
)


class ListarProdutosUseCase(UseCaseInterface):

    def __init__(self, produto_repository: ProdutoRepositoryInterface):
        self.produto_repository = produto_repository

    def executar(self, input: ListarProdutosInputDto) -> ListarProdutosOutputDto:
        produtos = self.produto_repository.listar_produtos()
        return ListarProdutosOutputDto(
            produtos=[
                ProdutoOutputDto(
                    id=p.id,
                    nome=p.nome,
                    preco=p.preco,
                    quantidade_estoque=p.quantidade_estoque,
                )
                for p in produtos
            ]
        )
