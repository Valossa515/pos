from domain.__seedwork.use_case_interface import UseCaseInterface
from domain.produto.produto_repository_interface import ProdutoRepositoryInterface
from application.produto.encontrar_produto.encontrar_produto_dto import (
    EncontrarProdutoInputDto,
    EncontrarProdutoOutputDto,
)


class EncontrarProdutoUseCase(UseCaseInterface):

    def __init__(self, produto_repository: ProdutoRepositoryInterface):
        self.produto_repository = produto_repository

    def executar(self, input: EncontrarProdutoInputDto) -> EncontrarProdutoOutputDto:
        produto = self.produto_repository.encontrar_produto(input.id)
        if not produto:
            raise ValueError("Produto não encontrado.")

        return EncontrarProdutoOutputDto(
            id=produto.id,
            nome=produto.nome,
            preco=produto.preco,
            quantidade_estoque=produto.quantidade_estoque,
        )
