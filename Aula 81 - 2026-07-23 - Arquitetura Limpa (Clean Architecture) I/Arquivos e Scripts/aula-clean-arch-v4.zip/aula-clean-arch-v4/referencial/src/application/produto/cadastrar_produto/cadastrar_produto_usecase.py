import uuid
from domain.__seedwork.use_case_interface import UseCaseInterface
from domain.produto.produto_repository_interface import ProdutoRepositoryInterface
from domain.produto.produto_entity import Produto
from application.produto.cadastrar_produto.cadastrar_produto_dto import (
    CadastrarProdutoInputDto,
    CadastrarProdutoOutputDto,
)


class CadastrarProdutoUseCase(UseCaseInterface):

    def __init__(self, produto_repository: ProdutoRepositoryInterface):
        self.produto_repository = produto_repository

    def executar(self, input: CadastrarProdutoInputDto) -> CadastrarProdutoOutputDto:
        produto = Produto(
            id=uuid.uuid4(),
            nome=input.nome,
            preco=input.preco,
            quantidade_estoque=input.quantidade_estoque,
        )

        self.produto_repository.cadastrar_produto(produto)

        return CadastrarProdutoOutputDto(
            id=produto.id,
            nome=produto.nome,
            preco=produto.preco,
            quantidade_estoque=produto.quantidade_estoque,
        )
