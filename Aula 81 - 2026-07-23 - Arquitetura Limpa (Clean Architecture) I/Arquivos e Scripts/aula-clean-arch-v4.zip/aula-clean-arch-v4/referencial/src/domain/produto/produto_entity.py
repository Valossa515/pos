from dataclasses import dataclass
from uuid import UUID


@dataclass
class Produto:
    id: UUID
    nome: str
    preco: float
    quantidade_estoque: int

    def __post_init__(self):
        self.validar()

    def validar(self):
        if not self.nome:
            raise ValueError("O nome do produto é obrigatório.")
        if self.preco <= 0:
            raise ValueError("O preço do produto deve ser maior que zero.")
        if self.quantidade_estoque < 0:
            raise ValueError("A quantidade em estoque não pode ser negativa.")

    def diminuir_estoque(self, quantidade: int) -> None:
        if quantidade <= 0:
            raise ValueError("A quantidade a ser removida deve ser maior que zero.")
        if self.quantidade_estoque < quantidade:
            raise ValueError("Estoque insuficiente para essa operação.")
        self.quantidade_estoque -= quantidade

    def aumentar_estoque(self, quantidade: int) -> None:
        if quantidade <= 0:
            raise ValueError("A quantidade a ser adicionada deve ser maior que zero.")
        self.quantidade_estoque += quantidade
