from abc import ABC, abstractmethod
from typing import List, Optional
from domain.pedido.pedido_entity import Pedido


class PedidoRepositoryInterface(ABC):

    @abstractmethod
    def criar_pedido(self, pedido: Pedido) -> None:
        raise NotImplementedError

    @abstractmethod
    def encontrar_pedido(self, pedido_id: str) -> Optional[Pedido]:
        raise NotImplementedError

    @abstractmethod
    def listar_pedidos(self) -> List[Pedido]:
        raise NotImplementedError

    @abstractmethod
    def listar_pedidos_por_cliente(self, cliente_id: str) -> List[Pedido]:
        raise NotImplementedError

    @abstractmethod
    def atualizar_pedido(self, pedido: Pedido) -> None:
        raise NotImplementedError
