from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import List
from uuid import UUID
from domain.pedido.item_pedido_entity import ItemPedido


class StatusPedido(Enum):
    PENDENTE = "PENDENTE"
    PAGO = "PAGO"
    CANCELADO = "CANCELADO"


@dataclass
class Pedido:
    id: UUID
    cliente_id: UUID
    itens: List[ItemPedido] = field(default_factory=list)
    status: StatusPedido = StatusPedido.PENDENTE
    criado_em: datetime = field(default_factory=datetime.now)

    def __post_init__(self):
        self.validar()

    def validar(self):
        if not self.id:
            raise ValueError("O ID do pedido é obrigatório.")
        if not self.cliente_id:
            raise ValueError("O ID do cliente é obrigatório.")

    def adicionar_item(self, novo_item: ItemPedido) -> None:
        if self.status != StatusPedido.PENDENTE:
            raise ValueError(
                "Não é possível adicionar itens a um pedido que não está pendente."
            )

        for item in self.itens:
            if item.produto_id == novo_item.produto_id:
                item.quantidade += novo_item.quantidade
                return

        self.itens.append(novo_item)

    def remover_item(self, produto_id: str) -> None:
        if self.status != StatusPedido.PENDENTE:
            raise ValueError(
                "Não é possível remover itens de um pedido que não está pendente."
            )

        item_para_remover = None
        for item in self.itens:
            if item.produto_id == produto_id:
                item_para_remover = item
                break

        if not item_para_remover:
            raise ValueError(
                f"Item com o produto_id '{produto_id}' não encontrado no pedido."
            )

        self.itens.remove(item_para_remover)

    def calcular_total(self) -> float:
        return sum(item.calcular_total() for item in self.itens)

    def pagar(self, valor_pago: float) -> None:
        if not self.itens:
            raise ValueError("Não é possível pagar um pedido que não possui itens.")
        if self.status == StatusPedido.CANCELADO:
            raise ValueError("Não é possível pagar um pedido cancelado.")
        if self.status == StatusPedido.PAGO:
            raise ValueError("O pedido já está pago.")

        # Validando o valor pago contra o total do pedido
        total_pedido = self.calcular_total()
        if valor_pago < total_pedido:
            raise ValueError(
                f"Valor pago (R$ {valor_pago:.2f}) é insuficiente. "
                f"O total do pedido é R$ {total_pedido:.2f}."
            )

        self.status = StatusPedido.PAGO

    def cancelar(self) -> None:
        if self.status == StatusPedido.PAGO:
            raise ValueError("Não é possível cancelar um pedido já pago.")
        self.status = StatusPedido.CANCELADO
