from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from infra.api.database import obter_sessao

from infra.produto.sqlalchemy.produto_repository import ProdutoRepositorySQLAlchemy

from application.produto.cadastrar_produto.cadastrar_produto_dto import (
    CadastrarProdutoInputDto,
)
from application.produto.cadastrar_produto.cadastrar_produto_usecase import (
    CadastrarProdutoUseCase,
)
from application.produto.encontrar_produto.encontrar_produto_dto import (
    EncontrarProdutoInputDto,
)
from application.produto.encontrar_produto.encontrar_produto_usecase import (
    EncontrarProdutoUseCase,
)
from application.produto.listar_produtos.listar_produtos_dto import (
    ListarProdutosInputDto,
)
from application.produto.listar_produtos.listar_produtos_usecase import (
    ListarProdutosUseCase,
)
from application.produto.atualizar_produto.atualizar_produto_dto import (
    AtualizarProdutoInputDto,
)
from application.produto.atualizar_produto.atualizar_produto_usecase import (
    AtualizarProdutoUseCase,
)
from application.produto.excluir_produto.excluir_produto_dto import (
    ExcluirProdutoInputDto,
)
from application.produto.excluir_produto.excluir_produto_usecase import (
    ExcluirProdutoUseCase,
)

router = APIRouter(prefix="/produtos", tags=["Produtos"])


@router.post("/", status_code=201)
def cadastrar_produto(
    request: CadastrarProdutoInputDto, session: Session = Depends(obter_sessao)
):
    try:
        repository = ProdutoRepositorySQLAlchemy(session=session)
        usecase = CadastrarProdutoUseCase(produto_repository=repository)
        return usecase.executar(input=request)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/{produto_id}")
def encontrar_produto(produto_id: str, session: Session = Depends(obter_sessao)):
    try:
        repository = ProdutoRepositorySQLAlchemy(session=session)
        usecase = EncontrarProdutoUseCase(produto_repository=repository)
        return usecase.executar(input=EncontrarProdutoInputDto(id=produto_id))
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/")
def listar_produtos(session: Session = Depends(obter_sessao)):
    try:
        repository = ProdutoRepositorySQLAlchemy(session=session)
        usecase = ListarProdutosUseCase(produto_repository=repository)
        return usecase.executar(ListarProdutosInputDto())
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.put("/{produto_id}")
def atualizar_produto(
    produto_id: str,
    request: CadastrarProdutoInputDto,
    session: Session = Depends(obter_sessao),
):
    try:
        repository = ProdutoRepositorySQLAlchemy(session=session)
        usecase = AtualizarProdutoUseCase(produto_repository=repository)
        input_dto = AtualizarProdutoInputDto(
            id=produto_id,
            nome=request.nome,
            preco=request.preco,
            quantidade_estoque=request.quantidade_estoque,
        )
        return usecase.executar(input=input_dto)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.delete("/{produto_id}")
def excluir_produto(produto_id: str, session: Session = Depends(obter_sessao)):
    try:
        repository = ProdutoRepositorySQLAlchemy(session=session)
        usecase = ExcluirProdutoUseCase(produto_repository=repository)
        return usecase.executar(input=ExcluirProdutoInputDto(id=produto_id))
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
