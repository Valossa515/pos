import xml.etree.ElementTree as ET

from application.cliente.encontrar_cliente.encontrar_cliente_dto import (
    EncontrarClienteOutputDto,
)


class ClientePresenter:

    @staticmethod
    def toJSON(cliente: EncontrarClienteOutputDto) -> dict:
        return {
            "id": str(cliente.id),
            "nome": cliente.nome,
            "email": cliente.email,
            "ativo": cliente.ativo,
        }

    @staticmethod
    def toXML(cliente: EncontrarClienteOutputDto) -> str:
        cliente_data = ET.Element("cliente")
        ET.SubElement(cliente_data, "id").text = str(cliente.id)
        ET.SubElement(cliente_data, "nome").text = cliente.nome
        ET.SubElement(cliente_data, "email").text = cliente.email
        ET.SubElement(cliente_data, "ativo").text = str(cliente.ativo).lower()

        return ET.tostring(cliente_data, encoding="unicode")
