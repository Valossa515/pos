from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from infra.api.database import obter_sessao


from infra.api.presenters.clienter_presenter import ClientePresenter
from infra.cliente.sqlalchemy.cliente_repository import ClienteRepositorySQLAlchemy

from application.cliente.cadastrar_cliente.cadastrar_cliente_dto import (
    CadastrarClienteInputDto,
)
from application.cliente.cadastrar_cliente.cadastrar_cliente_usecase import (
    CadastrarClienteUseCase,
)
from application.cliente.encontrar_cliente.encontrar_cliente_dto import (
    EncontrarClienteInputDto,
)
from application.cliente.encontrar_cliente.encontrar_cliente_usecase import (
    EncontrarClienteUseCase,
)
from application.cliente.listar_clientes.listar_clientes_usecase import (
    ListarClientesUseCase,
)
from application.cliente.atualizar_cliente.atualizar_cliente_dto import (
    AtualizarClienteInputDto,
)
from application.cliente.atualizar_cliente.atualizar_cliente_usecase import (
    AtualizarClienteUseCase,
)
from application.cliente.excluir_cliente.excluir_cliente_dto import (
    ExcluirClienteInputDto,
)
from application.cliente.excluir_cliente.excluir_cliente_usecase import (
    ExcluirClienteUseCase,
)

router = APIRouter(prefix="/clientes", tags=["Clientes"])


@router.post("/", status_code=201)
def cadastrar_cliente(
    request: CadastrarClienteInputDto, session: Session = Depends(obter_sessao)
):
    try:
        repository = ClienteRepositorySQLAlchemy(session=session)
        usecase = CadastrarClienteUseCase(cliente_repository=repository)
        return usecase.executar(input=request)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/{cliente_id}")
def encontrar_cliente(cliente_id: str, session: Session = Depends(obter_sessao)):
    try:
        repository = ClienteRepositorySQLAlchemy(session=session)
        usecase = EncontrarClienteUseCase(cliente_repository=repository)
        output = usecase.executar(input=EncontrarClienteInputDto(id=cliente_id))

        output_xml = ClientePresenter.toXML(output)
        output_json = ClientePresenter.toJSON(output)

        return {"json": output_json, "xml": output_xml}

    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/")
def listar_clientes(session: Session = Depends(obter_sessao)):
    try:
        repository = ClienteRepositorySQLAlchemy(session=session)
        usecase = ListarClientesUseCase(cliente_repository=repository)
        return usecase.executar()
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.put("/{cliente_id}")
def atualizar_cliente(
    cliente_id: str,
    request: CadastrarClienteInputDto,
    session: Session = Depends(obter_sessao),
):
    try:
        repository = ClienteRepositorySQLAlchemy(session=session)
        usecase = AtualizarClienteUseCase(cliente_repository=repository)
        input_dto = AtualizarClienteInputDto(
            id=cliente_id, nome=request.nome, email=request.email
        )
        return usecase.executar(input=input_dto)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.delete("/{cliente_id}")
def excluir_cliente(cliente_id: str, session: Session = Depends(obter_sessao)):
    try:
        repository = ClienteRepositorySQLAlchemy(session=session)
        usecase = ExcluirClienteUseCase(cliente_repository=repository)
        return usecase.executar(input=ExcluirClienteInputDto(id=cliente_id))
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
