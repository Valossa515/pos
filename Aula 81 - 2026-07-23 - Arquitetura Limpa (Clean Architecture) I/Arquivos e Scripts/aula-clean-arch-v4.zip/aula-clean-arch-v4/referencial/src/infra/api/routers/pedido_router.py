from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from infra.api.database import obter_sessao

from infra.pedido.sqlalchemy.pedido_repository import PedidoRepositorySQLAlchemy
from infra.cliente.sqlalchemy.cliente_repository import ClienteRepositorySQLAlchemy
from infra.produto.sqlalchemy.produto_repository import ProdutoRepositorySQLAlchemy

from application.pedido.criar_pedido.criar_pedido_dto import CriarPedidoInputDto
from application.pedido.criar_pedido.criar_pedido_usecase import CriarPedidoUseCase
from application.pedido.encontrar_pedido.encontrar_pedido_dto import (
    EncontrarPedidoInputDto,
)
from application.pedido.encontrar_pedido.encontrar_pedido_usecase import (
    EncontrarPedidoUseCase,
)
from application.pedido.pagar_pedido.pagar_pedido_dto import PagarPedidoInputDto
from application.pedido.pagar_pedido.pagar_pedido_usecase import PagarPedidoUseCase
from application.pedido.cancelar_pedido.cancelar_pedido_dto import (
    CancelarPedidoInputDto,
)
from application.pedido.cancelar_pedido.cancelar_pedido_usecase import (
    CancelarPedidoUseCase,
)

router = APIRouter(prefix="/pedidos", tags=["Pedidos"])


@router.post("/", status_code=201)
def criar_pedido(
    request: CriarPedidoInputDto, session: Session = Depends(obter_sessao)
):
    try:
        pedido_repository = PedidoRepositorySQLAlchemy(session=session)
        cliente_repository = ClienteRepositorySQLAlchemy(session=session)
        produto_repository = ProdutoRepositorySQLAlchemy(session=session)

        usecase = CriarPedidoUseCase(
            pedido_repository=pedido_repository,
            cliente_repository=cliente_repository,
            produto_repository=produto_repository,
        )
        return usecase.executar(input=request)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/{pedido_id}")
def encontrar_pedido(pedido_id: str, session: Session = Depends(obter_sessao)):
    try:
        pedido_repository = PedidoRepositorySQLAlchemy(session=session)
        usecase = EncontrarPedidoUseCase(pedido_repository=pedido_repository)
        return usecase.executar(input=EncontrarPedidoInputDto(id=pedido_id))
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.post("/{pedido_id}/pagar")
def pagar_pedido(
    pedido_id: str,
    valor_pago: float,
    session: Session = Depends(obter_sessao),
):
    try:
        pedido_repository = PedidoRepositorySQLAlchemy(session=session)
        produto_repository = ProdutoRepositorySQLAlchemy(session=session)

        usecase = PagarPedidoUseCase(
            pedido_repository=pedido_repository,
            produto_repository=produto_repository,
        )
        input_dto = PagarPedidoInputDto(pedido_id=pedido_id, valor_pago=valor_pago)
        return usecase.executar(input=input_dto)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/{pedido_id}/cancelar")
def cancelar_pedido(pedido_id: str, session: Session = Depends(obter_sessao)):
    try:
        pedido_repository = PedidoRepositorySQLAlchemy(session=session)
        produto_repository = ProdutoRepositorySQLAlchemy(session=session)

        usecase = CancelarPedidoUseCase(
            pedido_repository=pedido_repository,
            produto_repository=produto_repository,
        )
        input_dto = CancelarPedidoInputDto(pedido_id=pedido_id)
        return usecase.executar(input=input_dto)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
