from typing import List, Optional
from uuid import UUID

from sqlalchemy.orm import Session

from domain.produto.produto_entity import Produto
from domain.produto.produto_repository_interface import ProdutoRepositoryInterface
from infra.produto.sqlalchemy.produto_models import ProdutoModel


class ProdutoRepositorySQLAlchemy(ProdutoRepositoryInterface):

    def __init__(self, session: Session):
        self.session = session

    def cadastrar_produto(self, produto: Produto) -> None:
        produto_model = ProdutoModel(
            id=produto.id,
            nome=produto.nome,
            preco=produto.preco,
            quantidade_estoque=produto.quantidade_estoque,
        )
        self.session.add(produto_model)
        self.session.commit()

    def encontrar_produto(self, produto_id: UUID) -> Optional[Produto]:
        model = (
            self.session.query(ProdutoModel)
            .filter(ProdutoModel.id == produto_id)
            .first()
        )

        if not model:
            return None

        return Produto(
            id=model.id,
            nome=model.nome,
            preco=model.preco,
            quantidade_estoque=model.quantidade_estoque,
        )

    def listar_produtos(self) -> List[Produto]:
        models = self.session.query(ProdutoModel).all()

        return [
            Produto(
                id=model.id,
                nome=model.nome,
                preco=model.preco,
                quantidade_estoque=model.quantidade_estoque,
            )
            for model in models
        ]

    def atualizar_produto(self, produto: Produto) -> None:
        model = (
            self.session.query(ProdutoModel)
            .filter(ProdutoModel.id == produto.id)
            .first()
        )

        if not model:
            raise ValueError("Produto não encontrado.")

        model.nome = produto.nome
        model.preco = produto.preco
        model.quantidade_estoque = produto.quantidade_estoque

        self.session.commit()

    def excluir_produto(self, produto_id: UUID) -> None:
        model = (
            self.session.query(ProdutoModel)
            .filter(ProdutoModel.id == produto_id)
            .first()
        )

        if not model:
            raise ValueError("Produto não encontrado.")

        self.session.delete(model)
        self.session.commit()
