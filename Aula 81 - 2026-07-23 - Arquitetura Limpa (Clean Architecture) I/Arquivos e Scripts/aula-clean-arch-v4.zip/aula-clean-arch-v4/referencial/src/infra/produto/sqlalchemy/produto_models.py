from sqlalchemy import Column, String, Float, Integer
from sqlalchemy.dialects.postgresql import UUID
from infra.api.database import Base


class ProdutoModel(Base):
    __tablename__ = "tb_produtos"

    id = Column(UUID(as_uuid=True), primary_key=True, index=True)
    nome = Column(String, nullable=False)
    preco = Column(Float, nullable=False)
    quantidade_estoque = Column(Integer, nullable=False)
