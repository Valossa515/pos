from sqlalchemy import Column, String, Float, Integer, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import UUID
from infra.api.database import Base


class ClienteModel(Base):
    __tablename__ = "tb_clientes"

    id = Column(UUID(as_uuid=True), primary_key=True, index=True)
    nome = Column(String, nullable=False)
    email = Column(String, nullable=False, unique=True)
    ativo = Column(Boolean, default=True, nullable=False)
