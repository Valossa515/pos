from typing import List, Optional
from uuid import UUID
from sqlalchemy.orm import Session
from domain.cliente.cliente_entity import Cliente
from domain.cliente.email_vo import Email
from domain.cliente.cliente_repository_interface import ClienteRepositoryInterface
from infra.cliente.sqlalchemy.cliente_models import ClienteModel


class ClienteRepositorySQLAlchemy(ClienteRepositoryInterface):

    def __init__(self, session: Session):
        self.session = session

    def cadastrar_cliente(self, cliente: Cliente) -> None:
        cliente_model = ClienteModel(
            id=cliente.id,
            nome=cliente.nome,
            email=cliente.email.valor,
            ativo=cliente.ativo,
        )
        self.session.add(cliente_model)
        self.session.commit()

    def encontrar_cliente(self, cliente_id: UUID) -> Optional[Cliente]:
        model = (
            self.session.query(ClienteModel)
            .filter(ClienteModel.id == cliente_id)
            .first()
        )
        if not model:
            return None
        return Cliente(
            id=str(model.id),
            nome=model.nome,
            email=Email(model.email),
            ativo=model.ativo,
        )

    def listar_clientes(self) -> List[Cliente]:
        models = self.session.query(ClienteModel).all()
        return [
            Cliente(id=m.id, nome=m.nome, email=Email(m.email), ativo=m.ativo)
            for m in models
        ]

    def atualizar_cliente(self, cliente: Cliente) -> None:
        model = (
            self.session.query(ClienteModel)
            .filter(ClienteModel.id == cliente.id)
            .first()
        )
        if model:
            model.nome = cliente.nome
            model.email = cliente.email.valor
            model.ativo = cliente.ativo
            self.session.commit()

    def excluir_cliente(self, cliente_id: UUID) -> None:
        model = (
            self.session.query(ClienteModel)
            .filter(ClienteModel.id == cliente_id)
            .first()
        )
        if model:
            self.session.delete(model)
            self.session.commit()
