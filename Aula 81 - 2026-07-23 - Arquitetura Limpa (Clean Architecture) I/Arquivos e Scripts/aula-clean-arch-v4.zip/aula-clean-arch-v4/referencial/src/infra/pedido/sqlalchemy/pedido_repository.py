from typing import List, Optional
from uuid import UUID

from sqlalchemy.orm import Session

from domain.pedido.item_pedido_entity import ItemPedido
from domain.pedido.pedido_entity import Pedido, StatusPedido
from domain.pedido.pedido_repository_interface import PedidoRepositoryInterface
from infra.pedido.sqlalchemy.pedido_models import ItemPedidoModel, PedidoModel


class PedidoRepositorySQLAlchemy(PedidoRepositoryInterface):

    def __init__(self, session: Session):
        self.session = session

    def criar_pedido(self, pedido: Pedido) -> None:
        pedido_model = PedidoModel(
            id=pedido.id,
            cliente_id=pedido.cliente_id,
            status=pedido.status.value,
            criado_em=pedido.criado_em,
            itens=[
                ItemPedidoModel(
                    produto_id=item.produto_id,
                    preco_unitario=item.preco_unitario,
                    quantidade=item.quantidade,
                )
                for item in pedido.itens
            ],
        )

        self.session.add(pedido_model)
        self.session.commit()

    def encontrar_pedido(self, pedido_id: UUID) -> Optional[Pedido]:
        model = (
            self.session.query(PedidoModel).filter(PedidoModel.id == pedido_id).first()
        )

        if not model:
            return None

        return self._converter_model_para_entidade(model)

    def listar_pedidos(self) -> List[Pedido]:
        models = self.session.query(PedidoModel).all()
        return [self._converter_model_para_entidade(model) for model in models]

    def listar_pedidos_por_cliente(self, cliente_id: UUID) -> List[Pedido]:
        models = (
            self.session.query(PedidoModel)
            .filter(PedidoModel.cliente_id == cliente_id)
            .all()
        )

        return [self._converter_model_para_entidade(model) for model in models]

    def atualizar_pedido(self, pedido: Pedido) -> None:
        model = (
            self.session.query(PedidoModel).filter(PedidoModel.id == pedido.id).first()
        )

        if not model:
            raise ValueError("Pedido não encontrado.")

        model.status = pedido.status.value
        model.criado_em = pedido.criado_em

        model.itens.clear()
        model.itens.extend(
            [
                ItemPedidoModel(
                    produto_id=item.produto_id,
                    preco_unitario=item.preco_unitario,
                    quantidade=item.quantidade,
                )
                for item in pedido.itens
            ]
        )

        self.session.commit()

    def _converter_model_para_entidade(self, model: PedidoModel) -> Pedido:
        itens = [
            ItemPedido(
                produto_id=item.produto_id,
                preco_unitario=item.preco_unitario,
                quantidade=item.quantidade,
            )
            for item in model.itens
        ]

        return Pedido(
            id=model.id,
            cliente_id=model.cliente_id,
            itens=itens,
            status=StatusPedido(model.status),
            criado_em=model.criado_em,
        )
