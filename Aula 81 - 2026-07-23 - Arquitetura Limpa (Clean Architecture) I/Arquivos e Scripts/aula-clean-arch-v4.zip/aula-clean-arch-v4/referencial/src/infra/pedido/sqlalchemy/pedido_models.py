from sqlalchemy import Column, String, Float, Integer, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import UUID
from infra.api.database import Base


class PedidoModel(Base):
    __tablename__ = "tb_pedidos"

    id = Column(UUID(as_uuid=True), primary_key=True, index=True)
    cliente_id = Column(
        UUID(as_uuid=True),
        ForeignKey("tb_clientes.id", ondelete="CASCADE"),
        nullable=False,
    )
    status = Column(String, nullable=False)
    criado_em = Column(DateTime, nullable=False)

    # Relacionamento 1:N com os Itens do Pedido
    itens = relationship(
        "ItemPedidoModel", back_populates="pedido", cascade="all, delete-orphan"
    )


class ItemPedidoModel(Base):
    __tablename__ = "tb_itens_pedido"

    id = Column(Integer, primary_key=True, autoincrement=True)
    pedido_id = Column(
        UUID(as_uuid=True),
        ForeignKey("tb_pedidos.id", ondelete="CASCADE"),
        nullable=False,
    )
    produto_id = Column(
        UUID(as_uuid=True),
        ForeignKey("tb_produtos.id", ondelete="RESTRICT"),
        nullable=False,
    )
    preco_unitario = Column(Float, nullable=False)
    quantidade = Column(Integer, nullable=False)

    pedido = relationship("PedidoModel", back_populates="itens")
