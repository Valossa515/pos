# DDD — MBA USP/Esalq

Material da aula de **Domain-Driven Design (DDD)** do MBA da **USP/Esalq**.

Nesta aula vamos aprender, na prática e com código Python, os fundamentos da
**Modelagem Estratégica** do DDD (Capítulos 1 a 3 do texto-base):

- **Linguagem Ubíqua** — fazer o código falar a mesma língua do negócio, para
  pararmos de "traduzir" conhecimento (e é na tradução que o conhecimento se
  perde — o "jogo do telefone").
- **Bounded Contexts (Contextos Delimitados)** — por que um mesmo termo
  ("Produto", "disponível") significa coisas diferentes em áreas diferentes, e
  como dividir o modelo para que cada contexto tenha **um** significado claro.

A ideia de cada projeto é comparar **o mesmo problema** resolvido de duas
formas — *sem DDD* (código técnico, com a regra de negócio escondida) e
*com DDD* (código que fala a língua do negócio) — e sentir a diferença.

## Como o repositório está organizado

| Pasta | Para que serve |
|---|---|
| [`aula/`](aula/) | Onde **construímos juntos** em sala, partindo do `sem_ddd.py` e evoluindo o código ao vivo. É o seu ponto de partida. |
| [`referencial/`](referencial/) | O **código final** já pronto, para você consultar e comparar depois da aula. |

Cada pasta tem os mesmos dois projetos:

1. **Projeto 1 — Linguagem Ubíqua** — domínio: autorização de compra no cartão de crédito.
2. **Projeto 2 — Bounded Contexts** — domínio: e-commerce (o "Produto" visto por Catálogo, Estoque e Vendas).

## Pré-requisito

Apenas **Docker Desktop** instalado e em execução — não é preciso ter Python na
máquina, pois tudo roda dentro de um container (Python 3.14). O passo a passo
completo está no `README.md` de cada pasta:

- [`aula/README.md`](aula/README.md) — para acompanhar a construção em sala.
- [`referencial/README.md`](referencial/README.md) — para rodar o código final.
