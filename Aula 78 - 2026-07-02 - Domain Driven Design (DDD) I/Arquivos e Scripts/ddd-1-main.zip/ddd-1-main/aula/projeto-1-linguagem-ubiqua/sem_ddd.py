def check(c):
    if c["v"] <= c["l"]:
        return 1
    elif c["v"] <= c["l"] * 1.2:
        return 2
    else:
        return 0


def main():
    cartao = {"l": 1000.0, "v": 0.0}

    for valor in (800.0, 1150.0, 1300.0):
        cartao["v"] = valor
        r = check(cartao)
        print(f"compra {valor} -> {r}")


if __name__ == "__main__":
    main()
