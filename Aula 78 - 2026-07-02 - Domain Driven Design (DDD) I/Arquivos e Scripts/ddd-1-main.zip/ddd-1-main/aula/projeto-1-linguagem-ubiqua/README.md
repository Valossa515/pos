# Projeto 1: Linguagem Ubíqua — construção em sala

> **Conceito de DDD:** Linguagem Ubíqua (Capítulo 2 do texto-base)
> **Domínio:** Cartão de crédito / Autorização de compra
> **Código final para comparar:** [`../../referencial/projeto-1-linguagem-ubiqua/`](../../referencial/projeto-1-linguagem-ubiqua/)

## O que vamos fazer aqui

Partimos de um código "técnico" (`sem_ddd.py`) e, **juntos em sala**, criamos a
versão que **fala a língua do negócio** (`linguagem_ubiqua.py`).

| Arquivo | Estado |
|---|---|
| `sem_ddd.py` | ✅ Já existe. Código "técnico": resultado como número mágico (`0, 1, 2`), função genérica (`check`), dados em dicionário (`c['l']`, `c['v']`). A regra fica **escondida**. |
| `linguagem_ubiqua.py` | ✍️ **Vamos criar na aula.** Código que fala a língua do negócio: `Cartao.autorizar_compra(valor)`, `TOLERANCIA = 0.20`, decisões nomeadas (aprovada / aprovada com tolerância / recusada). |

A ideia central: **se o código usa a mesma terminologia que o especialista de
domínio usa, paramos de "traduzir" conhecimento — e é traduzir que faz o
conhecimento se perder** (o "jogo do telefone" do Capítulo 2).

## A regra de negócio (as 3 faixas)

Uma compra é avaliada contra o limite do cartão, com **tolerância de 20%**:

| Situação | Regra | Resultado |
|---|---|---|
| Compra cabe no limite | `valor ≤ limite` | **Aprovada** |
| Estoura o limite, mas em até 20% | `limite < valor ≤ limite × 1,20` | **Aprovada com tolerância** |
| Passa de 20% acima do limite | `valor > limite × 1,20` | **Recusada** |

Com `limite = R$ 1.000` (teto com tolerância = R$ 1.200):
- compra de **R$ 800** → aprovada
- compra de **R$ 1.150** → aprovada com tolerância
- compra de **R$ 1.300** → recusada

## Pré-requisitos

- **Docker Desktop** instalado e em execução (`docker --version`). Não é
  necessário ter Python na máquina — ele roda dentro do container (Python 3.14).
  Passo a passo completo do Docker em [../README.md](../README.md). Os comandos
  abaixo são executados a partir da pasta `aula`.

## Como executar (via Docker, Python 3.14)

### 1. Entre na pasta da aula e construa a imagem (uma vez)
```bash
cd aula
docker compose build
```

### 2. Rode a versão SEM DDD e sinta a dor
```bash
docker compose run --rm aula python projeto-1-linguagem-ubiqua/sem_ddd.py
```
Observe a saída e tente responder, **só lendo o código**:
- O que significa o retorno `2` de `check`?
- A compra de `1300` retorna `0`. **Por quê?** A regra das faixas está clara?

Anote: você precisou *adivinhar* o significado de cada número.

### 3. Construa e rode a versão COM DDD
Depois de criarmos `linguagem_ubiqua.py` em sala:
```bash
docker compose run --rm aula python projeto-1-linguagem-ubiqua/linguagem_ubiqua.py
```
A regra deve ficar **explícita e na linguagem do negócio** — inclusive a
tolerância de 20% nomeada (`TOLERANCIA`).

> Quer ver uma versão pronta (com `Enum` para as decisões)? Compare com
> [`../../referencial/projeto-1-linguagem-ubiqua/`](../../referencial/projeto-1-linguagem-ubiqua/).

## Para discutir em sala

1. Cite 3 termos do negócio que apareceram na versão *com DDD* e estavam **ausentes** no `sem_ddd.py`.
2. O `sem_ddd.py` está "errado"? Ele funciona — então qual é exatamente o custo dele?
3. Onde, na versão *com DDD*, mora a regra "pode estourar o limite em até 20%"? E no `sem_ddd.py`?

## Ligação com o texto-base

- Cap. 2 — "Linguagem do negócio. Sem jargões técnicos!"
- Cap. 2 — termos ambíguos e sinônimos: cada termo com **um** significado.
