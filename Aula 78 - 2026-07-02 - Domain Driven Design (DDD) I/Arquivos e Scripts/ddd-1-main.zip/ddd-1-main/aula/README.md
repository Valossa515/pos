# Aula — Modelagem Estratégica (Caps. 1 a 3) — pasta de construção ao vivo

> Esta é a pasta **`aula/`**: aqui partimos do `sem_ddd.py` e **construímos
> juntos**, em sala, a versão *com DDD* de cada projeto. O código final, para
> comparar depois, está em [`../referencial/`](../referencial/).

## Pré-requisito único

- **Docker Desktop** instalado e em execução. Confira com:
  ```bash
  docker --version
  docker compose version
  ```
  Não é preciso ter Python na máquina — tudo roda no container (Python 3.14).

## Passo a passo

### 1. Entre na pasta da aula
```bash
cd aula
```

### 2. Construa a imagem (apenas na primeira vez)
```bash
docker compose build
```
Isso baixa o Python 3.14 e monta a imagem `ddd-aula` com o código dos projetos.

### 3. Rode o ponto de partida (`sem_ddd.py`)

**Projeto 1 — Linguagem Ubíqua:**
```bash
docker compose run --rm aula python projeto-1-linguagem-ubiqua/sem_ddd.py
```

**Projeto 2 — Bounded Contexts:**
```bash
docker compose run --rm aula python projeto-2-bounded-contexts/sem_ddd.py
```

### 4. Construa a versão *com DDD* em sala

Durante a aula vamos criar, ao vivo, a versão que fala a língua do negócio:

- Projeto 1 → `projeto-1-linguagem-ubiqua/linguagem_ubiqua.py`
- Projeto 2 → `projeto-2-bounded-contexts/bounded_contexts.py`

Assim que o arquivo existir, rode-o do mesmo jeito, por exemplo:
```bash
docker compose run --rm aula python projeto-1-linguagem-ubiqua/linguagem_ubiqua.py
docker compose run --rm aula python projeto-2-bounded-contexts/bounded_contexts.py
```

> Travou ou quer conferir o resultado? O código final está em
> [`../referencial/`](../referencial/).

### 5. (Opcional) Abra um shell interativo dentro do container
```bash
docker compose run --rm aula
```
Lá dentro você está em Python 3.14:
```bash
python --version          # Python 3.14.x
python projeto-1-linguagem-ubiqua/sem_ddd.py
exit                      # sai do container
```

## Observações

- A flag `--rm` remove o container ao terminar (não deixa lixo).
- A pasta `aula` é **montada** no container (`volumes`), então qualquer edição
  que você fizer nos arquivos `.py` no seu computador vale na hora, sem
  reconstruir a imagem.
- Só é preciso refazer `docker compose build` se você mudar o `Dockerfile`.
