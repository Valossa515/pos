"""
SEM DDD — Um único modelo "faz-tudo" (o objeto-deus).

Aqui existe UMA classe Produto compartilhada por três áreas do e-commerce:
Catálogo, Estoque e Vendas. Cada área precisa de coisas diferentes de
"produto", então a classe vai inchando com campos de todos:

- Catálogo quer: nome, descrição, fotos.
- Estoque quer: quantidade, posição no depósito, peso.
- Vendas quer: preço, alíquota de imposto, desconto.

O termo "disponível" significa coisas DIFERENTES em cada área:
- Para o Catálogo, "disponível" = está publicado no site.
- Para o Estoque, "disponível" = tem unidade física na prateleira.
As duas ideias brigam dentro do mesmo campo 'disponivel' e ninguém sabe
qual regra vale. É o modelo inconsistente do Capítulo 3.

Rode com:  python sem_ddd.py
"""


class Produto:
    def __init__(self, sku):
        self.sku = sku
        # Catálogo
        self.nome = None
        self.descricao = None
        self.fotos = []
        # Estoque
        self.quantidade = 0
        self.posicao_deposito = None
        self.peso_kg = None
        # Vendas
        self.preco = None
        self.aliquota_imposto = None
        self.desconto = None
        # Campo ambíguo: "disponível" para quem???
        self.disponivel = False


def main():
    p = Produto(sku="ABC-123")

    # Time de catálogo publica o produto:
    p.nome = "Caneca DDD"
    p.descricao = "Caneca de cerâmica 300ml"
    p.disponivel = True  # "publicado no site"

    # Time de estoque mexe no MESMO objeto:
    p.quantidade = 0  # acabou o estoque físico!
    # ...mas 'disponivel' continua True. O produto está disponível ou não?

    # Time de vendas tenta vender:
    p.preco = 49.90
    if p.disponivel:
        print("Vendendo", p.nome, "por R$", p.preco)
        print("...mas a quantidade em estoque é:", p.quantidade, "-> venda fantasma!")

    print()
    print("Um único campo 'disponivel' tentou significar duas coisas e gerou bug.")


if __name__ == "__main__":
    main()
