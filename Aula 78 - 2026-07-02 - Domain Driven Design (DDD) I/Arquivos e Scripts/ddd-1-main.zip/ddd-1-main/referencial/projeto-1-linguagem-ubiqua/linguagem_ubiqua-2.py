"""
COM DDD — Linguagem Ubíqua presente.

O código "fala a língua do negócio.

    "O cartão tem um limite. A compra é aprovada se cabe no limite.
     O banco ainda aceita estourar o limite em até 20% (a tolerância).
     Acima disso, a compra é recusada."
"""

from enum import Enum

TOLERANCIA = 0.20  # o banco aceita estourar o limite em até 20%


class Decisao(Enum):
    APROVADA = "aprovada"
    APROVADA_COM_TOLERANCIA = "aprovada usando a tolerância"
    RECUSADA = "recusada: passou da tolerância"


class Cartao:
    def __init__(self, titular, limite):
        self.titular = titular
        self.limite = limite

    @property
    def valor_maximo_aceito(self):
        return self.limite + self.limite * TOLERANCIA

    def autorizar_compra(self, valor):
        if valor <= self.limite:
            return Decisao.APROVADA
        if valor <= self.valor_maximo_aceito:
            return Decisao.APROVADA_COM_TOLERANCIA
        return Decisao.RECUSADA


def main():
    cartao = Cartao(titular="Ana", limite=1000.0)

    for valor in (800.0, 1150.0, 1300.0):
        decisao = cartao.autorizar_compra(valor)
        print(f"Compra de R$ {valor:.0f}: {decisao.value}")


if __name__ == "__main__":
    main()
