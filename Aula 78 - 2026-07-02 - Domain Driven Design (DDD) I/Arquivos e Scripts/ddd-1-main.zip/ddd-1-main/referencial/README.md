# Referencial — Modelagem Estratégica (Caps. 1 a 3) — código final

> Esta é a pasta **`referencial/`**: o **código final** de cada projeto, pronto
> para você consultar e comparar. A versão que construímos ao vivo está em
> [`../aula/`](../aula/).

## Pré-requisito único

- **Docker Desktop** instalado e em execução. Confira com:
  ```bash
  docker --version
  docker compose version
  ```
  Não é preciso ter Python na máquina — tudo roda no container (Python 3.14).

## Passo a passo

### 1. Entre na pasta referencial
```bash
cd referencial
```

### 2. Construa a imagem (apenas na primeira vez)
```bash
docker compose build
```
Isso baixa o Python 3.14 e monta a imagem `ddd-referencial` com o código dos projetos.

### 3. Rode cada exemplo (Python 3.14 dentro do container)

**Projeto 1 — Linguagem Ubíqua:**
```bash
docker compose run --rm referencial python projeto-1-linguagem-ubiqua/sem_ddd.py
docker compose run --rm referencial python projeto-1-linguagem-ubiqua/linguagem_ubiqua-1.py
docker compose run --rm referencial python projeto-1-linguagem-ubiqua/linguagem_ubiqua-2.py
```
> `linguagem_ubiqua-1.py` é o primeiro passo (decisões como texto) e
> `linguagem_ubiqua-2.py` evolui para um `Enum` de decisões.

**Projeto 2 — Bounded Contexts:**
```bash
docker compose run --rm referencial python projeto-2-bounded-contexts/sem_ddd.py
docker compose run --rm referencial python projeto-2-bounded-contexts/bounded_contexts.py
```

### 4. (Opcional) Abra um shell interativo dentro do container
```bash
docker compose run --rm referencial
```
Lá dentro você está em Python 3.14:
```bash
python --version          # Python 3.14.x
python projeto-1-linguagem-ubiqua/linguagem_ubiqua-2.py
exit                      # sai do container
```

## Observações

- A flag `--rm` remove o container ao terminar (não deixa lixo).
- A pasta `referencial` é **montada** no container (`volumes`), então qualquer
  edição nos arquivos `.py` no seu computador vale na hora, sem reconstruir a imagem.
- Só é preciso refazer `docker compose build` se você mudar o `Dockerfile`.
