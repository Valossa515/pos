"""
COM DDD — Bounded Contexts (Capítulo 3).

Em vez de UM "Produto faz-tudo", dividimos a linguagem em três contextos
delimitados. Cada contexto tem o SEU modelo de Produto, com os campos e a
regra que fazem sentido ali:

- contexto CATÁLOGO  -> ProdutoDoCatalogo  ("disponível" = publicado)
- contexto ESTOQUE   -> ItemDeEstoque      ("disponível" = tem unidade física)
- contexto VENDAS    -> ProdutoAVenda      (preço, imposto, desconto)

O termo "Produto" continua existindo em todos, mas com UM significado claro
DENTRO de cada contexto. Os contextos se integram por um identificador
compartilhado: o SKU.

Repare: nenhum contexto enxerga os campos do outro. Não há mais um campo
'disponivel' ambíguo brigando consigo mesmo.

Rode com:  python bounded_contexts.py
"""

from dataclasses import dataclass, field


# ----------------------- Contexto: CATÁLOGO -----------------------
# Aqui "disponível" significa: está publicado para o cliente ver.
@dataclass
class ProdutoDoCatalogo:
    sku: str
    nome: str
    descricao: str
    fotos: list[str] = field(default_factory=list)
    publicado: bool = False

    def publicar(self) -> None:
        self.publicado = True

    def esta_visivel_para_o_cliente(self) -> bool:
        return self.publicado


# ----------------------- Contexto: ESTOQUE ------------------------
# Aqui "disponível" significa: existe unidade física na prateleira.
@dataclass
class ItemDeEstoque:
    sku: str
    quantidade: int = 0
    posicao_deposito: str = ""

    def ha_unidade_disponivel(self) -> bool:
        return self.quantidade > 0

    def baixar(self, qtd: int) -> None:
        if qtd > self.quantidade:
            raise ValueError("Estoque insuficiente.")
        self.quantidade -= qtd


# ----------------------- Contexto: VENDAS -------------------------
# Aqui o produto carrega preço, imposto e desconto.
@dataclass
class ProdutoAVenda:
    sku: str
    preco: float
    aliquota_imposto: float = 0.0

    def preco_final(self) -> float:
        return round(self.preco * (1 + self.aliquota_imposto), 2)


# ----------------------- Integração entre contextos ---------------
def pode_vender(catalogo: ProdutoDoCatalogo, estoque: ItemDeEstoque) -> bool:
    """A decisão de vender combina os DOIS sentidos de 'disponível',
    cada um vindo do seu contexto, de forma explícita."""
    return catalogo.esta_visivel_para_o_cliente() and estoque.ha_unidade_disponivel()


def main() -> None:
    sku = "ABC-123"

    catalogo = ProdutoDoCatalogo(sku, "Caneca DDD", "Caneca de cerâmica 300ml")
    catalogo.publicar()

    estoque = ItemDeEstoque(sku, quantidade=0, posicao_deposito="R3-P2")
    vendas = ProdutoAVenda(sku, preco=49.90, aliquota_imposto=0.12)

    print("Publicado no catálogo? ", catalogo.esta_visivel_para_o_cliente())
    print("Tem unidade no estoque?", estoque.ha_unidade_disponivel())
    print("Preço final (com imposto): R$", vendas.preco_final())
    print()

    if pode_vender(catalogo, estoque):
        print("Venda autorizada.")
    else:
        print("Venda BLOQUEADA: publicado, mas sem estoque físico. Sem venda fantasma.")

    # Repõe estoque e tenta de novo:
    estoque.quantidade = 5
    print("Após reposição, pode vender?", pode_vender(catalogo, estoque))


if __name__ == "__main__":
    main()
