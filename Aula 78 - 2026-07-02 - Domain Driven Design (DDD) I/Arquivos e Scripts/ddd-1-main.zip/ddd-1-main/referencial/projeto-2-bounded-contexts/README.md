# Projeto 2: Bounded Context (Contexto Delimitado) — código final

> **Conceito de DDD:** Bounded Context (Capítulo 3 do texto-base)
> **Domínio:** E-commerce / Produto visto por Catálogo, Estoque e Vendas
> **Versão construída em sala:** [`../../aula/projeto-2-bounded-contexts/`](../../aula/projeto-2-bounded-contexts/)

## O que este projeto mostra

O mesmo termo do negócio — **"Produto"** — significa coisas diferentes em áreas
diferentes. Forçar um único modelo para todos gera o **modelo inconsistente**
(o "objeto-deus").

| Arquivo | O que demonstra |
|---|---|
| `sem_ddd.py` | Uma única classe `Produto` compartilhada por Catálogo, Estoque e Vendas. O campo `disponivel` tenta significar "publicado" **e** "tem estoque" ao mesmo tempo → **venda fantasma** (vende sem estoque). |
| `bounded_contexts.py` | Três **contextos delimitados** (`ProdutoDoCatalogo`, `ItemDeEstoque`, `ProdutoAVenda`), cada um com o seu modelo consistente. Integração pelo **SKU**. |

Ideia central do Capítulo 3: **"Pau para toda obra, mestre de nada"**. Um modelo
único para tudo acaba não servindo bem para nada. A solução é dividir a
Linguagem Ubíqua em contextos, cada um com **um** significado para cada termo.

## Pré-requisitos

- **Docker Desktop** instalado e em execução (`docker --version`). Não é
  necessário ter Python na máquina — ele roda dentro do container (Python 3.14).
  Passo a passo completo do Docker em [../README.md](../README.md). Os comandos
  abaixo são executados a partir da pasta `referencial`.

## Como executar (via Docker, Python 3.14)

### 1. Entre na pasta referencial e construa a imagem (uma vez)
```bash
cd referencial
docker compose build
```

### 2. Rode a versão SEM DDD
```bash
docker compose run --rm referencial python projeto-2-bounded-contexts/sem_ddd.py
```
Observe: o produto fica `disponivel = True` (publicado) **mas** com
`quantidade = 0`. O código autoriza uma **venda fantasma**. Pergunte-se: *o
campo `disponivel` é "publicado" ou "tem estoque"?* Ele tenta ser os dois — e falha.

### 3. Rode a versão COM DDD
```bash
docker compose run --rm referencial python projeto-2-bounded-contexts/bounded_contexts.py
```
Agora cada contexto responde a **sua** pergunta:
- Catálogo: *está publicado?*
- Estoque: *tem unidade física?*
- Vendas: *qual o preço final?*

A função `pode_vender(...)` combina os dois sentidos de forma **explícita**, e a
venda fantasma desaparece.

## Para discutir em sala

1. Por que **não** basta renomear o campo para `publicado_e_com_estoque`? (Dica: carga cognitiva e modelos mentais diferentes.)
2. Qual é a diferença entre **subdomínio** (descoberto) e **bounded context** (projetado)?
3. Os três contextos compartilham o `sku`. Esse é o **contrato** de integração entre eles. O que aconteceria se cada contexto inventasse seu próprio identificador?

## Ligação com o texto-base

- Cap. 3 — "Modelos inconsistentes" e o exemplo do termo *lead* (marketing vs. vendas).
- Cap. 3 — "Contextos delimitados são os limites de consistência de linguagens ubíquas."
- Cap. 3 — subdomínios são **descobertos**; bounded contexts são **projetados**.
