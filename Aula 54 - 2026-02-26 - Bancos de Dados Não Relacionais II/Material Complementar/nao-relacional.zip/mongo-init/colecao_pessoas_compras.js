db = db.getMongo().getDB("mba_esalq");

db.pessoas.insertMany([
{ "_id" : 1, "nome" : "jane", "esporte" : ["golf", "vôlei"] }, 
{ "_id" : 2, "nome" : "joe", "esporte" : ["tênis", "golf", "natação"]},
{ "_id" : 3, "nome" : "anne", "esporte" : ["vôlei", "basquete", "futebol", "golf"]},
{ "_id" : 4, "nome" : "peter", "esporte" : ["futebol", "vôlei"]}
]);

db.compras.insertMany([
{"_id" : 1, "id_comprador": 2, "data": ISODate("2020-01-15"), "valor": "76.25"},
{"_id" : 2, "id_comprador": 4, "data": ISODate("2020-01-07"), "valor": "10.05"},
{"_id" : 3, "id_comprador": 2, "data": ISODate("2020-03-28"), "valor": "512.38"},
{"_id" : 4, "id_comprador": 2, "data": ISODate("2020-04-21"), "valor": "62.99"},
{"_id" : 5, "id_comprador": 4, "data": ISODate("2020-05-19"), "valor": "374.81"},
]);


