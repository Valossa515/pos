# Ambiente de Desenvolvimento com MongoDB, Mongo Express e Neo4j

Este projeto utiliza **Docker Compose** para configurar um ambiente de
desenvolvimento local contendo:

- **MongoDB** com carga automática de coleções.
- **Mongo Express** (interface web administrativa para MongoDB).
- **Neo4j** com carga automática do grafo via script Cypher.

Os dados são persistidos em volumes Docker, garantindo que permaneçam
disponíveis mesmo após reiniciar ou remover os containers.

---

## Pré‑requisitos

- Docker: https://docs.docker.com/get-docker/
- Docker Compose (já incluso no Docker Desktop moderno)

---

## Estrutura de Arquivos

    .
    ├── mongo-init/
    │   └── *.js                 # Scripts de ingestão MongoDB
    ├── neo4j-init/
    │   └── grafo_filmes.cypher  # Script de criação do grafo
    ├── docker-compose.yml
    └── README.md

---

## Como Usar

1.  Clone ou baixe os arquivos para um diretório em sua máquina.
2.  Abra um terminal dentro do diretório do projeto.

### Iniciar o ambiente

    docker compose up -d

Na primeira execução:

- O MongoDB executará automaticamente os scripts presentes em
  `mongo-init/`.
- O Neo4j será iniciado e o grafo será carregado automaticamente a
  partir do arquivo `grafo_filmes.cypher`.

### Parar o ambiente

    docker compose down

Os dados NÃO serão apagados.

---

## Reiniciar totalmente (resetar dados)

Caso deseje recriar os bancos do zero:

    docker compose down -v
    docker compose up -d

Isso remove os volumes persistidos.

---

## Acessando os Serviços

---

### Neo4j

Interface Web:

http://localhost:7474

Credenciais:

Usuário:

    neo4j

Senha:

    outrasenhasecreta

Bolt (drivers):

    7687

Após abrir o Browser execute:

    MATCH (n) RETURN n;

para visualizar o grafo carregado.

---

### MongoDB

Host:

    localhost

Porta:

    27017

Usuário:

    root

Senha:

    senhasecreta

String de conexão:

    mongodb://root:senhasecreta@localhost:27017/

---

### Mongo Express (Interface Web MongoDB)

O ambiente inclui o Mongo Express para administração via navegador.

Acesse:

http://localhost:8081

Permite:

- visualizar databases
- executar queries
- editar documentos
- importar/exportar dados

---

## Clientes Recomendados MongoDB

Além do Mongo Express, recomenda‑se:

### MongoDB Compass (oficial)

https://www.mongodb.com/products/compass

### VSCode Extension

MongoDB for VSCode:

https://marketplace.visualstudio.com/items?itemName=mongodb.mongodb-vscode

---

## Segurança

As credenciais utilizadas neste projeto são destinadas exclusivamente
para **desenvolvimento ou fins acadêmicos**.

Nunca utilize essas senhas em ambientes de produção.
