from abc import ABC, abstractmethod
from typing import List, Optional
from uuid import UUID
from app.domain.produto.produto_entity import Produto


class ProdutoRepositoryInterface(ABC):

    @abstractmethod
    def cadastrar_produto(self, produto: Produto) -> None:
        raise NotImplementedError

    @abstractmethod
    def encontrar_produto(self, produto_id: UUID) -> Optional[Produto]:
        raise NotImplementedError

    @abstractmethod
    def listar_produtos(self) -> List[Produto]:
        raise NotImplementedError

    @abstractmethod
    def atualizar_produto(self, produto: Produto) -> None:
        raise NotImplementedError

    @abstractmethod
    def excluir_produto(self, produto_id: UUID) -> None:
        raise NotImplementedError
