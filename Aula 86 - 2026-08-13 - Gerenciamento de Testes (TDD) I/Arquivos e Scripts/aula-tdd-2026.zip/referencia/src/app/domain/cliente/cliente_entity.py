from dataclasses import dataclass
from uuid import UUID

from app.domain.cliente.email_vo import Email


@dataclass
class Cliente:
    id: UUID
    nome: str
    email: Email
    ativo: bool = True

    def __post_init__(self):
        self.validar()

    def validar(self):
        if not isinstance(self.id, UUID):
            raise ValueError("O id deve ser um UUID.")

        if not self.nome or not self.nome.strip():
            raise ValueError("O nome do cliente é obrigatório.")

    def desativar(self) -> None:
        self.ativo = False

    def ativar(self) -> None:
        self.ativo = True
