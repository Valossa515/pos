from abc import ABC, abstractmethod
from typing import List
from uuid import UUID
from app.domain.cliente.cliente_entity import Cliente


class ClienteRepositoryInterface(ABC):

    @abstractmethod
    def cadastrar_cliente(self, cliente: Cliente) -> None:
        raise NotImplementedError

    @abstractmethod
    def encontrar_cliente(self, cliente_id: UUID) -> Cliente:
        raise NotImplementedError

    @abstractmethod
    def listar_clientes(self) -> List[Cliente]:
        raise NotImplementedError

    @abstractmethod
    def atualizar_cliente(self, cliente: Cliente) -> None:
        raise NotImplementedError

    @abstractmethod
    def excluir_cliente(self, client_id: UUID) -> None:
        raise NotImplementedError
