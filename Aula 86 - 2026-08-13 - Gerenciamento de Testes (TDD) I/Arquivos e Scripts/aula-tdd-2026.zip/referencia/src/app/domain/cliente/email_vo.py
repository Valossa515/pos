class Email:
    def __init__(self, valor: str):
        self.valor = valor
        self.validar()

    def validar(self):
        if not self.valor or not self.valor.strip():
            raise ValueError("O e-mail é obrigatório.")

        if "@" not in self.valor or "." not in self.valor:
            raise ValueError("E-mail inválido.")
