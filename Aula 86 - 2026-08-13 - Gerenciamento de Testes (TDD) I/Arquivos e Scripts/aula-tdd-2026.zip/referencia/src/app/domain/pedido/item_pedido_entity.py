from dataclasses import dataclass
from uuid import UUID


@dataclass
class ItemPedido:
    id: UUID
    produto_id: UUID
    preco_unitario: float
    quantidade: int

    def __post_init__(self):
        if not isinstance(self.id, UUID):
            raise ValueError("O id deve ser um UUID.")

        if not isinstance(self.produto_id, UUID):
            raise ValueError("O produto_id deve ser um UUID.")

        if self.quantidade <= 0:
            raise ValueError(
                "A quantidade do item deve ser maior que zero."
            )

        if self.preco_unitario <= 0:
            raise ValueError(
                "O preço unitário do item deve ser maior que zero."
            )

    def calcular_total(self) -> float:
        return self.preco_unitario * self.quantidade