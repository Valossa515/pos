from uuid import UUID

from pydantic import BaseModel


class EncontrarProdutoInputDto(BaseModel):
    id: UUID


class EncontrarProdutoOutputDto(BaseModel):
    id: UUID
    nome: str
    preco: float
    quantidade_estoque: int
