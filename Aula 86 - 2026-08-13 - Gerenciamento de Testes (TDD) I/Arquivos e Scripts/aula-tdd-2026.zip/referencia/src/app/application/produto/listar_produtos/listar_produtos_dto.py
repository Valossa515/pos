from uuid import UUID

from pydantic import BaseModel
from typing import List


class ListarProdutosInputDto(BaseModel):
    pass


class ProdutoOutputDto(BaseModel):
    id: UUID
    nome: str
    preco: float
    quantidade_estoque: int


class ListarProdutosOutputDto(BaseModel):
    produtos: List[ProdutoOutputDto]
