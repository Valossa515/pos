from app.domain.__seedwork.use_case_interface import UseCaseInterface
from app.domain.produto.produto_repository_interface import ProdutoRepositoryInterface
from app.application.produto.atualizar_produto.atualizar_produto_dto import (
    AtualizarProdutoInputDto,
    AtualizarProdutoOutputDto,
)


class AtualizarProdutoUseCase(UseCaseInterface):

    def __init__(self, produto_repository: ProdutoRepositoryInterface):
        self.produto_repository = produto_repository

    def executar(self, input: AtualizarProdutoInputDto) -> AtualizarProdutoOutputDto:
        produto = self.produto_repository.encontrar_produto(input.id)
        if not produto:
            raise ValueError("Produto não encontrado.")

        produto.nome = input.nome
        produto.preco = input.preco
        produto.quantidade_estoque = input.quantidade_estoque
        produto.validar()

        self.produto_repository.atualizar_produto(produto)

        return AtualizarProdutoOutputDto(
            id=produto.id,
            nome=produto.nome,
            preco=produto.preco,
            quantidade_estoque=produto.quantidade_estoque,
        )
