from app.domain.__seedwork.use_case_interface import UseCaseInterface
from app.domain.produto.produto_repository_interface import ProdutoRepositoryInterface
from app.application.produto.excluir_produto.excluir_produto_dto import (
    ExcluirProdutoInputDto,
    ExcluirProdutoOutputDto,
)


class ExcluirProdutoUseCase(UseCaseInterface):

    def __init__(self, produto_repository: ProdutoRepositoryInterface):
        self.produto_repository = produto_repository

    def executar(self, input: ExcluirProdutoInputDto) -> ExcluirProdutoOutputDto:
        produto = self.produto_repository.encontrar_produto(input.id)
        if not produto:
            raise ValueError("Produto não encontrado.")

        self.produto_repository.excluir_produto(input.id)
        return ExcluirProdutoOutputDto(mensagem="Produto excluído com sucesso.")
