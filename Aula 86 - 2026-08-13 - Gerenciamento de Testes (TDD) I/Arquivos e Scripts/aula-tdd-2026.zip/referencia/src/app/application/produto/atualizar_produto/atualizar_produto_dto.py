from uuid import UUID
from pydantic import BaseModel


class AtualizarProdutoInputDto(BaseModel):
    id: UUID
    nome: str
    preco: float
    quantidade_estoque: int


class AtualizarProdutoOutputDto(BaseModel):
    id: UUID
    nome: str
    preco: float
    quantidade_estoque: int
