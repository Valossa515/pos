from uuid import UUID

from pydantic import BaseModel


class CadastrarProdutoInputDto(BaseModel):
    nome: str
    preco: float
    quantidade_estoque: int


class CadastrarProdutoOutputDto(BaseModel):
    id: UUID
    nome: str
    preco: float
    quantidade_estoque: int
