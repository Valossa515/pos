from uuid import UUID

from pydantic import BaseModel


class ExcluirProdutoInputDto(BaseModel):
    id: UUID


class ExcluirProdutoOutputDto(BaseModel):
    mensagem: str
