from app.domain.__seedwork.use_case_interface import UseCaseInterface
from app.domain.cliente.cliente_repository_interface import ClienteRepositoryInterface
from app.application.cliente.encontrar_cliente.encontrar_cliente_dto import (
    EncontrarClienteInputDto,
    EncontrarClienteOutputDto,
)


class EncontrarClienteUseCase(UseCaseInterface):

    def __init__(self, cliente_repository: ClienteRepositoryInterface):
        self.cliente_repository = cliente_repository

    def executar(self, input: EncontrarClienteInputDto) -> EncontrarClienteOutputDto:
        cliente = self.cliente_repository.encontrar_cliente(input.id)
        if not cliente:
            raise ValueError("Cliente não encontrado.")

        return EncontrarClienteOutputDto(
            id=cliente.id,
            nome=cliente.nome,
            email=cliente.email.valor,
            ativo=cliente.ativo,
        )
