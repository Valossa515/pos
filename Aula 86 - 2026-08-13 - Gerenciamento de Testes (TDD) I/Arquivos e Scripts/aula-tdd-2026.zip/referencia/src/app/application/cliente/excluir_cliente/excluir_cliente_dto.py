from uuid import UUID

from pydantic import BaseModel


class ExcluirClienteInputDto(BaseModel):
    id: UUID


class ExcluirClienteOutputDto(BaseModel):
    mensagem: str
