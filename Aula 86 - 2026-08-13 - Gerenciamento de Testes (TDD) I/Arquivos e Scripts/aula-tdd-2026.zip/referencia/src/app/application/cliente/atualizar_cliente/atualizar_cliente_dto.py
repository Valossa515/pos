from uuid import UUID
from pydantic import BaseModel


class AtualizarClienteInputDto(BaseModel):
    id: UUID
    nome: str
    email: str


class AtualizarClienteOutputDto(BaseModel):
    id: UUID
    nome: str
    email: str
    ativo: bool
