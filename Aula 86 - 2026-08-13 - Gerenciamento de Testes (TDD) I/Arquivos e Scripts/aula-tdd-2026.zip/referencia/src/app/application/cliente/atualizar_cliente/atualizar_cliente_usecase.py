from app.domain.__seedwork.use_case_interface import UseCaseInterface
from app.domain.cliente.cliente_repository_interface import ClienteRepositoryInterface
from app.application.cliente.atualizar_cliente.atualizar_cliente_dto import (
    AtualizarClienteInputDto,
    AtualizarClienteOutputDto,
)
from app.domain.cliente.email_vo import Email


class AtualizarClienteUseCase(UseCaseInterface):

    def __init__(self, cliente_repository: ClienteRepositoryInterface):
        self.cliente_repository = cliente_repository

    def executar(self, input: AtualizarClienteInputDto) -> AtualizarClienteOutputDto:
        cliente = self.cliente_repository.encontrar_cliente(input.id)
        if not cliente:
            raise ValueError("Cliente não encontrado.")

        cliente.nome = input.nome
        cliente.email = Email(input.email)
        cliente.validar()

        self.cliente_repository.atualizar_cliente(cliente)

        return AtualizarClienteOutputDto(
            id=cliente.id,
            nome=cliente.nome,
            email=cliente.email.valor,
            ativo=cliente.ativo,
        )
