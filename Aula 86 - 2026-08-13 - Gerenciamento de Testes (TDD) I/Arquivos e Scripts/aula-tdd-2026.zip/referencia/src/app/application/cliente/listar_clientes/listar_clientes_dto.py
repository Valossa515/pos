from uuid import UUID
from pydantic import BaseModel
from typing import List


class ClienteOutputDto(BaseModel):
    id: UUID
    nome: str
    email: str
    ativo: bool


class ListarClientesOutputDto(BaseModel):
    clientes: List[ClienteOutputDto]
