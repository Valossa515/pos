from uuid import UUID
from pydantic import BaseModel


class EncontrarClienteInputDto(BaseModel):
    id: UUID


class EncontrarClienteOutputDto(BaseModel):
    id: UUID
    nome: str
    email: str
    ativo: bool
