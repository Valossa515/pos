from uuid import UUID

from pydantic import BaseModel


class CadastrarClienteInputDto(BaseModel):
    nome: str
    email: str


class CadastrarClienteOutputDto(BaseModel):
    id: UUID
    nome: str
    email: str
    ativo: bool
