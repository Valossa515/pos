from uuid import UUID
from pydantic import BaseModel
from typing import List


class EncontrarPedidoInputDto(BaseModel):
    id: UUID


class ItemPedidoOutputDto(BaseModel):
    produto_id: UUID
    preco_unitario: float
    quantidade: int
    total: float


class EncontrarPedidoOutputDto(BaseModel):
    id: UUID
    cliente_id: UUID
    status: str
    total: float
    criado_em: str
    itens: List[ItemPedidoOutputDto]
