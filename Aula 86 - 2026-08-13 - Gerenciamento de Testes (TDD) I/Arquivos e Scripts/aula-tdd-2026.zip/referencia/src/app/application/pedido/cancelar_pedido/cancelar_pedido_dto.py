from uuid import UUID
from pydantic import BaseModel


class CancelarPedidoInputDto(BaseModel):
    pedido_id: UUID


class CancelarPedidoOutputDto(BaseModel):
    pedido_id: UUID
    status: str
    mensagem: str
