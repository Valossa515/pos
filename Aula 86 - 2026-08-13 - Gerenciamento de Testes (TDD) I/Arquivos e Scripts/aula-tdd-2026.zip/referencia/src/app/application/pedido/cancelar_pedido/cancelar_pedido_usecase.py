from app.domain.__seedwork.use_case_interface import UseCaseInterface
from app.domain.pedido.pedido_repository_interface import PedidoRepositoryInterface
from app.domain.produto.produto_repository_interface import ProdutoRepositoryInterface
from app.application.pedido.cancelar_pedido.cancelar_pedido_dto import (
    CancelarPedidoInputDto,
    CancelarPedidoOutputDto,
)


class CancelarPedidoUseCase(UseCaseInterface):

    def __init__(
        self,
        pedido_repository: PedidoRepositoryInterface,
        produto_repository: ProdutoRepositoryInterface,
    ):
        self.pedido_repository = pedido_repository
        self.produto_repository = produto_repository

    def executar(self, input: CancelarPedidoInputDto) -> CancelarPedidoOutputDto:
        # 1. Busca o pedido
        pedido = self.pedido_repository.encontrar_pedido(input.pedido_id)
        if not pedido:
            raise ValueError("Pedido não encontrado.")

        # 2. Transiciona o estado do pedido (lança exceção se já estiver PAGO)
        pedido.cancelar()

        # 3. Devolve a quantidade de cada item de volta ao estoque do Produto
        for item in pedido.itens:
            produto = self.produto_repository.encontrar_produto(item.produto_id)
            if produto:
                produto.aumentar_estoque(
                    item.quantidade
                )  # Regra de negócio na Entidade Produto
                self.produto_repository.atualizar_produto(produto)

        # 4. Atualiza o status do pedido no banco
        self.pedido_repository.atualizar_pedido(pedido)

        return CancelarPedidoOutputDto(
            pedido_id=pedido.id,
            status=pedido.status.value,
            mensagem="Pedido cancelado com sucesso e estoque estornado.",
        )
