from uuid import UUID

from pydantic import BaseModel


class PagarPedidoInputDto(BaseModel):
    pedido_id: UUID
    valor_pago: float


class PagarPedidoOutputDto(BaseModel):
    pedido_id: UUID
    status: str
    total: float
