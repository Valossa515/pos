from typing import Optional
from uuid import UUID

from app.domain.produto.produto_entity import Produto
from app.domain.produto.produto_repository_interface import (
    ProdutoRepositoryInterface,
)


class InMemoryProdutoRepository(ProdutoRepositoryInterface):

    def __init__(self, produtos: list[Produto] = None):
        self.produtos: list[Produto] = produtos or []

    def cadastrar_produto(self, produto: Produto) -> None:
        self.produtos.append(produto)

    def encontrar_produto(self, produto_id: UUID) -> Optional[Produto]:
        return next(
            (produto for produto in self.produtos if produto.id == produto_id),
            None,
        )

    def listar_produtos(self) -> list[Produto]:
        return [produto for produto in self.produtos]

    def atualizar_produto(self, produto: Produto) -> None:
        produto_atual = self.encontrar_produto(produto.id)

        if produto_atual:
            self.produtos.remove(produto_atual)
            self.produtos.append(produto)

    def excluir_produto(self, produto_id: UUID) -> None:
        produto = self.encontrar_produto(produto_id)

        if produto:
            self.produtos.remove(produto)
