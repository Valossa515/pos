from typing import Optional
from uuid import UUID

from app.domain.cliente.cliente_entity import Cliente
from app.domain.cliente.cliente_repository_interface import (
    ClienteRepositoryInterface,
)


class InMemoryClienteRepository(ClienteRepositoryInterface):

    def __init__(self, clientes: list[Cliente] = None):
        self.clientes: list[Cliente] = clientes or []

    def cadastrar_cliente(self, cliente: Cliente) -> None:
        self.clientes.append(cliente)

    def encontrar_cliente(self, cliente_id: UUID) -> Optional[Cliente]:
        return next(
            (cliente for cliente in self.clientes if cliente.id == cliente_id),
            None,
        )

    def listar_clientes(self) -> list[Cliente]:
        return [cliente for cliente in self.clientes]

    def atualizar_cliente(self, cliente: Cliente) -> None:
        cliente_atual = self.encontrar_cliente(cliente.id)

        if cliente_atual:
            self.clientes.remove(cliente_atual)
            self.clientes.append(cliente)

    def excluir_cliente(self, cliente_id: UUID) -> None:
        cliente = self.encontrar_cliente(cliente_id)

        if cliente:
            self.clientes.remove(cliente)
