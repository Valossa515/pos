from app.infra.cliente.in_memory_cliente_repository import (
    InMemoryClienteRepository,
)
from app.infra.produto.in_memory_produto_repository import (
    InMemoryProdutoRepository,
)
from app.infra.pedido.in_memory_pedido_repository import (
    InMemoryPedidoRepository,
)

cliente_repository = InMemoryClienteRepository()
produto_repository = InMemoryProdutoRepository()
pedido_repository = InMemoryPedidoRepository()
