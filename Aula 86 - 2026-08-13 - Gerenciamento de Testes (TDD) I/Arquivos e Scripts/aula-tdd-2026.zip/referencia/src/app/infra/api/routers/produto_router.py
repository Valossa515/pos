from fastapi import APIRouter, HTTPException

from app.infra.api.dependencies import (
    produto_repository,
)

from app.application.produto.cadastrar_produto.cadastrar_produto_dto import (
    CadastrarProdutoInputDto,
)
from app.application.produto.cadastrar_produto.cadastrar_produto_usecase import (
    CadastrarProdutoUseCase,
)

from app.application.produto.encontrar_produto.encontrar_produto_dto import (
    EncontrarProdutoInputDto,
)
from app.application.produto.encontrar_produto.encontrar_produto_usecase import (
    EncontrarProdutoUseCase,
)

from app.application.produto.listar_produtos.listar_produtos_dto import (
    ListarProdutosInputDto,
)
from app.application.produto.listar_produtos.listar_produtos_usecase import (
    ListarProdutosUseCase,
)

from app.application.produto.atualizar_produto.atualizar_produto_dto import (
    AtualizarProdutoInputDto,
)
from app.application.produto.atualizar_produto.atualizar_produto_usecase import (
    AtualizarProdutoUseCase,
)

from app.application.produto.excluir_produto.excluir_produto_dto import (
    ExcluirProdutoInputDto,
)
from app.application.produto.excluir_produto.excluir_produto_usecase import (
    ExcluirProdutoUseCase,
)

router = APIRouter(
    prefix="/produtos",
    tags=["Produtos"],
)


@router.post("/", status_code=201)
def cadastrar_produto(
    request: CadastrarProdutoInputDto,
):
    try:
        usecase = CadastrarProdutoUseCase(
            produto_repository=produto_repository,
        )

        return usecase.executar(
            input=request,
        )

    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=str(e),
        )


@router.get("/{produto_id}")
def encontrar_produto(
    produto_id: str,
):
    try:
        usecase = EncontrarProdutoUseCase(
            produto_repository=produto_repository,
        )

        return usecase.executar(
            input=EncontrarProdutoInputDto(
                id=produto_id,
            )
        )

    except Exception as e:
        raise HTTPException(
            status_code=404,
            detail=str(e),
        )


@router.get("/")
def listar_produtos():
    try:
        usecase = ListarProdutosUseCase(
            produto_repository=produto_repository,
        )

        return usecase.executar(ListarProdutosInputDto())

    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=str(e),
        )


@router.put("/{produto_id}")
def atualizar_produto(
    produto_id: str,
    request: CadastrarProdutoInputDto,
):
    try:
        usecase = AtualizarProdutoUseCase(
            produto_repository=produto_repository,
        )

        input_dto = AtualizarProdutoInputDto(
            id=produto_id,
            nome=request.nome,
            preco=request.preco,
            quantidade_estoque=request.quantidade_estoque,
        )

        return usecase.executar(
            input=input_dto,
        )

    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=str(e),
        )


@router.delete("/{produto_id}")
def excluir_produto(
    produto_id: str,
):
    try:
        usecase = ExcluirProdutoUseCase(
            produto_repository=produto_repository,
        )

        return usecase.executar(
            input=ExcluirProdutoInputDto(
                id=produto_id,
            )
        )

    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=str(e),
        )
