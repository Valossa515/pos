from fastapi import FastAPI
from app.infra.api.routers import cliente_router, pedido_router, produto_router

app = FastAPI()

app.include_router(cliente_router.router)
app.include_router(pedido_router.router)
app.include_router(produto_router.router)
