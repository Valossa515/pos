from fastapi import APIRouter, HTTPException

from app.infra.api.dependencies import cliente_repository

from app.application.cliente.cadastrar_cliente.cadastrar_cliente_dto import (
    CadastrarClienteInputDto,
)
from app.application.cliente.cadastrar_cliente.cadastrar_cliente_usecase import (
    CadastrarClienteUseCase,
)
from app.application.cliente.encontrar_cliente.encontrar_cliente_dto import (
    EncontrarClienteInputDto,
)
from app.application.cliente.encontrar_cliente.encontrar_cliente_usecase import (
    EncontrarClienteUseCase,
)
from app.application.cliente.listar_clientes.listar_clientes_usecase import (
    ListarClientesUseCase,
)
from app.application.cliente.atualizar_cliente.atualizar_cliente_dto import (
    AtualizarClienteInputDto,
)
from app.application.cliente.atualizar_cliente.atualizar_cliente_usecase import (
    AtualizarClienteUseCase,
)
from app.application.cliente.excluir_cliente.excluir_cliente_dto import (
    ExcluirClienteInputDto,
)
from app.application.cliente.excluir_cliente.excluir_cliente_usecase import (
    ExcluirClienteUseCase,
)

router = APIRouter(
    prefix="/clientes",
    tags=["Clientes"],
)


@router.post("/", status_code=201)
def cadastrar_cliente(
    request: CadastrarClienteInputDto,
):
    try:
        usecase = CadastrarClienteUseCase(
            cliente_repository=cliente_repository,
        )

        return usecase.executar(input=request)

    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=str(e),
        )


@router.get("/{cliente_id}")
def encontrar_cliente(cliente_id: str):
    try:
        usecase = EncontrarClienteUseCase(
            cliente_repository=cliente_repository,
        )

        output = usecase.executar(
            input=EncontrarClienteInputDto(
                id=cliente_id,
            )
        )

        return output

    except Exception as e:
        raise HTTPException(
            status_code=404,
            detail=str(e),
        )


@router.get("/")
def listar_clientes():
    try:
        usecase = ListarClientesUseCase(
            cliente_repository=cliente_repository,
        )

        return usecase.executar()

    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=str(e),
        )


@router.put("/{cliente_id}")
def atualizar_cliente(
    cliente_id: str,
    request: CadastrarClienteInputDto,
):
    try:
        usecase = AtualizarClienteUseCase(
            cliente_repository=cliente_repository,
        )

        input_dto = AtualizarClienteInputDto(
            id=cliente_id,
            nome=request.nome,
            email=request.email,
        )

        return usecase.executar(
            input=input_dto,
        )

    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=str(e),
        )


@router.delete("/{cliente_id}")
def excluir_cliente(cliente_id: str):
    try:
        usecase = ExcluirClienteUseCase(
            cliente_repository=cliente_repository,
        )

        return usecase.executar(
            input=ExcluirClienteInputDto(
                id=cliente_id,
            )
        )

    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=str(e),
        )
