from typing import Optional
from uuid import UUID

from app.domain.pedido.pedido_entity import Pedido
from app.domain.pedido.pedido_repository_interface import (
    PedidoRepositoryInterface,
)


class InMemoryPedidoRepository(PedidoRepositoryInterface):

    def __init__(self, pedidos: list[Pedido] = None):
        self.pedidos: list[Pedido] = pedidos or []

    def criar_pedido(self, pedido: Pedido) -> None:
        self.pedidos.append(pedido)

    def encontrar_pedido(
        self,
        pedido_id: UUID,
    ) -> Optional[Pedido]:
        return next(
            (pedido for pedido in self.pedidos if pedido.id == pedido_id),
            None,
        )

    def listar_pedidos(self) -> list[Pedido]:
        return [pedido for pedido in self.pedidos]

    def listar_pedidos_por_cliente(
        self,
        cliente_id: UUID,
    ) -> list[Pedido]:
        return [pedido for pedido in self.pedidos if pedido.cliente_id == cliente_id]

    def atualizar_pedido(
        self,
        pedido: Pedido,
    ) -> None:
        pedido_atual = self.encontrar_pedido(pedido.id)

        if pedido_atual:
            self.pedidos.remove(pedido_atual)
            self.pedidos.append(pedido)
