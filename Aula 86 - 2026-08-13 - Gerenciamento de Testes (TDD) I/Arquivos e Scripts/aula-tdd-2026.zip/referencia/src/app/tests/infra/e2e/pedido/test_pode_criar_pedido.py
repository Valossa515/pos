from uuid import UUID

from fastapi.testclient import TestClient

from app.infra.api.main import app

client = TestClient(app)


class TestCriarPedido:

    def test_pode_criar_pedido(self):
        # Cria o cliente
        cliente_response = client.post(
            "/clientes/",
            json={
                "nome": "João da Silva",
                "email": "joao@email.com",
            },
        )

        assert cliente_response.status_code == 201

        cliente_data = cliente_response.json()
        cliente_id = cliente_data["id"]

        # Cria o produto
        produto_response = client.post(
            "/produtos/",
            json={
                "nome": "Hambúrguer",
                "preco": 25.0,
                "quantidade_estoque": 10,
            },
        )

        assert produto_response.status_code == 201

        produto_data = produto_response.json()
        produto_id = produto_data["id"]

        # Cria o pedido
        pedido_response = client.post(
            "/pedidos/",
            json={
                "cliente_id": cliente_id,
                "itens": [
                    {
                        "produto_id": produto_id,
                        "quantidade": 2,
                    }
                ],
            },
        )

        print("STATUS:", pedido_response.status_code)
        print("BODY:", pedido_response.text)

        # Verifica se o pedido foi criado
        assert pedido_response.status_code == 201

        pedido_data = pedido_response.json()

        # Verifica os dados do pedido
        assert isinstance(UUID(pedido_data["id"]), UUID)
        assert pedido_data["cliente_id"] == cliente_id
        assert pedido_data["status"] == "PENDENTE"

        # Verifica os itens
        assert len(pedido_data["itens"]) == 1

        item = pedido_data["itens"][0]

        assert item["produto_id"] == produto_id
        assert item["preco_unitario"] == 25.0
        assert item["quantidade"] == 2
        assert item["total"] == 50.0

        # Verifica o total do pedido
        assert pedido_data["total"] == 50.0
