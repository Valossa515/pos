from uuid import UUID

from fastapi.testclient import TestClient

from app.infra.api.main import app

client = TestClient(app)


class TestCadastrarProduto:

    def test_pode_cadastrar_produto(self):
        response = client.post(
            "/produtos/",
            json={
                "nome": "Hambúrguer",
                "preco": 25.0,
                "quantidade_estoque": 10,
            },
        )

        data = response.json()

        assert response.status_code == 201
        assert isinstance(UUID(data["id"]), UUID)
        assert data["nome"] == "Hambúrguer"
        assert data["preco"] == 25.0
        assert data["quantidade_estoque"] == 10
