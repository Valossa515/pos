from uuid import UUID

from fastapi.testclient import TestClient

from app.infra.api.main import app

client = TestClient(app)


class TestCadastrarCliente:

    def test_pode_cadastrar_cliente(self):
        response = client.post(
            "/clientes/",
            json={
                "nome": "João da Silva",
                "email": "joao@email.com",
            },
        )

        data = response.json()

        assert response.status_code == 201
        assert isinstance(UUID(data["id"]), UUID)
        assert data["nome"] == "João da Silva"
        assert data["email"] == "joao@email.com"
        assert data["ativo"] is True
