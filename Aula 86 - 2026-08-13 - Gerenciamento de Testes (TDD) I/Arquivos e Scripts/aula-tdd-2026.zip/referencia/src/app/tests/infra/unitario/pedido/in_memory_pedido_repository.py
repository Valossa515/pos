from uuid import uuid4

from app.domain.pedido.pedido_entity import Pedido
from app.infra.pedido.in_memory_pedido_repository import (
    InMemoryPedidoRepository,
)


class TestInMemoryPedidoRepository:

    def test_criar_pedido(self):
        repository = InMemoryPedidoRepository()

        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        repository.criar_pedido(pedido)

        pedidos = repository.listar_pedidos()

        assert len(pedidos) == 1
        assert pedidos[0] == pedido

    def test_encontrar_pedido(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        repository = InMemoryPedidoRepository(
            pedidos=[pedido],
        )

        resultado = repository.encontrar_pedido(pedido.id)

        assert resultado == pedido

    def test_encontrar_pedido_inexistente(self):
        repository = InMemoryPedidoRepository()

        resultado = repository.encontrar_pedido(uuid4())

        assert resultado is None

    def test_listar_pedidos(self):
        pedido1 = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        pedido2 = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        repository = InMemoryPedidoRepository(
            pedidos=[pedido1, pedido2],
        )

        resultado = repository.listar_pedidos()

        assert len(resultado) == 2
        assert resultado[0] == pedido1
        assert resultado[1] == pedido2

    def test_listar_pedidos_por_cliente(self):
        cliente1_id = uuid4()
        cliente2_id = uuid4()

        pedido1 = Pedido(
            id=uuid4(),
            cliente_id=cliente1_id,
        )

        pedido2 = Pedido(
            id=uuid4(),
            cliente_id=cliente1_id,
        )

        pedido3 = Pedido(
            id=uuid4(),
            cliente_id=cliente2_id,
        )

        repository = InMemoryPedidoRepository(
            pedidos=[pedido1, pedido2, pedido3],
        )

        resultado = repository.listar_pedidos_por_cliente(cliente1_id)

        assert len(resultado) == 2
        assert pedido1 in resultado
        assert pedido2 in resultado
        assert pedido3 not in resultado

    def test_listar_pedidos_por_cliente_sem_pedidos(self):
        repository = InMemoryPedidoRepository()

        cliente_id = uuid4()

        resultado = repository.listar_pedidos_por_cliente(cliente_id)

        assert resultado == []

    def test_atualizar_pedido(self):
        cliente_id = uuid4()
        pedido_id = uuid4()

        pedido_original = Pedido(
            id=pedido_id,
            cliente_id=cliente_id,
        )

        repository = InMemoryPedidoRepository(
            pedidos=[pedido_original],
        )

        pedido_atualizado = Pedido(
            id=pedido_id,
            cliente_id=cliente_id,
        )

        repository.atualizar_pedido(pedido_atualizado)

        resultado = repository.encontrar_pedido(pedido_id)

        assert resultado == pedido_atualizado
        assert len(repository.listar_pedidos()) == 1

    def test_atualizar_pedido_inexistente(self):
        repository = InMemoryPedidoRepository()

        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        repository.atualizar_pedido(pedido)

        resultado = repository.listar_pedidos()

        assert resultado == []
