from uuid import uuid4

from app.domain.cliente.cliente_entity import Cliente
from app.domain.cliente.email_vo import Email
from app.infra.cliente.in_memory_cliente_repository import (
    InMemoryClienteRepository,
)


class TestCadastrarCliente:

    # Testa se é possível cadastrar clientes no repositório
    def test_cadastrar_clientes(self):
        repository = InMemoryClienteRepository()

        cliente1 = Cliente(
            id=uuid4(),
            nome="João",
            email=Email("joao@email.com"),
        )

        cliente2 = Cliente(
            id=uuid4(),
            nome="Maria",
            email=Email("maria@email.com"),
        )

        repository.cadastrar_cliente(cliente1)
        repository.cadastrar_cliente(cliente2)

        # Verifica se os dois clientes foram cadastrados
        assert len(repository.clientes) == 2
        assert repository.clientes[0] == cliente1
        assert repository.clientes[1] == cliente2


class TestEncontrarCliente:

    # Testa se é possível buscar um cliente pelo ID
    def test_encontrar_cliente_por_id(self):
        repository = InMemoryClienteRepository()

        cliente1 = Cliente(
            id=uuid4(),
            nome="João",
            email=Email("joao@email.com"),
        )

        cliente2 = Cliente(
            id=uuid4(),
            nome="Maria",
            email=Email("maria@email.com"),
        )

        repository.cadastrar_cliente(cliente1)
        repository.cadastrar_cliente(cliente2)

        cliente = repository.encontrar_cliente(cliente2.id)

        # Verifica se o cliente encontrado é o correto
        assert cliente == cliente2

    # Testa se retorna None quando o cliente não existe
    def test_cliente_nao_existente_deve_retornar_none(self):
        repository = InMemoryClienteRepository()

        cliente1 = Cliente(
            id=uuid4(),
            nome="João",
            email=Email("joao@email.com"),
        )

        cliente2 = Cliente(
            id=uuid4(),
            nome="Maria",
            email=Email("maria@email.com"),
        )

        repository.cadastrar_cliente(cliente1)
        repository.cadastrar_cliente(cliente2)

        cliente = repository.encontrar_cliente(uuid4())

        # Verifica se nenhum cliente foi encontrado
        assert cliente is None


class TestListarClientes:

    # Testa se é possível listar todos os clientes
    def test_listar_clientes(self):
        repository = InMemoryClienteRepository()

        cliente1 = Cliente(
            id=uuid4(),
            nome="João",
            email=Email("joao@email.com"),
        )

        cliente2 = Cliente(
            id=uuid4(),
            nome="Maria",
            email=Email("maria@email.com"),
        )

        repository.cadastrar_cliente(cliente1)
        repository.cadastrar_cliente(cliente2)

        clientes = repository.listar_clientes()

        # Verifica se todos os clientes foram retornados
        assert len(clientes) == 2
        assert clientes[0] == cliente1
        assert clientes[1] == cliente2


class TestAtualizarCliente:

    # Testa se é possível atualizar um cliente existente
    def test_atualizar_cliente(self):
        repository = InMemoryClienteRepository()

        cliente1 = Cliente(
            id=uuid4(),
            nome="João",
            email=Email("joao@email.com"),
        )

        cliente2 = Cliente(
            id=uuid4(),
            nome="Maria",
            email=Email("maria@email.com"),
        )

        repository.cadastrar_cliente(cliente1)
        repository.cadastrar_cliente(cliente2)

        # Atualiza o nome do primeiro cliente
        cliente1.nome = "Alexandre"

        repository.atualizar_cliente(cliente1)

        # Verifica se ainda existem dois clientes
        assert len(repository.clientes) == 2

        cliente_atualizado = repository.encontrar_cliente(cliente1.id)

        assert cliente_atualizado.nome == "Alexandre"

    # Testa se atualizar cliente inexistente não gera erro
    def test_atualizar_cliente_inexistente(self):
        repository = InMemoryClienteRepository()

        cliente = Cliente(
            id=uuid4(),
            nome="João",
            email=Email("joao@email.com"),
        )

        repository.atualizar_cliente(cliente)

        # O repositório deve continuar vazio
        assert len(repository.clientes) == 0


class TestExcluirCliente:

    # Testa se é possível excluir um cliente pelo ID
    def test_excluir_cliente(self):
        repository = InMemoryClienteRepository()

        cliente1 = Cliente(
            id=uuid4(),
            nome="João",
            email=Email("joao@email.com"),
        )

        cliente2 = Cliente(
            id=uuid4(),
            nome="Maria",
            email=Email("maria@email.com"),
        )

        repository.cadastrar_cliente(cliente1)
        repository.cadastrar_cliente(cliente2)

        repository.excluir_cliente(cliente1.id)

        # Verifica se apenas o segundo cliente permanece
        assert len(repository.clientes) == 1
        assert repository.clientes[0] == cliente2

    # Testa se excluir um cliente inexistente não gera erro
    def test_excluir_cliente_inexistente(self):
        repository = InMemoryClienteRepository()

        cliente = Cliente(
            id=uuid4(),
            nome="João",
            email=Email("joao@email.com"),
        )

        repository.cadastrar_cliente(cliente)

        repository.excluir_cliente(uuid4())

        # O cliente existente deve permanecer
        assert len(repository.clientes) == 1
        assert repository.clientes[0] == cliente
