from fastapi.testclient import TestClient

from app.infra.api.main import app

client = TestClient(app)


class TestCancelarPedido:

    def test_pode_cancelar_pedido(self):
        # Cria o cliente
        cliente_response = client.post(
            "/clientes/",
            json={
                "nome": "João da Silva",
                "email": "joao@email.com",
            },
        )

        assert cliente_response.status_code == 201

        cliente_id = cliente_response.json()["id"]

        # Cria o produto
        produto_response = client.post(
            "/produtos/",
            json={
                "nome": "Hambúrguer",
                "preco": 25.0,
                "quantidade_estoque": 10,
            },
        )

        assert produto_response.status_code == 201

        produto_id = produto_response.json()["id"]

        # Cria o pedido
        pedido_response = client.post(
            "/pedidos/",
            json={
                "cliente_id": cliente_id,
                "itens": [
                    {
                        "produto_id": produto_id,
                        "quantidade": 2,
                    }
                ],
            },
        )

        assert pedido_response.status_code == 201

        pedido_id = pedido_response.json()["id"]

        # Cancela o pedido
        cancelamento_response = client.post(
            f"/pedidos/{pedido_id}/cancelar",
        )

        cancelamento_data = cancelamento_response.json()

        assert cancelamento_response.status_code == 200
        assert cancelamento_data["status"] == "CANCELADO"
