from uuid import UUID

from fastapi.testclient import TestClient

from app.infra.api.main import app

client = TestClient(app)


class TestListarCliente:

    def test_pode_listar_clientes(self):
        # Cria um cliente
        criar_response = client.post(
            "/clientes/",
            json={
                "nome": "João da Silva",
                "email": "joao@email.com",
            },
        )

        assert criar_response.status_code == 201

        cliente_criado = criar_response.json()
        cliente_id = cliente_criado["id"]

        # Lista os clientes
        listar_response = client.get("/clientes/")

        assert listar_response.status_code == 200

        data = listar_response.json()

        assert "clientes" in data
        assert isinstance(data["clientes"], list)
        assert len(data["clientes"]) >= 1

        # Procura exatamente o cliente que acabamos de criar
        cliente = next(
            cliente for cliente in data["clientes"] if cliente["id"] == cliente_id
        )

        assert isinstance(UUID(cliente["id"]), UUID)
        assert cliente["nome"] == "João da Silva"
        assert cliente["email"] == "joao@email.com"
        assert cliente["ativo"] is True
