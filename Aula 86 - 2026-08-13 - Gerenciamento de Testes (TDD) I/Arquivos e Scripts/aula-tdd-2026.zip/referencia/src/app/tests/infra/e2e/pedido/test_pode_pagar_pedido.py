from fastapi.testclient import TestClient

from app.infra.api.main import app

client = TestClient(app)


class TestPagarPedido:

    def test_pode_pagar_pedido(self):
        # Cria o cliente
        cliente_response = client.post(
            "/clientes/",
            json={
                "nome": "João da Silva",
                "email": "joao@email.com",
            },
        )

        assert cliente_response.status_code == 201

        cliente_id = cliente_response.json()["id"]

        # Cria o produto
        produto_response = client.post(
            "/produtos/",
            json={
                "nome": "Hambúrguer",
                "preco": 25.0,
                "quantidade_estoque": 10,
            },
        )

        assert produto_response.status_code == 201

        produto_id = produto_response.json()["id"]

        # Cria o pedido
        pedido_response = client.post(
            "/pedidos/",
            json={
                "cliente_id": cliente_id,
                "itens": [
                    {
                        "produto_id": produto_id,
                        "quantidade": 2,
                    }
                ],
            },
        )

        assert pedido_response.status_code == 201

        pedido_id = pedido_response.json()["id"]

        # Paga o pedido
        pagamento_response = client.post(
            f"/pedidos/{pedido_id}/pagar",
            params={
                "valor_pago": 50.0,
            },
        )

        pagamento_data = pagamento_response.json()

        assert pagamento_response.status_code == 200
        assert pagamento_data["status"] == "PAGO"
