from uuid import uuid4

from app.domain.produto.produto_entity import Produto
from app.infra.produto.in_memory_produto_repository import (
    InMemoryProdutoRepository,
)


class TestCadastrarProduto:

    # Testa se é possível cadastrar produtos no repositório
    def test_cadastrar_produtos(self):
        repository = InMemoryProdutoRepository()

        produto1 = Produto(
            id=uuid4(),
            nome="Hambúrguer",
            preco=25.0,
            quantidade_estoque=10,
        )

        produto2 = Produto(
            id=uuid4(),
            nome="Batata Frita",
            preco=15.0,
            quantidade_estoque=20,
        )

        repository.cadastrar_produto(produto1)
        repository.cadastrar_produto(produto2)

        produtos = repository.listar_produtos()

        # Verifica se os dois produtos foram cadastrados
        assert len(produtos) == 2
        assert produtos[0] == produto1
        assert produtos[1] == produto2


class TestEncontrarProduto:

    # Testa se é possível buscar um produto pelo ID
    def test_encontrar_produto_por_id(self):
        repository = InMemoryProdutoRepository()

        produto1 = Produto(
            id=uuid4(),
            nome="Hambúrguer",
            preco=25.0,
            quantidade_estoque=10,
        )

        produto2 = Produto(
            id=uuid4(),
            nome="Batata Frita",
            preco=15.0,
            quantidade_estoque=20,
        )

        repository.cadastrar_produto(produto1)
        repository.cadastrar_produto(produto2)

        produto = repository.encontrar_produto(produto2.id)

        # Verifica se o produto encontrado é o correto
        assert produto == produto2

    # Testa se retorna None quando o produto não existe
    def test_produto_nao_existente_deve_retornar_none(self):
        repository = InMemoryProdutoRepository()

        produto1 = Produto(
            id=uuid4(),
            nome="Hambúrguer",
            preco=25.0,
            quantidade_estoque=10,
        )

        produto2 = Produto(
            id=uuid4(),
            nome="Batata Frita",
            preco=15.0,
            quantidade_estoque=20,
        )

        repository.cadastrar_produto(produto1)
        repository.cadastrar_produto(produto2)

        produto = repository.encontrar_produto(uuid4())

        # Verifica se nenhum produto foi encontrado
        assert produto is None


class TestListarProdutos:

    # Testa se é possível listar todos os produtos
    def test_listar_produtos(self):
        repository = InMemoryProdutoRepository()

        produto1 = Produto(
            id=uuid4(),
            nome="Hambúrguer",
            preco=25.0,
            quantidade_estoque=10,
        )

        produto2 = Produto(
            id=uuid4(),
            nome="Batata Frita",
            preco=15.0,
            quantidade_estoque=20,
        )

        repository.cadastrar_produto(produto1)
        repository.cadastrar_produto(produto2)

        produtos = repository.listar_produtos()

        # Verifica se todos os produtos foram retornados
        assert len(produtos) == 2
        assert produtos[0] == produto1
        assert produtos[1] == produto2


class TestAtualizarProduto:

    # Testa se é possível atualizar um produto existente
    def test_atualizar_produto(self):
        repository = InMemoryProdutoRepository()

        produto1 = Produto(
            id=uuid4(),
            nome="Hambúrguer",
            preco=25.0,
            quantidade_estoque=10,
        )

        produto2 = Produto(
            id=uuid4(),
            nome="Batata Frita",
            preco=15.0,
            quantidade_estoque=20,
        )

        repository.cadastrar_produto(produto1)
        repository.cadastrar_produto(produto2)

        # Atualiza os dados do primeiro produto
        produto1.nome = "Hambúrguer Especial"
        produto1.preco = 30.0
        produto1.quantidade_estoque = 15

        repository.atualizar_produto(produto1)

        produtos = repository.listar_produtos()

        # Verifica se ainda existem dois produtos
        assert len(produtos) == 2

        produto_atualizado = repository.encontrar_produto(produto1.id)

        assert produto_atualizado is not None
        assert produto_atualizado.nome == "Hambúrguer Especial"
        assert produto_atualizado.preco == 30.0
        assert produto_atualizado.quantidade_estoque == 15

    # Testa se atualizar produto inexistente não gera erro
    def test_atualizar_produto_inexistente(self):
        repository = InMemoryProdutoRepository()

        produto = Produto(
            id=uuid4(),
            nome="Hambúrguer",
            preco=25.0,
            quantidade_estoque=10,
        )

        repository.atualizar_produto(produto)

        # O repositório deve continuar vazio
        assert len(repository.listar_produtos()) == 0


class TestExcluirProduto:

    # Testa se é possível excluir um produto pelo ID
    def test_excluir_produto(self):
        repository = InMemoryProdutoRepository()

        produto1 = Produto(
            id=uuid4(),
            nome="Hambúrguer",
            preco=25.0,
            quantidade_estoque=10,
        )

        produto2 = Produto(
            id=uuid4(),
            nome="Batata Frita",
            preco=15.0,
            quantidade_estoque=20,
        )

        repository.cadastrar_produto(produto1)
        repository.cadastrar_produto(produto2)

        repository.excluir_produto(produto1.id)

        produtos = repository.listar_produtos()

        # Verifica se apenas o segundo produto permanece
        assert len(produtos) == 1
        assert produtos[0] == produto2

    # Testa se excluir um produto inexistente não gera erro
    def test_excluir_produto_inexistente(self):
        repository = InMemoryProdutoRepository()

        produto = Produto(
            id=uuid4(),
            nome="Hambúrguer",
            preco=25.0,
            quantidade_estoque=10,
        )

        repository.cadastrar_produto(produto)

        repository.excluir_produto(produto.id)

        produtos = repository.listar_produtos()

        # O produto existente deve permanecer
        assert len(produtos) == 1
        assert produtos[0] == produto
