from unittest.mock import MagicMock
from uuid import UUID

from app.application.produto.cadastrar_produto.cadastrar_produto_dto import (
    CadastrarProdutoInputDto,
    CadastrarProdutoOutputDto,
)
from app.application.produto.cadastrar_produto.cadastrar_produto_usecase import (
    CadastrarProdutoUseCase,
)
from app.domain.produto.produto_repository_interface import (
    ProdutoRepositoryInterface,
)


class TestCadastrarProduto:

    def test_cadastrar_produto_com_dados_validos(self):
        repositorio = MagicMock(spec=ProdutoRepositoryInterface)

        caso_de_uso = CadastrarProdutoUseCase(
            produto_repository=repositorio,
        )

        input_dto = CadastrarProdutoInputDto(
            nome="Hambúrguer",
            preco=25.0,
            quantidade_estoque=10,
        )

        output = caso_de_uso.executar(input_dto)

        assert isinstance(output, CadastrarProdutoOutputDto)
        assert isinstance(output.id, UUID)

        assert output.nome == "Hambúrguer"
        assert output.preco == 25.0
        assert output.quantidade_estoque == 10

        repositorio.cadastrar_produto.assert_called_once()

    def test_deve_cadastrar_o_produto_no_repositorio(self):
        repositorio = MagicMock(spec=ProdutoRepositoryInterface)

        caso_de_uso = CadastrarProdutoUseCase(
            produto_repository=repositorio,
        )

        input_dto = CadastrarProdutoInputDto(
            nome="Hambúrguer",
            preco=25.0,
            quantidade_estoque=10,
        )

        caso_de_uso.executar(input_dto)

        produto_cadastrado = repositorio.cadastrar_produto.call_args[0][0]

        assert produto_cadastrado.nome == "Hambúrguer"
        assert produto_cadastrado.preco == 25.0
        assert produto_cadastrado.quantidade_estoque == 10
