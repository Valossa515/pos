from unittest.mock import MagicMock
from uuid import uuid4

from app.application.cliente.excluir_cliente.excluir_cliente_dto import (
    ExcluirClienteInputDto,
)
from app.application.cliente.excluir_cliente.excluir_cliente_usecase import (
    ExcluirClienteUseCase,
)
from app.domain.cliente.cliente_entity import Cliente
from app.domain.cliente.cliente_repository_interface import (
    ClienteRepositoryInterface,
)
from app.domain.cliente.email_vo import Email


class TestExcluirCliente:

    def test_excluir_cliente(self):
        cliente_id = uuid4()

        cliente = Cliente(
            id=cliente_id,
            nome="João da Silva",
            email=Email("joao@email.com"),
        )

        repositorio = MagicMock(spec=ClienteRepositoryInterface)

        repositorio.encontrar_cliente.return_value = cliente

        caso_de_uso = ExcluirClienteUseCase(
            cliente_repository=repositorio,
        )

        input_dto = ExcluirClienteInputDto(
            id=cliente_id,
        )

        caso_de_uso.executar(input_dto)

        repositorio.encontrar_cliente.assert_called_once_with(cliente_id)

        repositorio.excluir_cliente.assert_called_once_with(cliente_id)

    def test_excluir_cliente_inexistente(self):
        cliente_id = uuid4()

        repositorio = MagicMock(spec=ClienteRepositoryInterface)

        repositorio.encontrar_cliente.return_value = None

        caso_de_uso = ExcluirClienteUseCase(
            cliente_repository=repositorio,
        )

        input_dto = ExcluirClienteInputDto(
            id=cliente_id,
        )

        try:
            caso_de_uso.executar(input_dto)
            assert False
        except ValueError:
            pass

        repositorio.excluir_cliente.assert_not_called()
