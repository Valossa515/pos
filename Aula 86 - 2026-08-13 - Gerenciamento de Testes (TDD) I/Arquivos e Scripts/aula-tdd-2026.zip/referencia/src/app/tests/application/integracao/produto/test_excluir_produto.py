import pytest
from uuid import uuid4

from app.application.produto.cadastrar_produto.cadastrar_produto_dto import (
    CadastrarProdutoInputDto,
)
from app.application.produto.cadastrar_produto.cadastrar_produto_usecase import (
    CadastrarProdutoUseCase,
)
from app.application.produto.excluir_produto.excluir_produto_dto import (
    ExcluirProdutoInputDto,
)
from app.application.produto.excluir_produto.excluir_produto_usecase import (
    ExcluirProdutoUseCase,
)
from app.infra.produto.in_memory_produto_repository import (
    InMemoryProdutoRepository,
)


class TestExcluirProduto:

    def test_excluir_produto(self):
        repositorio = InMemoryProdutoRepository()

        cadastrar_produto = CadastrarProdutoUseCase(
            produto_repository=repositorio,
        )

        produto = cadastrar_produto.executar(
            CadastrarProdutoInputDto(
                nome="Hambúrguer",
                preco=25.0,
                quantidade_estoque=10,
            )
        )

        excluir_produto = ExcluirProdutoUseCase(
            produto_repository=repositorio,
        )

        input_dto = ExcluirProdutoInputDto(
            id=produto.id,
        )

        excluir_produto.executar(input_dto)

        produto_excluido = repositorio.encontrar_produto(produto.id)

        assert produto_excluido is None

        assert len(repositorio.listar_produtos()) == 0

    def test_excluir_produto_inexistente(self):
        repositorio = InMemoryProdutoRepository()

        caso_de_uso = ExcluirProdutoUseCase(
            produto_repository=repositorio,
        )

        input_dto = ExcluirProdutoInputDto(
            id=uuid4(),
        )

        with pytest.raises(
            ValueError,
            match="Produto não encontrado.",
        ):
            caso_de_uso.executar(input_dto)
