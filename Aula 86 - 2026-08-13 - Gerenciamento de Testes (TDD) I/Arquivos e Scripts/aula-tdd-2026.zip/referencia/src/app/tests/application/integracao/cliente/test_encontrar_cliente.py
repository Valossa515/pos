from uuid import uuid4

import pytest

from app.application.cliente.cadastrar_cliente.cadastrar_cliente_dto import (
    CadastrarClienteInputDto,
)
from app.application.cliente.cadastrar_cliente.cadastrar_cliente_usecase import (
    CadastrarClienteUseCase,
)
from app.application.cliente.encontrar_cliente.encontrar_cliente_dto import (
    EncontrarClienteInputDto,
)
from app.application.cliente.encontrar_cliente.encontrar_cliente_usecase import (
    EncontrarClienteUseCase,
)
from app.infra.cliente.in_memory_cliente_repository import (
    InMemoryClienteRepository,
)


class TestEncontrarCliente:

    def test_encontrar_cliente_existente(self):
        repositorio = InMemoryClienteRepository()

        cadastrar_cliente = CadastrarClienteUseCase(
            cliente_repository=repositorio,
        )

        cliente = cadastrar_cliente.executar(
            CadastrarClienteInputDto(
                nome="João da Silva",
                email="joao@email.com",
            )
        )

        caso_de_uso = EncontrarClienteUseCase(
            cliente_repository=repositorio,
        )

        input_dto = EncontrarClienteInputDto(
            id=cliente.id,
        )

        output = caso_de_uso.executar(input_dto)

        assert output.id == cliente.id
        assert output.nome == "João da Silva"
        assert output.email == "joao@email.com"
        assert output.ativo is True

    def test_encontrar_cliente_inexistente(self):
        repositorio = InMemoryClienteRepository()

        caso_de_uso = EncontrarClienteUseCase(
            cliente_repository=repositorio,
        )

        input_dto = EncontrarClienteInputDto(
            id=uuid4(),
        )

        with pytest.raises(ValueError):
            caso_de_uso.executar(input_dto)
