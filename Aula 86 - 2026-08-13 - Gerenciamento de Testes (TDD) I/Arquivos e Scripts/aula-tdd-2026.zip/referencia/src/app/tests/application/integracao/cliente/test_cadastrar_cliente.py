import pytest
from uuid import UUID

from app.application.cliente.cadastrar_cliente.cadastrar_cliente_dto import (
    CadastrarClienteInputDto,
)
from app.application.cliente.cadastrar_cliente.cadastrar_cliente_usecase import (
    CadastrarClienteUseCase,
)
from app.infra.cliente.in_memory_cliente_repository import (
    InMemoryClienteRepository,
)


class TestCadastrarCliente:

    def test_cadastrar_cliente_com_dados_validos(self):
        repositorio = InMemoryClienteRepository()

        caso_de_uso = CadastrarClienteUseCase(
            cliente_repository=repositorio,
        )

        input_dto = CadastrarClienteInputDto(
            nome="João da Silva",
            email="joao@email.com",
        )

        output = caso_de_uso.executar(input_dto)

        assert output is not None
        assert isinstance(output.id, UUID)

        cliente_persistido = repositorio.encontrar_cliente(output.id)

        assert cliente_persistido is not None
        assert cliente_persistido.id == output.id
        assert cliente_persistido.nome == "João da Silva"
        assert cliente_persistido.email.valor == "joao@email.com"
        assert cliente_persistido.ativo is True

    def test_cadastrar_cliente_com_nome_invalido(self):
        repositorio = InMemoryClienteRepository()

        caso_de_uso = CadastrarClienteUseCase(
            cliente_repository=repositorio,
        )

        input_dto = CadastrarClienteInputDto(
            nome="",
            email="joao@email.com",
        )

        with pytest.raises(
            ValueError,
            match="O nome do cliente é obrigatório.",
        ):
            caso_de_uso.executar(input_dto)

        assert len(repositorio.listar_clientes()) == 0

    def test_cadastrar_cliente_com_email_invalido(self):
        repositorio = InMemoryClienteRepository()

        caso_de_uso = CadastrarClienteUseCase(
            cliente_repository=repositorio,
        )

        input_dto = CadastrarClienteInputDto(
            nome="João da Silva",
            email="email-invalido",
        )

        with pytest.raises(
            ValueError,
            match="E-mail inválido.",
        ):
            caso_de_uso.executar(input_dto)

        assert len(repositorio.listar_clientes()) == 0
