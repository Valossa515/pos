import pytest
from unittest.mock import MagicMock
from uuid import uuid4

from app.application.produto.encontrar_produto.encontrar_produto_dto import (
    EncontrarProdutoInputDto,
)
from app.application.produto.encontrar_produto.encontrar_produto_usecase import (
    EncontrarProdutoUseCase,
)
from app.domain.produto.produto_entity import Produto
from app.domain.produto.produto_repository_interface import (
    ProdutoRepositoryInterface,
)


class TestEncontrarProduto:

    def test_encontrar_produto_existente(self):
        produto_id = uuid4()

        produto = Produto(
            id=produto_id,
            nome="Hambúrguer",
            preco=25.0,
            quantidade_estoque=10,
        )

        repositorio = MagicMock(spec=ProdutoRepositoryInterface)

        repositorio.encontrar_produto.return_value = produto

        caso_de_uso = EncontrarProdutoUseCase(
            produto_repository=repositorio,
        )

        input_dto = EncontrarProdutoInputDto(
            id=produto_id,
        )

        output = caso_de_uso.executar(input_dto)

        assert output.id == produto_id
        assert output.nome == "Hambúrguer"
        assert output.preco == 25.0
        assert output.quantidade_estoque == 10

        repositorio.encontrar_produto.assert_called_once_with(produto_id)

    def test_encontrar_produto_inexistente(self):
        produto_id = uuid4()

        repositorio = MagicMock(spec=ProdutoRepositoryInterface)

        repositorio.encontrar_produto.return_value = None

        caso_de_uso = EncontrarProdutoUseCase(
            produto_repository=repositorio,
        )

        input_dto = EncontrarProdutoInputDto(
            id=produto_id,
        )

        with pytest.raises(
            ValueError,
            match="Produto não encontrado.",
        ):
            caso_de_uso.executar(input_dto)
