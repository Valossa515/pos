from uuid import UUID, uuid4

from app.application.pedido.criar_pedido.criar_pedido_usecase import (
    CriarPedidoUseCase,
)

from app.application.pedido.criar_pedido.criar_pedido_dto import (
    CriarPedidoInputDto,
)

from app.domain.cliente.cliente_entity import Cliente
from app.domain.cliente.email_vo import Email
from app.domain.produto.produto_entity import Produto

from app.infra.cliente.in_memory_cliente_repository import (
    InMemoryClienteRepository,
)

from app.infra.produto.in_memory_produto_repository import (
    InMemoryProdutoRepository,
)

from app.infra.pedido.in_memory_pedido_repository import (
    InMemoryPedidoRepository,
)


class TestCriarPedido:

    def test_criar_pedido_com_dados_validos(self):
        cliente_repository = InMemoryClienteRepository()
        produto_repository = InMemoryProdutoRepository()
        pedido_repository = InMemoryPedidoRepository()

        cliente = Cliente(
            id=uuid4(),
            nome="João da Silva",
            email=Email("joao@email.com"),
        )

        produto = Produto(
            id=uuid4(),
            nome="Notebook",
            preco=2500.00,
            quantidade_estoque=10,
        )

        cliente_repository.cadastrar_cliente(cliente)
        produto_repository.cadastrar_produto(produto)

        use_case = CriarPedidoUseCase(
            pedido_repository=pedido_repository,
            cliente_repository=cliente_repository,
            produto_repository=produto_repository,
        )

        input_dto = CriarPedidoInputDto(
            cliente_id=cliente.id,
            itens=[
                {
                    "produto_id": produto.id,
                    "quantidade": 2,
                }
            ],
        )

        response = use_case.executar(input_dto)

        assert response is not None
        assert isinstance(response.id, UUID)

        assert response.cliente_id == cliente.id
        assert response.status == "PENDENTE"

        assert response.total == 5000.00

        assert len(response.itens) == 1

        item = response.itens[0]

        assert item.produto_id == produto.id
        assert item.preco_unitario == 2500.00
        assert item.quantidade == 2
        assert item.total == 5000.00

        # Verifica se o pedido realmente foi persistido
        pedidos = pedido_repository.listar_pedidos()

        assert len(pedidos) == 1

        pedido_persistido = pedidos[0]

        assert pedido_persistido.id == response.id
        assert pedido_persistido.cliente_id == cliente.id

        assert len(pedido_persistido.itens) == 1

        item_persistido = pedido_persistido.itens[0]

        assert item_persistido.produto_id == produto.id
        assert item_persistido.preco_unitario == 2500.00
        assert item_persistido.quantidade == 2
