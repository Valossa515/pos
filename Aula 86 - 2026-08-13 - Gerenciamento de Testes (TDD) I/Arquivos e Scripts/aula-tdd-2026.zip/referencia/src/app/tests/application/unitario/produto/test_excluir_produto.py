import pytest
from unittest.mock import MagicMock
from uuid import uuid4

from app.application.produto.excluir_produto.excluir_produto_dto import (
    ExcluirProdutoInputDto,
)
from app.application.produto.excluir_produto.excluir_produto_usecase import (
    ExcluirProdutoUseCase,
)
from app.domain.produto.produto_entity import Produto
from app.domain.produto.produto_repository_interface import (
    ProdutoRepositoryInterface,
)


class TestExcluirProduto:

    def test_excluir_produto(self):
        produto_id = uuid4()

        produto = Produto(
            id=produto_id,
            nome="Hambúrguer",
            preco=25.0,
            quantidade_estoque=10,
        )

        repositorio = MagicMock(spec=ProdutoRepositoryInterface)

        repositorio.encontrar_produto.return_value = produto

        caso_de_uso = ExcluirProdutoUseCase(
            produto_repository=repositorio,
        )

        input_dto = ExcluirProdutoInputDto(
            id=produto_id,
        )

        caso_de_uso.executar(input_dto)

        repositorio.encontrar_produto.assert_called_once_with(produto_id)

        repositorio.excluir_produto.assert_called_once_with(produto_id)

    def test_excluir_produto_inexistente(self):
        produto_id = uuid4()

        repositorio = MagicMock(spec=ProdutoRepositoryInterface)

        repositorio.encontrar_produto.return_value = None

        caso_de_uso = ExcluirProdutoUseCase(
            produto_repository=repositorio,
        )

        input_dto = ExcluirProdutoInputDto(
            id=produto_id,
        )

        with pytest.raises(
            ValueError,
            match="Produto não encontrado.",
        ):
            caso_de_uso.executar(input_dto)

        repositorio.excluir_produto.assert_not_called()
