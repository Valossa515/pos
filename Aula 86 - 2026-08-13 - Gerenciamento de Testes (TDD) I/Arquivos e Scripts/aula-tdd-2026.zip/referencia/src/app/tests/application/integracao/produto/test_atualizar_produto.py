from app.application.produto.atualizar_produto.atualizar_produto_dto import (
    AtualizarProdutoInputDto,
)
from app.application.produto.atualizar_produto.atualizar_produto_usecase import (
    AtualizarProdutoUseCase,
)
from app.application.produto.cadastrar_produto.cadastrar_produto_dto import (
    CadastrarProdutoInputDto,
)
from app.application.produto.cadastrar_produto.cadastrar_produto_usecase import (
    CadastrarProdutoUseCase,
)
from app.infra.produto.in_memory_produto_repository import (
    InMemoryProdutoRepository,
)


class TestAtualizarProduto:

    def test_atualizar_produto_com_dados_validos(self):
        repositorio = InMemoryProdutoRepository()

        cadastrar_produto = CadastrarProdutoUseCase(
            produto_repository=repositorio,
        )

        produto = cadastrar_produto.executar(
            CadastrarProdutoInputDto(
                nome="Hambúrguer",
                preco=25.0,
                quantidade_estoque=10,
            )
        )

        atualizar_produto = AtualizarProdutoUseCase(
            produto_repository=repositorio,
        )

        input_dto = AtualizarProdutoInputDto(
            id=produto.id,
            nome="Hambúrguer Especial",
            preco=30.0,
            quantidade_estoque=20,
        )

        output = atualizar_produto.executar(input_dto)

        produto_atualizado = repositorio.encontrar_produto(produto.id)

        assert output.id == produto.id
        assert output.nome == "Hambúrguer Especial"
        assert output.preco == 30.0
        assert output.quantidade_estoque == 20

        assert produto_atualizado is not None
        assert produto_atualizado.nome == "Hambúrguer Especial"
        assert produto_atualizado.preco == 30.0
        assert produto_atualizado.quantidade_estoque == 20

    def test_atualizar_produto_inexistente(self):
        import pytest
        from uuid import uuid4

        repositorio = InMemoryProdutoRepository()

        caso_de_uso = AtualizarProdutoUseCase(
            produto_repository=repositorio,
        )

        input_dto = AtualizarProdutoInputDto(
            id=uuid4(),
            nome="Hambúrguer",
            preco=25.0,
            quantidade_estoque=10,
        )

        with pytest.raises(
            ValueError,
            match="Produto não encontrado.",
        ):
            caso_de_uso.executar(input_dto)

        assert len(repositorio.listar_produtos()) == 0
