from uuid import UUID

from app.application.produto.cadastrar_produto.cadastrar_produto_dto import (
    CadastrarProdutoInputDto,
)
from app.application.produto.cadastrar_produto.cadastrar_produto_usecase import (
    CadastrarProdutoUseCase,
)
from app.infra.produto.in_memory_produto_repository import (
    InMemoryProdutoRepository,
)


class TestCadastrarProduto:

    def test_cadastrar_produto_com_dados_validos(self):
        repositorio = InMemoryProdutoRepository()

        caso_de_uso = CadastrarProdutoUseCase(
            produto_repository=repositorio,
        )

        input_dto = CadastrarProdutoInputDto(
            nome="Hambúrguer",
            preco=25.0,
            quantidade_estoque=10,
        )

        output = caso_de_uso.executar(input_dto)

        assert output is not None
        assert isinstance(output.id, UUID)

        produto_persistido = repositorio.encontrar_produto(output.id)

        assert produto_persistido is not None
        assert produto_persistido.id == output.id
        assert produto_persistido.nome == "Hambúrguer"
        assert produto_persistido.preco == 25.0
        assert produto_persistido.quantidade_estoque == 10

    def test_cadastrar_produto_deve_adicionar_produto_na_lista(self):
        repositorio = InMemoryProdutoRepository()

        caso_de_uso = CadastrarProdutoUseCase(
            produto_repository=repositorio,
        )

        input_dto = CadastrarProdutoInputDto(
            nome="Batata Frita",
            preco=15.0,
            quantidade_estoque=20,
        )

        output = caso_de_uso.executar(input_dto)

        produtos = repositorio.listar_produtos()

        assert len(produtos) == 1
        assert produtos[0].id == output.id
        assert produtos[0].nome == "Batata Frita"
        assert produtos[0].preco == 15.0
        assert produtos[0].quantidade_estoque == 20
