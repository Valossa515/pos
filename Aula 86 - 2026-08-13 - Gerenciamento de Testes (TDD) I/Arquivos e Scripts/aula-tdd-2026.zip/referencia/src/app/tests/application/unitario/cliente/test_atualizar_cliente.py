from unittest.mock import MagicMock

from app.application.cliente.atualizar_cliente.atualizar_cliente_dto import (
    AtualizarClienteInputDto,
)
from app.application.cliente.atualizar_cliente.atualizar_cliente_usecase import (
    AtualizarClienteUseCase,
)
from app.domain.cliente.cliente_entity import Cliente
from app.domain.cliente.cliente_repository_interface import (
    ClienteRepositoryInterface,
)
from app.domain.cliente.email_vo import Email

from uuid import uuid4


class TestAtualizarCliente:

    def test_atualizar_cliente_com_dados_validos(self):
        cliente_id = uuid4()

        cliente = Cliente(
            id=cliente_id,
            nome="João da Silva",
            email=Email("joao@email.com"),
        )

        repositorio = MagicMock(spec=ClienteRepositoryInterface)

        repositorio.encontrar_cliente.return_value = cliente

        caso_de_uso = AtualizarClienteUseCase(
            cliente_repository=repositorio,
        )

        input_dto = AtualizarClienteInputDto(
            id=cliente_id,
            nome="João Santos",
            email="joao.santos@email.com",
        )

        output = caso_de_uso.executar(input_dto)

        assert output.id == cliente_id
        assert output.nome == "João Santos"
        assert output.email == "joao.santos@email.com"

        repositorio.encontrar_cliente.assert_called_once_with(cliente_id)

        repositorio.atualizar_cliente.assert_called_once()

    def test_atualizar_cliente_inexistente(self):
        cliente_id = uuid4()

        repositorio = MagicMock(spec=ClienteRepositoryInterface)

        repositorio.encontrar_cliente.return_value = None

        caso_de_uso = AtualizarClienteUseCase(
            cliente_repository=repositorio,
        )

        input_dto = AtualizarClienteInputDto(
            id=cliente_id,
            nome="João Santos",
            email="joao.santos@email.com",
        )

        try:
            caso_de_uso.executar(input_dto)
            assert False
        except ValueError:
            pass

        repositorio.atualizar_cliente.assert_not_called()
