from unittest.mock import MagicMock
from uuid import uuid4

from app.application.cliente.encontrar_cliente.encontrar_cliente_dto import (
    EncontrarClienteInputDto,
)
from app.application.cliente.encontrar_cliente.encontrar_cliente_usecase import (
    EncontrarClienteUseCase,
)
from app.domain.cliente.cliente_entity import Cliente
from app.domain.cliente.cliente_repository_interface import (
    ClienteRepositoryInterface,
)
from app.domain.cliente.email_vo import Email


class TestEncontrarCliente:

    def test_encontrar_cliente_existente(self):
        cliente_id = uuid4()

        cliente = Cliente(
            id=cliente_id,
            nome="João da Silva",
            email=Email("joao@email.com"),
        )

        repositorio = MagicMock(spec=ClienteRepositoryInterface)

        repositorio.encontrar_cliente.return_value = cliente

        caso_de_uso = EncontrarClienteUseCase(
            cliente_repository=repositorio,
        )

        input_dto = EncontrarClienteInputDto(
            id=cliente_id,
        )

        output = caso_de_uso.executar(input_dto)

        assert output.id == cliente_id
        assert output.nome == "João da Silva"
        assert output.email == "joao@email.com"
        assert output.ativo is True

        repositorio.encontrar_cliente.assert_called_once_with(cliente_id)

    def test_encontrar_cliente_inexistente(self):
        cliente_id = uuid4()

        repositorio = MagicMock(spec=ClienteRepositoryInterface)

        repositorio.encontrar_cliente.return_value = None

        caso_de_uso = EncontrarClienteUseCase(
            cliente_repository=repositorio,
        )

        input_dto = EncontrarClienteInputDto(
            id=cliente_id,
        )

        try:
            caso_de_uso.executar(input_dto)
            assert False
        except ValueError:
            pass
