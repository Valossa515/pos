from uuid import uuid4

from app.application.pedido.pagar_pedido.pagar_pedido_usecase import (
    PagarPedidoUseCase,
)

from app.application.pedido.pagar_pedido.pagar_pedido_dto import (
    PagarPedidoInputDto,
)

from app.domain.pedido.pedido_entity import StatusPedido
from app.domain.pedido.pedido_entity import Pedido
from app.domain.pedido.item_pedido_entity import ItemPedido

from app.domain.produto.produto_entity import Produto

from app.infra.pedido.in_memory_pedido_repository import (
    InMemoryPedidoRepository,
)

from app.infra.produto.in_memory_produto_repository import (
    InMemoryProdutoRepository,
)


class TestPagarPedido:

    def test_pagar_pedido_e_reduzir_estoque(self):
        pedido_repository = InMemoryPedidoRepository()
        produto_repository = InMemoryProdutoRepository()

        produto = Produto(
            id=uuid4(),
            nome="Notebook",
            preco=2500.00,
            quantidade_estoque=10,
        )

        produto_repository.cadastrar_produto(produto)

        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        item = ItemPedido(
            id=uuid4(),
            produto_id=produto.id,
            preco_unitario=produto.preco,
            quantidade=2,
        )

        pedido.adicionar_item(item)

        pedido_repository.criar_pedido(pedido)

        use_case = PagarPedidoUseCase(
            pedido_repository=pedido_repository,
            produto_repository=produto_repository,
        )

        input_dto = PagarPedidoInputDto(
            pedido_id=pedido.id,
            valor_pago=5000.00,
        )

        response = use_case.executar(input_dto)

        # Verifica o resultado do pagamento
        assert response.pedido_id == pedido.id
        assert response.status == StatusPedido.PAGO.value
        assert response.total == 5000.00

        # Recupera o produto do repository
        produto_atualizado = produto_repository.encontrar_produto(produto.id)

        # 10 - 2 = 8
        assert produto_atualizado.quantidade_estoque == 8

        # Recupera o pedido
        pedido_atualizado = pedido_repository.encontrar_pedido(pedido.id)

        assert pedido_atualizado.status == StatusPedido.PAGO
