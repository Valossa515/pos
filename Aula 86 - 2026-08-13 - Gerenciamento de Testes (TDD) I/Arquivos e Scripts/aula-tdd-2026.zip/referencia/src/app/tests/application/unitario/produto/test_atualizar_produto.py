from unittest.mock import MagicMock
from uuid import uuid4

import pytest

from app.application.produto.atualizar_produto.atualizar_produto_dto import (
    AtualizarProdutoInputDto,
)
from app.application.produto.atualizar_produto.atualizar_produto_usecase import (
    AtualizarProdutoUseCase,
)
from app.domain.produto.produto_entity import Produto
from app.domain.produto.produto_repository_interface import (
    ProdutoRepositoryInterface,
)


class TestAtualizarProduto:

    def test_atualizar_produto_com_dados_validos(self):
        produto_id = uuid4()

        produto = Produto(
            id=produto_id,
            nome="Hambúrguer",
            preco=25.0,
            quantidade_estoque=10,
        )

        repositorio = MagicMock(spec=ProdutoRepositoryInterface)

        repositorio.encontrar_produto.return_value = produto

        caso_de_uso = AtualizarProdutoUseCase(
            produto_repository=repositorio,
        )

        input_dto = AtualizarProdutoInputDto(
            id=produto_id,
            nome="Hambúrguer Especial",
            preco=30.0,
            quantidade_estoque=20,
        )

        output = caso_de_uso.executar(input_dto)

        assert output.id == produto_id
        assert output.nome == "Hambúrguer Especial"
        assert output.preco == 30.0
        assert output.quantidade_estoque == 20

        repositorio.encontrar_produto.assert_called_once_with(produto_id)

        repositorio.atualizar_produto.assert_called_once_with(produto)

    def test_atualizar_produto_inexistente(self):
        produto_id = uuid4()

        repositorio = MagicMock(spec=ProdutoRepositoryInterface)

        repositorio.encontrar_produto.return_value = None

        caso_de_uso = AtualizarProdutoUseCase(
            produto_repository=repositorio,
        )

        input_dto = AtualizarProdutoInputDto(
            id=produto_id,
            nome="Hambúrguer",
            preco=25.0,
            quantidade_estoque=10,
        )

        with pytest.raises(
            ValueError,
            match="Produto não encontrado.",
        ):
            caso_de_uso.executar(input_dto)

        repositorio.atualizar_produto.assert_not_called()
