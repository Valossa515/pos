import pytest
from uuid import UUID
from unittest.mock import MagicMock

from app.application.cliente.cadastrar_cliente.cadastrar_cliente_dto import (
    CadastrarClienteInputDto,
)
from app.application.cliente.cadastrar_cliente.cadastrar_cliente_usecase import (
    CadastrarClienteUseCase,
)
from app.domain.cliente.cliente_repository_interface import (
    ClienteRepositoryInterface,
)


def mock_repository():
    return MagicMock(spec=ClienteRepositoryInterface)


class TestCadastrarClienteUseCase:

    def test_deve_cadastrar_um_cliente(self):
        cliente_repository = mock_repository()

        use_case = CadastrarClienteUseCase(cliente_repository)

        input = CadastrarClienteInputDto(
            nome="João",
            email="joao@email.com",
        )

        output = use_case.executar(input)

        assert output.nome == input.nome
        assert output.email == input.email
        assert output.ativo is True
        assert isinstance(output.id, UUID)

    def test_deve_lancar_erro_quando_nome_estiver_vazio(self):
        cliente_repository = mock_repository()

        use_case = CadastrarClienteUseCase(cliente_repository)

        input = CadastrarClienteInputDto(
            nome="",
            email="joao@email.com",
        )

        with pytest.raises(
            ValueError,
            match="O nome do cliente é obrigatório.",
        ):
            use_case.executar(input)

    def test_deve_lancar_erro_quando_email_for_invalido(self):
        cliente_repository = mock_repository()

        use_case = CadastrarClienteUseCase(cliente_repository)

        input = CadastrarClienteInputDto(
            nome="João",
            email="email-invalido",
        )

        with pytest.raises(
            ValueError,
            match="E-mail inválido.",
        ):
            use_case.executar(input)
