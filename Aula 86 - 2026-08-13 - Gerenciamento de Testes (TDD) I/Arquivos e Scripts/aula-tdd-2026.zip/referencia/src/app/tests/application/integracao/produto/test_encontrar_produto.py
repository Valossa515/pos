import pytest
from uuid import uuid4

from app.application.produto.cadastrar_produto.cadastrar_produto_dto import (
    CadastrarProdutoInputDto,
)
from app.application.produto.cadastrar_produto.cadastrar_produto_usecase import (
    CadastrarProdutoUseCase,
)
from app.application.produto.encontrar_produto.encontrar_produto_dto import (
    EncontrarProdutoInputDto,
)
from app.application.produto.encontrar_produto.encontrar_produto_usecase import (
    EncontrarProdutoUseCase,
)
from app.infra.produto.in_memory_produto_repository import (
    InMemoryProdutoRepository,
)


class TestEncontrarProduto:

    def test_encontrar_produto_existente(self):
        repositorio = InMemoryProdutoRepository()

        cadastrar_produto = CadastrarProdutoUseCase(
            produto_repository=repositorio,
        )

        produto = cadastrar_produto.executar(
            CadastrarProdutoInputDto(
                nome="Hambúrguer",
                preco=25.0,
                quantidade_estoque=10,
            )
        )

        caso_de_uso = EncontrarProdutoUseCase(
            produto_repository=repositorio,
        )

        input_dto = EncontrarProdutoInputDto(
            id=produto.id,
        )

        output = caso_de_uso.executar(input_dto)

        assert output.id == produto.id
        assert output.nome == "Hambúrguer"
        assert output.preco == 25.0
        assert output.quantidade_estoque == 10

    def test_encontrar_produto_inexistente(self):
        repositorio = InMemoryProdutoRepository()

        caso_de_uso = EncontrarProdutoUseCase(
            produto_repository=repositorio,
        )

        input_dto = EncontrarProdutoInputDto(
            id=uuid4(),
        )

        with pytest.raises(
            ValueError,
            match="Produto não encontrado.",
        ):
            caso_de_uso.executar(input_dto)
