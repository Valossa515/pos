from unittest.mock import MagicMock
from uuid import uuid4

from app.application.produto.listar_produtos.listar_produtos_dto import (
    ListarProdutosInputDto,
)
from app.application.produto.listar_produtos.listar_produtos_usecase import (
    ListarProdutosUseCase,
)
from app.domain.produto.produto_entity import Produto
from app.domain.produto.produto_repository_interface import (
    ProdutoRepositoryInterface,
)


class TestListarProdutos:

    def test_listar_produtos(self):
        produto_1 = Produto(
            id=uuid4(),
            nome="Hambúrguer",
            preco=25.0,
            quantidade_estoque=10,
        )

        produto_2 = Produto(
            id=uuid4(),
            nome="Batata Frita",
            preco=15.0,
            quantidade_estoque=20,
        )

        repositorio = MagicMock(spec=ProdutoRepositoryInterface)

        repositorio.listar_produtos.return_value = [
            produto_1,
            produto_2,
        ]

        caso_de_uso = ListarProdutosUseCase(
            produto_repository=repositorio,
        )

        output = caso_de_uso.executar(input=ListarProdutosInputDto())

        assert len(output.produtos) == 2

        assert output.produtos[0].id == produto_1.id
        assert output.produtos[0].nome == "Hambúrguer"
        assert output.produtos[0].preco == 25.0
        assert output.produtos[0].quantidade_estoque == 10

        assert output.produtos[1].id == produto_2.id
        assert output.produtos[1].nome == "Batata Frita"
        assert output.produtos[1].preco == 15.0
        assert output.produtos[1].quantidade_estoque == 20

        repositorio.listar_produtos.assert_called_once()

    def test_listar_produtos_sem_produtos(self):
        repositorio = MagicMock(spec=ProdutoRepositoryInterface)

        repositorio.listar_produtos.return_value = []

        caso_de_uso = ListarProdutosUseCase(
            produto_repository=repositorio,
        )

        output = caso_de_uso.executar(input=ListarProdutosInputDto())

        assert output.produtos == []

        repositorio.listar_produtos.assert_called_once()
