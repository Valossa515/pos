from uuid import uuid4

import pytest

from app.application.cliente.cadastrar_cliente.cadastrar_cliente_dto import (
    CadastrarClienteInputDto,
)
from app.application.cliente.cadastrar_cliente.cadastrar_cliente_usecase import (
    CadastrarClienteUseCase,
)
from app.application.cliente.excluir_cliente.excluir_cliente_dto import (
    ExcluirClienteInputDto,
)
from app.application.cliente.excluir_cliente.excluir_cliente_usecase import (
    ExcluirClienteUseCase,
)
from app.infra.cliente.in_memory_cliente_repository import (
    InMemoryClienteRepository,
)


class TestExcluirCliente:

    def test_excluir_cliente(self):
        repositorio = InMemoryClienteRepository()

        cadastrar_cliente = CadastrarClienteUseCase(
            cliente_repository=repositorio,
        )

        cliente = cadastrar_cliente.executar(
            CadastrarClienteInputDto(
                nome="João da Silva",
                email="joao@email.com",
            )
        )

        excluir_cliente = ExcluirClienteUseCase(
            cliente_repository=repositorio,
        )

        input_dto = ExcluirClienteInputDto(
            id=cliente.id,
        )

        excluir_cliente.executar(input_dto)

        cliente_excluido = repositorio.encontrar_cliente(cliente.id)

        assert cliente_excluido is None

        assert len(repositorio.listar_clientes()) == 0

    def test_excluir_cliente_inexistente(self):
        repositorio = InMemoryClienteRepository()

        caso_de_uso = ExcluirClienteUseCase(
            cliente_repository=repositorio,
        )

        input_dto = ExcluirClienteInputDto(
            id=uuid4(),
        )

        with pytest.raises(ValueError):
            caso_de_uso.executar(input_dto)
