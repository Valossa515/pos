import pytest
from uuid import uuid4

from app.application.cliente.atualizar_cliente.atualizar_cliente_dto import (
    AtualizarClienteInputDto,
)
from app.application.cliente.atualizar_cliente.atualizar_cliente_usecase import (
    AtualizarClienteUseCase,
)
from app.application.cliente.cadastrar_cliente.cadastrar_cliente_dto import (
    CadastrarClienteInputDto,
)
from app.application.cliente.cadastrar_cliente.cadastrar_cliente_usecase import (
    CadastrarClienteUseCase,
)
from app.infra.cliente.in_memory_cliente_repository import (
    InMemoryClienteRepository,
)


class TestAtualizarCliente:

    def test_atualizar_cliente_com_dados_validos(self):
        repositorio = InMemoryClienteRepository()

        cadastrar_cliente = CadastrarClienteUseCase(
            cliente_repository=repositorio,
        )

        cliente = cadastrar_cliente.executar(
            CadastrarClienteInputDto(
                nome="João da Silva",
                email="joao@email.com",
            )
        )

        atualizar_cliente = AtualizarClienteUseCase(
            cliente_repository=repositorio,
        )

        input_dto = AtualizarClienteInputDto(
            id=cliente.id,
            nome="João Santos",
            email="joao.santos@email.com",
        )

        output = atualizar_cliente.executar(input_dto)

        cliente_atualizado = repositorio.encontrar_cliente(cliente.id)

        # Verifica a resposta do Use Case
        assert output.id == cliente.id
        assert output.nome == "João Santos"
        assert output.email == "joao.santos@email.com"
        assert output.ativo is True

        # Verifica o cliente persistido no repository
        assert cliente_atualizado is not None
        assert cliente_atualizado.id == cliente.id
        assert cliente_atualizado.nome == "João Santos"
        assert cliente_atualizado.email.valor == "joao.santos@email.com"
        assert cliente_atualizado.ativo is True

    def test_atualizar_cliente_inexistente(self):
        repositorio = InMemoryClienteRepository()

        caso_de_uso = AtualizarClienteUseCase(
            cliente_repository=repositorio,
        )

        input_dto = AtualizarClienteInputDto(
            id=uuid4(),
            nome="João Santos",
            email="joao.santos@email.com",
        )

        with pytest.raises(
            ValueError,
            match="Cliente não encontrado.",
        ):
            caso_de_uso.executar(input_dto)

        # Nenhum cliente deve ter sido criado
        assert repositorio.listar_clientes() == []
