import pytest
from unittest.mock import MagicMock
from uuid import UUID, uuid4

from app.application.pedido.criar_pedido.criar_pedido_usecase import (
    CriarPedidoUseCase,
)
from app.application.pedido.criar_pedido.criar_pedido_dto import (
    CriarPedidoInputDto,
)

from app.domain.cliente.cliente_entity import Cliente
from app.domain.cliente.email_vo import Email
from app.domain.produto.produto_entity import Produto
from app.domain.pedido.pedido_entity import StatusPedido


class TestCriarPedidoUseCase:

    def test_criar_pedido_com_dados_validos(self):
        pedido_repository = MagicMock()
        cliente_repository = MagicMock()
        produto_repository = MagicMock()

        cliente = Cliente(
            id=uuid4(),
            nome="João da Silva",
            email=Email("joao@email.com"),
        )

        produto = Produto(
            id=uuid4(),
            nome="Notebook",
            preco=2500.00,
            quantidade_estoque=10,
        )

        cliente_repository.encontrar_cliente.return_value = cliente
        produto_repository.encontrar_produto.return_value = produto

        use_case = CriarPedidoUseCase(
            pedido_repository=pedido_repository,
            cliente_repository=cliente_repository,
            produto_repository=produto_repository,
        )

        input_dto = CriarPedidoInputDto(
            cliente_id=cliente.id,
            itens=[
                {
                    "produto_id": produto.id,
                    "quantidade": 2,
                }
            ],
        )

        response = use_case.executar(input_dto)

        assert response is not None
        assert isinstance(response.id, UUID)
        assert response.cliente_id == cliente.id
        assert response.status == StatusPedido.PENDENTE.value
        assert response.total == 5000.00

        assert len(response.itens) == 1
        assert response.itens[0].produto_id == produto.id
        assert response.itens[0].preco_unitario == 2500.00
        assert response.itens[0].quantidade == 2
        assert response.itens[0].total == 5000.00

        cliente_repository.encontrar_cliente.assert_called_once_with(cliente.id)

        produto_repository.encontrar_produto.assert_called_once_with(produto.id)

        pedido_repository.criar_pedido.assert_called_once()

    def test_nao_deve_criar_pedido_para_cliente_inexistente(self):
        pedido_repository = MagicMock()
        cliente_repository = MagicMock()
        produto_repository = MagicMock()

        cliente_repository.encontrar_cliente.return_value = None

        use_case = CriarPedidoUseCase(
            pedido_repository=pedido_repository,
            cliente_repository=cliente_repository,
            produto_repository=produto_repository,
        )

        input_dto = CriarPedidoInputDto(
            cliente_id=uuid4(),
            itens=[],
        )

        with pytest.raises(
            ValueError,
            match="Cliente não encontrado.",
        ):
            use_case.executar(input_dto)

        pedido_repository.criar_pedido.assert_not_called()

    def test_nao_deve_criar_pedido_para_cliente_inativo(self):
        pedido_repository = MagicMock()
        cliente_repository = MagicMock()
        produto_repository = MagicMock()

        cliente = Cliente(
            id=uuid4(),
            nome="João da Silva",
            email=Email("joao@email.com"),
        )

        cliente.desativar()

        cliente_repository.encontrar_cliente.return_value = cliente

        use_case = CriarPedidoUseCase(
            pedido_repository=pedido_repository,
            cliente_repository=cliente_repository,
            produto_repository=produto_repository,
        )

        input_dto = CriarPedidoInputDto(
            cliente_id=cliente.id,
            itens=[],
        )

        with pytest.raises(
            ValueError,
            match="Clientes inativos não podem realizar novos pedidos.",
        ):
            use_case.executar(input_dto)

        pedido_repository.criar_pedido.assert_not_called()

    def test_nao_deve_criar_pedido_com_produto_inexistente(self):
        pedido_repository = MagicMock()
        cliente_repository = MagicMock()
        produto_repository = MagicMock()

        cliente = Cliente(
            id=uuid4(),
            nome="João da Silva",
            email=Email("joao@email.com"),
        )

        produto_id = uuid4()

        cliente_repository.encontrar_cliente.return_value = cliente
        produto_repository.encontrar_produto.return_value = None

        use_case = CriarPedidoUseCase(
            pedido_repository=pedido_repository,
            cliente_repository=cliente_repository,
            produto_repository=produto_repository,
        )

        input_dto = CriarPedidoInputDto(
            cliente_id=cliente.id,
            itens=[
                {
                    "produto_id": produto_id,
                    "quantidade": 2,
                }
            ],
        )

        with pytest.raises(
            ValueError,
            match=f"Produto '{produto_id}' não foi encontrado.",
        ):
            use_case.executar(input_dto)

        pedido_repository.criar_pedido.assert_not_called()
