import pytest
from unittest.mock import MagicMock
from uuid import uuid4

from app.application.pedido.pagar_pedido.pagar_pedido_usecase import (
    PagarPedidoUseCase,
)

from app.application.pedido.pagar_pedido.pagar_pedido_dto import (
    PagarPedidoInputDto,
    PagarPedidoOutputDto,
)

from app.domain.pedido.pedido_entity import Pedido, StatusPedido
from app.domain.pedido.item_pedido_entity import ItemPedido
from app.domain.produto.produto_entity import Produto


class TestPagarPedidoUseCase:

    def test_pagar_pedido_com_dados_validos(self):
        pedido_repository = MagicMock()
        produto_repository = MagicMock()

        cliente_id = uuid4()
        produto_id = uuid4()

        pedido = Pedido(
            id=uuid4(),
            cliente_id=cliente_id,
        )

        item = ItemPedido(
            id=uuid4(),
            produto_id=produto_id,
            preco_unitario=100.00,
            quantidade=2,
        )

        pedido.adicionar_item(item)

        produto = Produto(
            id=produto_id,
            nome="Notebook",
            preco=100.00,
            quantidade_estoque=10,
        )

        pedido_repository.encontrar_pedido.return_value = pedido
        produto_repository.encontrar_produto.return_value = produto

        use_case = PagarPedidoUseCase(
            pedido_repository=pedido_repository,
            produto_repository=produto_repository,
        )

        input_dto = PagarPedidoInputDto(
            pedido_id=pedido.id,
            valor_pago=200.00,
        )

        response = use_case.executar(input_dto)

        # Verifica a resposta
        assert response is not None
        assert isinstance(response, PagarPedidoOutputDto)
        assert response.pedido_id == pedido.id
        assert response.status == StatusPedido.PAGO.value
        assert response.total == 200.00

        # Verifica se o estoque foi reduzido
        assert produto.quantidade_estoque == 8

        # Verifica as chamadas aos repositories
        pedido_repository.encontrar_pedido.assert_called_once_with(pedido.id)

        produto_repository.encontrar_produto.assert_called_once_with(produto_id)

        produto_repository.atualizar_produto.assert_called_once_with(produto)

        pedido_repository.atualizar_pedido.assert_called_once_with(pedido)

    def test_nao_deve_pagar_pedido_inexistente(self):
        pedido_repository = MagicMock()
        produto_repository = MagicMock()

        pedido_repository.encontrar_pedido.return_value = None

        use_case = PagarPedidoUseCase(
            pedido_repository=pedido_repository,
            produto_repository=produto_repository,
        )

        input_dto = PagarPedidoInputDto(
            pedido_id=uuid4(),
            valor_pago=100.00,
        )

        with pytest.raises(
            ValueError,
            match="Pedido não encontrado.",
        ):
            use_case.executar(input_dto)

        pedido_repository.atualizar_pedido.assert_not_called()
        produto_repository.atualizar_produto.assert_not_called()

    def test_nao_deve_pagar_com_valor_insuficiente(self):
        pedido_repository = MagicMock()
        produto_repository = MagicMock()

        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        item = ItemPedido(
            id=uuid4(),
            produto_id=uuid4(),
            preco_unitario=100.00,
            quantidade=2,
        )

        pedido.adicionar_item(item)

        pedido_repository.encontrar_pedido.return_value = pedido

        use_case = PagarPedidoUseCase(
            pedido_repository=pedido_repository,
            produto_repository=produto_repository,
        )

        input_dto = PagarPedidoInputDto(
            pedido_id=pedido.id,
            valor_pago=100.00,
        )

        with pytest.raises(
            ValueError,
            match=(
                r"Valor pago \(R\$ 100\.00\) é insuficiente\. "
                r"O total do pedido é R\$ 200\.00\."
            ),
        ):
            use_case.executar(input_dto)

        # O pedido não deve ser atualizado
        pedido_repository.atualizar_pedido.assert_not_called()

        # O estoque não deve ser atualizado
        produto_repository.atualizar_produto.assert_not_called()

    def test_deve_reduzir_estoque_de_todos_os_produtos(self):
        pedido_repository = MagicMock()
        produto_repository = MagicMock()

        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        produto_1 = Produto(
            id=uuid4(),
            nome="Notebook",
            preco=100.00,
            quantidade_estoque=10,
        )

        produto_2 = Produto(
            id=uuid4(),
            nome="Mouse",
            preco=50.00,
            quantidade_estoque=20,
        )

        item_1 = ItemPedido(
            id=uuid4(),
            produto_id=produto_1.id,
            preco_unitario=produto_1.preco,
            quantidade=2,
        )

        item_2 = ItemPedido(
            id=uuid4(),
            produto_id=produto_2.id,
            preco_unitario=produto_2.preco,
            quantidade=3,
        )

        pedido.adicionar_item(item_1)
        pedido.adicionar_item(item_2)

        pedido_repository.encontrar_pedido.return_value = pedido

        def encontrar_produto(produto_id):
            if produto_id == produto_1.id:
                return produto_1

            if produto_id == produto_2.id:
                return produto_2

            return None

        produto_repository.encontrar_produto.side_effect = encontrar_produto

        use_case = PagarPedidoUseCase(
            pedido_repository=pedido_repository,
            produto_repository=produto_repository,
        )

        input_dto = PagarPedidoInputDto(
            pedido_id=pedido.id,
            valor_pago=350.00,
        )

        use_case.executar(input_dto)

        # 10 - 2
        assert produto_1.quantidade_estoque == 8

        # 20 - 3
        assert produto_2.quantidade_estoque == 17

        assert produto_repository.atualizar_produto.call_count == 2

        pedido_repository.atualizar_pedido.assert_called_once_with(pedido)
