from app.application.produto.cadastrar_produto.cadastrar_produto_dto import (
    CadastrarProdutoInputDto,
)
from app.application.produto.cadastrar_produto.cadastrar_produto_usecase import (
    CadastrarProdutoUseCase,
)
from app.application.produto.listar_produtos.listar_produtos_dto import (
    ListarProdutosInputDto,
)
from app.application.produto.listar_produtos.listar_produtos_usecase import (
    ListarProdutosUseCase,
)
from app.infra.produto.in_memory_produto_repository import (
    InMemoryProdutoRepository,
)


class TestListarProdutos:

    def test_listar_produtos(self):
        repositorio = InMemoryProdutoRepository()

        cadastrar_produto = CadastrarProdutoUseCase(
            produto_repository=repositorio,
        )

        produto_1 = cadastrar_produto.executar(
            CadastrarProdutoInputDto(
                nome="Hambúrguer",
                preco=25.0,
                quantidade_estoque=10,
            )
        )

        produto_2 = cadastrar_produto.executar(
            CadastrarProdutoInputDto(
                nome="Batata Frita",
                preco=15.0,
                quantidade_estoque=20,
            )
        )

        caso_de_uso = ListarProdutosUseCase(
            produto_repository=repositorio,
        )

        output = caso_de_uso.executar(input=ListarProdutosInputDto())

        assert len(output.produtos) == 2

        assert output.produtos[0].id == produto_1.id
        assert output.produtos[0].nome == "Hambúrguer"
        assert output.produtos[0].preco == 25.0
        assert output.produtos[0].quantidade_estoque == 10

        assert output.produtos[1].id == produto_2.id
        assert output.produtos[1].nome == "Batata Frita"
        assert output.produtos[1].preco == 15.0
        assert output.produtos[1].quantidade_estoque == 20

    def test_listar_produtos_sem_produtos(self):
        repositorio = InMemoryProdutoRepository()

        caso_de_uso = ListarProdutosUseCase(
            produto_repository=repositorio,
        )

        output = caso_de_uso.executar(input=ListarProdutosInputDto())

        assert output.produtos == []
