from unittest.mock import MagicMock
from uuid import uuid4

from app.application.cliente.listar_clientes.listar_clientes_usecase import (
    ListarClientesUseCase,
)
from app.domain.cliente.cliente_entity import Cliente
from app.domain.cliente.cliente_repository_interface import (
    ClienteRepositoryInterface,
)
from app.domain.cliente.email_vo import Email


class TestListarClientes:

    def test_listar_clientes(self):
        cliente_1 = Cliente(
            id=uuid4(),
            nome="João da Silva",
            email=Email("joao@email.com"),
        )

        cliente_2 = Cliente(
            id=uuid4(),
            nome="Maria da Silva",
            email=Email("maria@email.com"),
        )

        repositorio = MagicMock(spec=ClienteRepositoryInterface)

        repositorio.listar_clientes.return_value = [
            cliente_1,
            cliente_2,
        ]

        caso_de_uso = ListarClientesUseCase(
            cliente_repository=repositorio,
        )

        output = caso_de_uso.executar()

        assert len(output.clientes) == 2

        assert output.clientes[0].id == cliente_1.id
        assert output.clientes[0].nome == "João da Silva"
        assert output.clientes[0].email == "joao@email.com"

        assert output.clientes[1].id == cliente_2.id
        assert output.clientes[1].nome == "Maria da Silva"
        assert output.clientes[1].email == "maria@email.com"

        repositorio.listar_clientes.assert_called_once()

    def test_listar_clientes_sem_clientes(self):
        repositorio = MagicMock(spec=ClienteRepositoryInterface)

        repositorio.listar_clientes.return_value = []

        caso_de_uso = ListarClientesUseCase(
            cliente_repository=repositorio,
        )

        output = caso_de_uso.executar()

        assert output.clientes == []

        repositorio.listar_clientes.assert_called_once()
