from app.application.cliente.cadastrar_cliente.cadastrar_cliente_dto import (
    CadastrarClienteInputDto,
)
from app.application.cliente.cadastrar_cliente.cadastrar_cliente_usecase import (
    CadastrarClienteUseCase,
)
from app.application.cliente.listar_clientes.listar_clientes_usecase import (
    ListarClientesUseCase,
)
from app.infra.cliente.in_memory_cliente_repository import (
    InMemoryClienteRepository,
)


class TestListarClientes:

    def test_listar_clientes(self):
        repositorio = InMemoryClienteRepository()

        cadastrar_cliente = CadastrarClienteUseCase(
            cliente_repository=repositorio,
        )

        cliente_1 = cadastrar_cliente.executar(
            CadastrarClienteInputDto(
                nome="João da Silva",
                email="joao@email.com",
            )
        )

        cliente_2 = cadastrar_cliente.executar(
            CadastrarClienteInputDto(
                nome="Maria da Silva",
                email="maria@email.com",
            )
        )

        listar_clientes = ListarClientesUseCase(
            cliente_repository=repositorio,
        )

        output = listar_clientes.executar()

        clientes = output.clientes

        assert len(clientes) == 2

        assert clientes[0].id == cliente_1.id
        assert clientes[0].nome == "João da Silva"
        assert clientes[0].email == "joao@email.com"

        assert clientes[1].id == cliente_2.id
        assert clientes[1].nome == "Maria da Silva"
        assert clientes[1].email == "maria@email.com"

    def test_listar_clientes_sem_clientes(self):
        repositorio = InMemoryClienteRepository()

        caso_de_uso = ListarClientesUseCase(
            cliente_repository=repositorio,
        )

        output = caso_de_uso.executar()

        clientes = output.clientes

        assert clientes == []
