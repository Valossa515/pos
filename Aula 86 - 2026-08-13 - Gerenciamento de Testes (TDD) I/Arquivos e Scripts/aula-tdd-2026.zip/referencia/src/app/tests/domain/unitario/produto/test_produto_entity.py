import pytest
from uuid import uuid4

from app.domain.produto.produto_entity import Produto


class TestProduto:

    # Teste para verificar a inicialização de um produto
    def test_inicializacao_produto(self):
        produto_id = uuid4()
        nome = "Notebook"
        preco = 2500.00
        quantidade_estoque = 10

        produto = Produto(
            id=produto_id,
            nome=nome,
            preco=preco,
            quantidade_estoque=quantidade_estoque,
        )

        # Verifica se os atributos do produto estão corretos
        assert produto.id == produto_id
        assert produto.nome == nome
        assert produto.preco == preco
        assert produto.quantidade_estoque == quantidade_estoque

    # Teste para verificar a validação do ID do produto
    def test_validacao_id_produto(self):
        with pytest.raises(
            ValueError,
            match="O id deve ser um UUID.",
        ):
            Produto(
                id=1,
                nome="Notebook",
                preco=2500.00,
                quantidade_estoque=10,
            )

    # Teste para verificar a validação do nome do produto
    def test_validacao_nome_produto(self):
        with pytest.raises(
            ValueError,
            match="O nome do produto é obrigatório.",
        ):
            Produto(
                id=uuid4(),
                nome="",
                preco=2500.00,
                quantidade_estoque=10,
            )

    # Teste para verificar a validação de nome contendo apenas espaços
    def test_validacao_nome_produto_apenas_espacos(self):
        with pytest.raises(
            ValueError,
            match="O nome do produto é obrigatório.",
        ):
            Produto(
                id=uuid4(),
                nome="   ",
                preco=2500.00,
                quantidade_estoque=10,
            )

    # Teste para verificar a validação do preço do produto
    def test_validacao_preco_produto(self):
        with pytest.raises(
            ValueError,
            match="O preço do produto deve ser maior que zero.",
        ):
            Produto(
                id=uuid4(),
                nome="Notebook",
                preco=0,
                quantidade_estoque=10,
            )

    # Teste para verificar a validação de preço negativo
    def test_validacao_preco_produto_negativo(self):
        with pytest.raises(
            ValueError,
            match="O preço do produto deve ser maior que zero.",
        ):
            Produto(
                id=uuid4(),
                nome="Notebook",
                preco=-100,
                quantidade_estoque=10,
            )

    # Teste para verificar a validação da quantidade em estoque
    def test_validacao_quantidade_estoque(self):
        with pytest.raises(
            ValueError,
            match="A quantidade em estoque não pode ser negativa.",
        ):
            Produto(
                id=uuid4(),
                nome="Notebook",
                preco=2500.00,
                quantidade_estoque=-1,
            )

    # Teste para verificar a diminuição do estoque
    def test_diminuir_estoque(self):
        produto = Produto(
            id=uuid4(),
            nome="Notebook",
            preco=2500.00,
            quantidade_estoque=10,
        )

        produto.diminuir_estoque(3)

        # Verifica se o estoque foi reduzido corretamente
        assert produto.quantidade_estoque == 7

    # Teste para verificar a tentativa de diminuir estoque com quantidade zero
    def test_diminuir_estoque_quantidade_zero(self):
        produto = Produto(
            id=uuid4(),
            nome="Notebook",
            preco=2500.00,
            quantidade_estoque=10,
        )

        with pytest.raises(
            ValueError,
            match="A quantidade a ser removida deve ser maior que zero.",
        ):
            produto.diminuir_estoque(0)

    # Teste para verificar a tentativa de diminuir estoque com quantidade negativa
    def test_diminuir_estoque_quantidade_negativa(self):
        produto = Produto(
            id=uuid4(),
            nome="Notebook",
            preco=2500.00,
            quantidade_estoque=10,
        )

        with pytest.raises(
            ValueError,
            match="A quantidade a ser removida deve ser maior que zero.",
        ):
            produto.diminuir_estoque(-1)

    # Teste para verificar estoque insuficiente
    def test_diminuir_estoque_insuficiente(self):
        produto = Produto(
            id=uuid4(),
            nome="Notebook",
            preco=2500.00,
            quantidade_estoque=5,
        )

        with pytest.raises(
            ValueError,
            match="Estoque insuficiente para essa operação.",
        ):
            produto.diminuir_estoque(10)

    # Teste para verificar o aumento do estoque
    def test_aumentar_estoque(self):
        produto = Produto(
            id=uuid4(),
            nome="Notebook",
            preco=2500.00,
            quantidade_estoque=10,
        )

        produto.aumentar_estoque(5)

        # Verifica se o estoque foi aumentado corretamente
        assert produto.quantidade_estoque == 15

    # Teste para verificar a tentativa de aumentar estoque com quantidade zero
    def test_aumentar_estoque_quantidade_zero(self):
        produto = Produto(
            id=uuid4(),
            nome="Notebook",
            preco=2500.00,
            quantidade_estoque=10,
        )

        with pytest.raises(
            ValueError,
            match="A quantidade a ser adicionada deve ser maior que zero.",
        ):
            produto.aumentar_estoque(0)

    # Teste para verificar a tentativa de aumentar estoque com quantidade negativa
    def test_aumentar_estoque_quantidade_negativa(self):
        produto = Produto(
            id=uuid4(),
            nome="Notebook",
            preco=2500.00,
            quantidade_estoque=10,
        )

        with pytest.raises(
            ValueError,
            match="A quantidade a ser adicionada deve ser maior que zero.",
        ):
            produto.aumentar_estoque(-1)
