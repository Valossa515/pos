from uuid import uuid4

from app.domain.pedido.item_pedido_entity import ItemPedido
from app.domain.pedido.pedido_entity import Pedido, StatusPedido


class TestPedidoItemPedido:

    # Teste de integração entre Pedido e ItemPedido
    def test_adicionar_item_pedido(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        item = ItemPedido(
            id=uuid4(),
            produto_id=uuid4(),
            preco_unitario=100.00,
            quantidade=2,
        )

        pedido.adicionar_item(item)

        assert len(pedido.itens) == 1
        assert pedido.itens[0].id == item.id
        assert pedido.itens[0].produto_id == item.produto_id
        assert pedido.itens[0].preco_unitario == 100.00
        assert pedido.itens[0].quantidade == 2

    # Teste de integração para produtos iguais
    def test_adicionar_item_produto_existente(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        produto_id = uuid4()

        item_1 = ItemPedido(
            id=uuid4(),
            produto_id=produto_id,
            preco_unitario=100.00,
            quantidade=2,
        )

        item_2 = ItemPedido(
            id=uuid4(),
            produto_id=produto_id,
            preco_unitario=100.00,
            quantidade=3,
        )

        pedido.adicionar_item(item_1)
        pedido.adicionar_item(item_2)

        # O Pedido deve reconhecer que o produto já existe
        assert len(pedido.itens) == 1
        assert pedido.itens[0].quantidade == 5

    # Teste de integração para produtos diferentes
    def test_adicionar_itens_produtos_diferentes(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        item_1 = ItemPedido(
            id=uuid4(),
            produto_id=uuid4(),
            preco_unitario=100.00,
            quantidade=2,
        )

        item_2 = ItemPedido(
            id=uuid4(),
            produto_id=uuid4(),
            preco_unitario=50.00,
            quantidade=3,
        )

        pedido.adicionar_item(item_1)
        pedido.adicionar_item(item_2)

        assert len(pedido.itens) == 2

    # Teste de integração para cálculo do total
    def test_calcular_total_pedido(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        item_1 = ItemPedido(
            id=uuid4(),
            produto_id=uuid4(),
            preco_unitario=100.00,
            quantidade=2,
        )

        item_2 = ItemPedido(
            id=uuid4(),
            produto_id=uuid4(),
            preco_unitario=50.00,
            quantidade=3,
        )

        pedido.adicionar_item(item_1)
        pedido.adicionar_item(item_2)

        total = pedido.calcular_total()

        # 100 * 2 + 50 * 3 = 350
        assert total == 350.00

    # Teste de integração para pagamento
    def test_pagar_pedido_com_itens(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        item = ItemPedido(
            id=uuid4(),
            produto_id=uuid4(),
            preco_unitario=100.00,
            quantidade=2,
        )

        pedido.adicionar_item(item)

        pedido.pagar(200.00)

        assert pedido.status == StatusPedido.PAGO

    # Teste de integração para remover item
    def test_remover_item_do_pedido(self):
        produto_id = uuid4()

        item = ItemPedido(
            id=uuid4(),
            produto_id=produto_id,
            preco_unitario=100.00,
            quantidade=2,
        )

        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
            itens=[item],
        )

        pedido.remover_item(produto_id)

        assert pedido.itens == []