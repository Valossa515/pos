import pytest
from uuid import uuid4

from app.domain.pedido.item_pedido_entity import ItemPedido


class TestItemPedido:

    # Teste para verificar a inicialização de um item do pedido
    def test_inicializacao_item_pedido(self):
        item_id = uuid4()
        produto_id = uuid4()
        preco_unitario = 100.00
        quantidade = 2

        item = ItemPedido(
            id=item_id,
            produto_id=produto_id,
            preco_unitario=preco_unitario,
            quantidade=quantidade,
        )

        # Verifica se os atributos do item estão corretos
        assert item.id == item_id
        assert item.produto_id == produto_id
        assert item.preco_unitario == preco_unitario
        assert item.quantidade == quantidade

    # Teste para verificar a validação do ID do item
    def test_validacao_id_item_pedido(self):
        with pytest.raises(
            ValueError,
            match="O id deve ser um UUID.",
        ):
            ItemPedido(
                id=1,
                produto_id=uuid4(),
                preco_unitario=100.00,
                quantidade=2,
            )

    # Teste para verificar a validação do ID do produto
    def test_validacao_produto_id(self):
        with pytest.raises(
            ValueError,
            match="O produto_id deve ser um UUID.",
        ):
            ItemPedido(
                id=uuid4(),
                produto_id=1,
                preco_unitario=100.00,
                quantidade=2,
            )

    # Teste para verificar a validação da quantidade
    def test_validacao_quantidade_item_pedido(self):
        with pytest.raises(
            ValueError,
            match="A quantidade do item deve ser maior que zero.",
        ):
            ItemPedido(
                id=uuid4(),
                produto_id=uuid4(),
                preco_unitario=100.00,
                quantidade=0,
            )

    # Teste para verificar a validação de quantidade negativa
    def test_validacao_quantidade_item_pedido_negativa(self):
        with pytest.raises(
            ValueError,
            match="A quantidade do item deve ser maior que zero.",
        ):
            ItemPedido(
                id=uuid4(),
                produto_id=uuid4(),
                preco_unitario=100.00,
                quantidade=-1,
            )

    # Teste para verificar a validação do preço unitário
    def test_validacao_preco_unitario(self):
        with pytest.raises(
            ValueError,
            match="O preço unitário do item deve ser maior que zero.",
        ):
            ItemPedido(
                id=uuid4(),
                produto_id=uuid4(),
                preco_unitario=0,
                quantidade=2,
            )

    # Teste para verificar a validação de preço unitário negativo
    def test_validacao_preco_unitario_negativo(self):
        with pytest.raises(
            ValueError,
            match="O preço unitário do item deve ser maior que zero.",
        ):
            ItemPedido(
                id=uuid4(),
                produto_id=uuid4(),
                preco_unitario=-100.00,
                quantidade=2,
            )

    # Teste para verificar o cálculo do total do item
    def test_calcular_total(self):
        item = ItemPedido(
            id=uuid4(),
            produto_id=uuid4(),
            preco_unitario=100.00,
            quantidade=3,
        )

        total = item.calcular_total()

        # Verifica se o total foi calculado corretamente
        assert total == 300.00
