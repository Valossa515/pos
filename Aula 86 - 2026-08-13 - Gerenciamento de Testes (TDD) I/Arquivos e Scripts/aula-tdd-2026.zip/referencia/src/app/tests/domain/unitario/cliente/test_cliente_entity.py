import pytest
from uuid import uuid4

from app.domain.cliente.cliente_entity import Cliente
from app.domain.cliente.email_vo import Email


class TestCliente:

    def test_inicializacao_cliente(self):
        cliente_id = uuid4()
        email = Email("joao@email.com")

        cliente = Cliente(
            id=cliente_id,
            nome="João da Silva",
            email=email,
        )

        assert cliente.id == cliente_id
        assert cliente.nome == "João da Silva"
        assert cliente.email == email
        assert cliente.ativo is True

    def test_validacao_id_cliente(self):
        with pytest.raises(
            ValueError,
            match="O id deve ser um UUID.",
        ):
            Cliente(
                id=1,
                nome="João da Silva",
                email=Email("joao@email.com"),
            )

    def test_validacao_nome_cliente(self):
        with pytest.raises(
            ValueError,
            match="O nome do cliente é obrigatório.",
        ):
            Cliente(
                id=uuid4(),
                nome="",
                email=Email("joao@email.com"),
            )

    def test_desativar_cliente(self):
        cliente = Cliente(
            id=uuid4(),
            nome="João da Silva",
            email=Email("joao@email.com"),
        )

        cliente.desativar()

        assert cliente.ativo is False

    def test_ativar_cliente(self):
        cliente = Cliente(
            id=uuid4(),
            nome="João da Silva",
            email=Email("joao@email.com"),
        )

        cliente.desativar()
        cliente.ativar()

        assert cliente.ativo is True