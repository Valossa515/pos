import pytest

from app.domain.cliente.email_vo import Email


class TestEmail:

    def test_inicializacao_email(self):
        email = Email("joao@email.com")

        assert email.valor == "joao@email.com"

    def test_validacao_email_obrigatorio(self):
        with pytest.raises(
            ValueError,
            match="O e-mail é obrigatório.",
        ):
            Email("")

    def test_validacao_email_apenas_espacos(self):
        with pytest.raises(
            ValueError,
            match="O e-mail é obrigatório.",
        ):
            Email("   ")

    def test_validacao_email_sem_arroba(self):
        with pytest.raises(
            ValueError,
            match="E-mail inválido.",
        ):
            Email("joaoemail.com")

    def test_validacao_email_sem_ponto(self):
        with pytest.raises(
            ValueError,
            match="E-mail inválido.",
        ):
            Email("joao@emailcom")