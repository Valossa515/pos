import pytest
from datetime import datetime
from unittest.mock import Mock
from uuid import uuid4

from app.domain.pedido.pedido_entity import Pedido, StatusPedido


class TestPedido:

    # Teste para verificar a inicialização de um pedido
    def test_inicializacao_pedido(self):
        pedido_id = uuid4()
        cliente_id = uuid4()

        pedido = Pedido(
            id=pedido_id,
            cliente_id=cliente_id,
        )

        # Verifica se os atributos do pedido estão corretos
        assert pedido.id == pedido_id
        assert pedido.cliente_id == cliente_id
        assert pedido.itens == []
        assert pedido.status == StatusPedido.PENDENTE
        assert isinstance(pedido.criado_em, datetime)

    # Teste para verificar a validação do ID do pedido
    def test_validacao_id_pedido(self):
        with pytest.raises(
            ValueError,
            match="O id deve ser um UUID.",
        ):
            Pedido(
                id=1,
                cliente_id=uuid4(),
            )

    # Teste para verificar a validação do ID do cliente
    def test_validacao_cliente_id_pedido(self):
        with pytest.raises(
            ValueError,
            match="O cliente_id deve ser um UUID.",
        ):
            Pedido(
                id=uuid4(),
                cliente_id=1,
            )

    # Teste para verificar a adição de um item ao pedido
    def test_adicionar_item(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        item = Mock()
        item.produto_id = uuid4()
        item.quantidade = 2

        pedido.adicionar_item(item)

        # Verifica se o item foi adicionado
        assert len(pedido.itens) == 1
        assert pedido.itens[0] == item

    # Teste para verificar a adição de dois itens diferentes
    def test_adicionar_itens_diferentes(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        item_1 = Mock()
        item_1.produto_id = uuid4()
        item_1.quantidade = 2

        item_2 = Mock()
        item_2.produto_id = uuid4()
        item_2.quantidade = 3

        pedido.adicionar_item(item_1)
        pedido.adicionar_item(item_2)

        # Verifica se os dois itens foram adicionados
        assert len(pedido.itens) == 2

    # Teste para verificar a soma da quantidade de produtos iguais
    def test_adicionar_item_produto_existente(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        produto_id = uuid4()

        item_existente = Mock()
        item_existente.produto_id = produto_id
        item_existente.quantidade = 2

        novo_item = Mock()
        novo_item.produto_id = produto_id
        novo_item.quantidade = 3

        pedido.adicionar_item(item_existente)
        pedido.adicionar_item(novo_item)

        # Verifica se a quantidade foi somada
        assert len(pedido.itens) == 1
        assert pedido.itens[0].quantidade == 5

    # Teste para verificar que não é possível adicionar item
    # em pedido que não está pendente
    def test_adicionar_item_pedido_nao_pendente(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
            status=StatusPedido.PAGO,
        )

        item = Mock()
        item.produto_id = uuid4()
        item.quantidade = 2

        with pytest.raises(
            ValueError,
            match=(
                "Não é possível adicionar itens a um pedido " "que não está pendente."
            ),
        ):
            pedido.adicionar_item(item)

    # Teste para verificar a remoção de um item
    def test_remover_item(self):
        produto_id = uuid4()

        item = Mock()
        item.produto_id = produto_id
        item.quantidade = 2

        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
            itens=[item],
        )

        pedido.remover_item(produto_id)

        # Verifica se o item foi removido
        assert len(pedido.itens) == 0

    # Teste para verificar a remoção de item inexistente
    def test_remover_item_inexistente(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        produto_id = uuid4()

        with pytest.raises(
            ValueError,
            match=(
                f"Item com o produto_id '{produto_id}' " "não encontrado no pedido."
            ),
        ):
            pedido.remover_item(produto_id)

    # Teste para verificar que não é possível remover item
    # de pedido que não está pendente
    def test_remover_item_pedido_nao_pendente(self):
        produto_id = uuid4()

        item = Mock()
        item.produto_id = produto_id
        item.quantidade = 2

        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
            itens=[item],
            status=StatusPedido.PAGO,
        )

        with pytest.raises(
            ValueError,
            match=(
                "Não é possível remover itens de um pedido " "que não está pendente."
            ),
        ):
            pedido.remover_item(produto_id)

    # Teste para verificar o cálculo do total do pedido
    def test_calcular_total(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        item_1 = Mock()
        item_1.calcular_total.return_value = 100.00

        item_2 = Mock()
        item_2.calcular_total.return_value = 50.00

        pedido.itens = [item_1, item_2]

        total = pedido.calcular_total()

        # Verifica se o total foi calculado corretamente
        assert total == 150.00

    # Teste para verificar o cálculo do total de um pedido vazio
    def test_calcular_total_pedido_vazio(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        assert pedido.calcular_total() == 0

    # Teste para verificar o pagamento de um pedido
    def test_pagar_pedido(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        item = Mock()
        item.calcular_total.return_value = 100.00

        pedido.itens.append(item)

        pedido.pagar(100.00)

        # Verifica se o pedido foi marcado como pago
        assert pedido.status == StatusPedido.PAGO

    # Teste para verificar pagamento com valor superior ao total
    def test_pagar_pedido_valor_superior(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        item = Mock()
        item.calcular_total.return_value = 100.00

        pedido.itens.append(item)

        pedido.pagar(150.00)

        assert pedido.status == StatusPedido.PAGO

    # Teste para verificar pagamento de pedido sem itens
    def test_pagar_pedido_sem_itens(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        with pytest.raises(
            ValueError,
            match="Não é possível pagar um pedido que não possui itens.",
        ):
            pedido.pagar(100.00)

    # Teste para verificar pagamento insuficiente
    def test_pagar_pedido_valor_insuficiente(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        item = Mock()
        item.calcular_total.return_value = 100.00

        pedido.itens.append(item)

        with pytest.raises(
            ValueError,
            match=(
                r"Valor pago \(R\$ 50\.00\) é insuficiente\. "
                r"O total do pedido é R\$ 100\.00\."
            ),
        ):
            pedido.pagar(50.00)

    # Teste para verificar pagamento de pedido cancelado
    def test_pagar_pedido_cancelado(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
            status=StatusPedido.CANCELADO,
        )

        item = Mock()
        item.calcular_total.return_value = 100.00

        pedido.itens.append(item)

        with pytest.raises(
            ValueError,
            match="Não é possível pagar um pedido cancelado.",
        ):
            pedido.pagar(100.00)

    # Teste para verificar pagamento de pedido já pago
    def test_pagar_pedido_ja_pago(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
            status=StatusPedido.PAGO,
        )

        item = Mock()
        item.calcular_total.return_value = 100.00

        pedido.itens.append(item)

        with pytest.raises(
            ValueError,
            match="O pedido já está pago.",
        ):
            pedido.pagar(100.00)

    # Teste para verificar o cancelamento de um pedido
    def test_cancelar_pedido(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
        )

        pedido.cancelar()

        # Verifica se o pedido foi cancelado
        assert pedido.status == StatusPedido.CANCELADO

    # Teste para verificar que não é possível cancelar
    # um pedido já pago
    def test_cancelar_pedido_pago(self):
        pedido = Pedido(
            id=uuid4(),
            cliente_id=uuid4(),
            status=StatusPedido.PAGO,
        )

        with pytest.raises(
            ValueError,
            match="Não é possível cancelar um pedido já pago.",
        ):
            pedido.cancelar()
