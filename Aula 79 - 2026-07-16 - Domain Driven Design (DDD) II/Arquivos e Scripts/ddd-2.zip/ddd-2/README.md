# Aula 2 — Modelagem Tática / Implementação (DDD, Caps. 4 a 6)

Exemplos de **Domain-Driven Design** em Python, no formato **sem DDD → com DDD**.

| Projeto | Conceito | Domínio |
|---|---|---|
| **1 — Value Objects** | Fim da obsessão por primitivos (Cap. 6) | Dinheiro, E-mail, CEP, Endereço |
| **2 — Modelo de Domínio** | Modelo anêmico vs. Agregado (Caps. 5–6) | Biblioteca / Empréstimo |
| **3 — Camada Anticorrupção** | Anti-Corruption Layer | Integração com API de banco |

## Pré-requisitos

Apenas **Docker Desktop** instalado e rodando — **não precisa ter Python na máquina**
(tudo roda dentro do container, com Python 3.14). Confira com:

```bash
docker --version
docker compose version
```

## As duas pastas

| Pasta | O que é |
|---|---|
| **`referencial/`** | Versão **completa** — inclui os `com_ddd.py` prontos. É o gabarito de referência. |
| **`aula/`** | Igual à referencial, **mas sem os `com_ddd.py`** — a versão DDD é construída **ao vivo em aula**. Traz `sem_ddd.py`, o sistema legado e os READMEs de roteiro. |

Cada pasta é **autocontida** e usa o **mesmo Docker**. Entre na pasta desejada e siga
os comandos abaixo (ou o README de cada projeto).

## Como rodar

```bash
cd referencial          # ou: cd aula

docker compose build    # só na primeira vez
```

> Cada projeto tem seu próprio `README.md` com os detalhes, a saída esperada e as
> perguntas para discussão em sala.
