"""
COM DDD — Camada Anticorrupção (Anti-Corruption Layer).

A API do banco (sistema_legado.py) responde a transação num formato bagunçado:
{"vlr": 100, "dt": "2025-08-10"} — chaves abreviadas e a data como string.
A classe BankACL é a fronteira que CONSOME a API e TRADUZ esse formato para o
nosso domínio limpo (BankTransaction). É o único lugar que conhece a API — o
resto do sistema só enxerga BankTransaction.

Rode com (a API precisa estar no ar):
    docker compose up -d banco-api
    docker compose run --rm aula2 python projeto-3-anticorrupcao/com_ddd.py
"""

from __future__ import annotations

import json
import os
import urllib.request
from datetime import date
from decimal import Decimal

API_URL = os.environ.get("BANCO_API_URL", "http://localhost:8000")


# --- nosso domínio limpo (não sabe que a API existe) ---
class BankTransaction:
    def __init__(self, amount: Decimal, date: date) -> None:
        self.amount = amount
        self.date = date


# --- camada anticorrupção: consome a API e traduz para o domínio ---
class BankACL:
    def __init__(self, base_url: str) -> None:
        self._base_url = base_url

    def buscar_transacao(self) -> BankTransaction:
        # chama a API do banco e lê o JSON cru
        with urllib.request.urlopen(f"{self._base_url}/transacao") as resposta:
            bruto = json.load(resposta)
        # aqui — e só aqui — mora o conhecimento do formato da API
        return BankTransaction(
            amount=Decimal(bruto["vlr"]),
            date=date.fromisoformat(bruto["dt"]),
        )


def main() -> None:
    banco = BankACL(API_URL)   # a fronteira

    transacao = banco.buscar_transacao()
    print("amount:", transacao.amount)
    print("date:", transacao.date)
    print("amount é Decimal?", isinstance(transacao.amount, Decimal))
    print("date é date?", isinstance(transacao.date, date))


if __name__ == "__main__":
    main()
