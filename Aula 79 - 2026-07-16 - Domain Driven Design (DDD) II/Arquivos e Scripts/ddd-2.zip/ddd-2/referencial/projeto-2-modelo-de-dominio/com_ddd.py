"""
COM DDD — Agregado / Domain Model.

A Biblioteca é a RAIZ DO AGREGADO e protege as próprias regras:
- no máximo 5 livros no acervo;
- um livro indisponível não pode ser emprestado;
- a devolução com atraso calcula a multa.

Rode com:  python com_ddd.py
"""

MAX_LIVROS = 5
MULTA_POR_DIA = 2   # R$ por dia de atraso


class Livro:
    def __init__(self, titulo):
        self.titulo = titulo
        self.disponivel = True


class Biblioteca:
    def __init__(self):
        self.livros = []

    def adicionar_livro(self, titulo):
        # REGRA: no máximo 5 livros
        if len(self.livros) >= MAX_LIVROS:
            raise ValueError(f"A biblioteca só comporta {MAX_LIVROS} livros.")
        self.livros.append(Livro(titulo))

    def emprestar(self, livro):
        # REGRA: livro indisponível não pode ser emprestado
        if not livro.disponivel:
            raise ValueError(f"O livro {livro.titulo!r} está indisponível.")
        livro.disponivel = False

    def devolver(self, livro, dias_atraso=0):
        # REGRA: devolução com atraso calcula a multa
        livro.disponivel = True
        return dias_atraso * MULTA_POR_DIA


def main():
    biblioteca = Biblioteca()
    for i in range(1, 6):
        biblioteca.adicionar_livro(f"Livro {i}")
    print("Livros no acervo:", len(biblioteca.livros))

    # não passa de 5
    try:
        biblioteca.adicionar_livro("Livro 6")
    except ValueError as e:
        print("Regra protegeu:", e)

    # indisponível não empresta
    livro = biblioteca.livros[0]
    biblioteca.emprestar(livro)
    try:
        biblioteca.emprestar(livro)
    except ValueError as e:
        print("Regra protegeu:", e)

    # multa por atraso na devolução
    multa = biblioteca.devolver(livro, dias_atraso=3)
    print("Multa por 3 dias de atraso: R$", multa)


if __name__ == "__main__":
    main()
