"""
COM DDD — Value Objects (Capítulo 6).

Cada conceito do domínio vira um Value Object:

- Email: só existe se for válido (valida no nascimento).
- Cep: idem.
- Endereco: composto por outros value objects.

Características de um Value Object (texto-base, Cap. 6):
- IMUTÁVEL (frozen=True): mudar um campo cria um NOVO valor.
- Igualdade POR VALOR: dois Cep de "13400000" são iguais.
- A validação mora DENTRO do objeto: é impossível criar um inválido.

Rode com:  python com_ddd.py
"""

from __future__ import annotations

from dataclasses import dataclass
from email_validator import EmailNotValidError, validate_email


@dataclass()
class Email:
    valor: str

    def __post_init__(self) -> None:
        try:
            validate_email(self.valor, check_deliverability=False)
        except EmailNotValidError as erro:
            raise ValueError(f"E-mail inválido: {self.valor!r}") from erro


@dataclass()
class Cep:
    valor: str

    def __post_init__(self) -> None:
        somente_digitos = self.valor.replace("-", "")
        if len(somente_digitos) != 8:
            raise ValueError(f"CEP inválido: {self.valor!r}")
        if not somente_digitos.isdigit():
            raise ValueError(f"CEP inválido: {self.valor!r}")

    def formatado(self) -> str:
        d = self.valor.replace("-", "")
        return f"{d[:5]}-{d[5:]}"


@dataclass()
class Endereco:
    logradouro: str
    numero: str
    cep: Cep


def main() -> None:
    # 1) E-mail inválido NÃO entra no sistema
    try:
        Email("fulano.email")
    except ValueError as e:
        print("Bloqueado na origem:", e)

    email_ok = Email("seunome@email.com")
    print("E-mail válido criado:", email_ok.valor)

    # 2) CEP inválido também é barrado; o válido se formata sozinho
    print()
    try:
        Cep("1234")
    except ValueError as e:
        print("Bloqueado na origem:", e)

    endereco = Endereco("Rua DDD", "100", Cep("13400000"))
    print("Endereço:", endereco.logradouro, endereco.numero, "-", endereco.cep.formatado())

    # 3) Igualdade por valor
    print()
    print("Dois Cep de '13400000' são iguais?", Cep("13400000") == Cep("13400000"))


if __name__ == "__main__":
    main()
