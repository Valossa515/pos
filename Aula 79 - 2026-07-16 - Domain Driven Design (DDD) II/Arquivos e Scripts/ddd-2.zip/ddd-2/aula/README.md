# Aula 2 — Modelagem Tática / Implementação (Caps. 4 a 6) — Execução via Docker

> **Não é preciso ter Python instalado na sua máquina.** Tudo roda dentro do
> Docker, com **Python 3.14**.

## Pré-requisito único

- **Docker Desktop** instalado e em execução. Confira com:
  ```bash
  docker --version
  docker compose version
  ```

## Passo a passo

### 1. Entre na pasta da Aula 2
```bash
cd aula-2
```

### 2. Construa a imagem (apenas na primeira vez)
```bash
docker compose build
```
Isso baixa o Python 3.14 e monta a imagem `ddd-aula-2` com o código dos projetos.

### 3. Rode cada exemplo (Python 3.14 dentro do container)

**Projeto 1 — Value Objects:**
```bash
docker compose run --rm aula2 python projeto-1-value-objects/sem_ddd.py
docker compose run --rm aula2 python projeto-1-value-objects/com_ddd.py
```

**Projeto 2 — Modelo Anêmico vs. Agregado:**
```bash
docker compose run --rm aula2 python projeto-2-modelo-de-dominio/sem_ddd.py
docker compose run --rm aula2 python projeto-2-modelo-de-dominio/com_ddd.py
```

**Projeto 3 — Camada Anticorrupção (a API do banco sobe no Docker):**
```bash
docker compose up -d banco-api          # sobe a API do banco (fica no ar)
docker compose run --rm aula2 python projeto-3-anticorrupcao/com_ddd.py
docker compose down                     # encerra a API ao terminar
```

### 4. (Opcional) Abra um shell interativo dentro do container
```bash
docker compose run --rm aula2
```
Lá dentro você está em Python 3.14. Verifique e rode o que quiser:
```bash
python --version          # Python 3.14.x
python projeto-2-modelo-de-dominio/com_ddd.py
exit                      # sai do container
```

## Observações

- A flag `--rm` remove o container ao terminar (não deixa lixo).
- A pasta `aula-2` é **montada** no container (`volumes`), então qualquer
  edição que você fizer nos arquivos `.py` no seu computador vale na hora,
  sem reconstruir a imagem.
- Só é preciso refazer `docker compose build` se você mudar o `Dockerfile`.
