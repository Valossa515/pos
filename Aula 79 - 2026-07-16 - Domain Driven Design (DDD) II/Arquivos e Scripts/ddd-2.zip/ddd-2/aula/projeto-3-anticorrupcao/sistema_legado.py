"""
SISTEMA LEGADO — NÃO ALTERE!.

API HTTP de um banco (terceiro). Sobe junto com o Docker e responde uma
transação num formato bagunçado: chaves abreviadas ("vlr", "dt") e a data
como string. Não controlamos esse formato — por isso o com_ddd.py cria uma
CAMADA ANTICORRUPÇÃO que consome esta API e traduz para o nosso modelo.

Sobe sozinha via `docker compose up banco-api`. Para rodar na mão:
    python sistema_legado.py     # escuta em http://0.0.0.0:8000
"""

import json
from http.server import BaseHTTPRequestHandler, HTTPServer


class BancoHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        # resposta crua da API do banco, no formato dela
        corpo = json.dumps({"vlr": 100, "dt": "2025-08-10"}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(corpo)

    def log_message(self, *args):
        pass  # silencia o log padrão (evita flood do healthcheck)


if __name__ == "__main__":
    servidor = HTTPServer(("0.0.0.0", 8000), BancoHandler)
    print("API do banco ouvindo em http://0.0.0.0:8000 ...", flush=True)
    servidor.serve_forever()
