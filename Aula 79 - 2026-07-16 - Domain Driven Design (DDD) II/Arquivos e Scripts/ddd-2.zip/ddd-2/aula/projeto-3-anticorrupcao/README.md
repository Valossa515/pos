# Aula 2 — Projeto 3: Camada Anticorrupção

> **Conceito de DDD:** Anti-Corruption Layer (camada anticorrupção)
> **Domínio:** Integração com a API de um banco (terceiro)

## O que este projeto mostra

Quase todo sistema precisa conversar com algo que **não controlamos**: a API de
um banco, uma biblioteca antiga, um sistema de terceiros. Esse "outro lado"
costuma falar num modelo bagunçado. Se o nosso domínio conversar direto com
ele, esse jeito feio **vaza** e "corrompe" o nosso código.

A **camada anticorrupção** é uma fronteira fina que fica no meio: é o único
lugar que conhece o formato do legado. Ela conecta, conversa e **traduz** o
modelo estranho para o nosso domínio limpo.

| Arquivo | O que demonstra |
|---|---|
| `sistema_legado.py` | A **API HTTP** do banco que **não pode ser alterada**. Sobe junto com o Docker e responde `{"vlr": 100, "dt": "2025-08-10"}` — chaves abreviadas e data como string. |
| `com_ddd.py` | Nosso domínio limpo (`BankTransaction`) + a classe `BankACL`, a camada anticorrupção que **consome a API** (via HTTP) e traduz para o domínio. |

Só a biblioteca padrão: a API usa `http.server` e o cliente usa `urllib` —
nenhuma dependência extra.

O que a `BankACL` traduz na fronteira:

| API do banco (formato feio) | Domínio (`BankTransaction`) |
|---|---|
| `"vlr": 100` | `amount = Decimal("100")` |
| `"dt": "2025-08-10"` | `date = date(2025, 8, 10)` |

O resto do sistema **nunca vê** `"vlr"` nem a data como string: só enxerga
`BankTransaction`, com `amount` (`Decimal`) e `date` (`date`).

## Pré-requisitos

- **Docker Desktop** instalado e em execução (`docker --version`). Não é
  necessário ter Python na máquina — ele roda dentro do container (Python 3.14).
  Passo a passo completo do Docker em [../README.md](../README.md).

## Como executar (via Docker, Python 3.14)

### 1. Construa a imagem (uma vez)
```bash
docker compose build
```

### 2. Suba a API do banco (fica no ar)
```bash
docker compose up -d banco-api
```
Isso inicia o sistema legado como uma API HTTP em `http://localhost:8000`.

### 3. Rode o cliente COM DDD (consome a API e traduz)
```bash
docker compose run --rm aula2 python projeto-3-anticorrupcao/com_ddd.py
```
O `com_ddd.py` faz uma chamada HTTP à API e recebe de volta um objeto de
**domínio limpo** — `amount` como `Decimal` e `date` como `date`. O formato da
API (chaves abreviadas, data em string) ficou preso na fronteira. Saída
esperada:
```
BankTransaction: BankTransaction(amount=Decimal('100'), date=datetime.date(2025, 8, 10))
amount é Decimal? True
date é date? True
```

### 4. Encerre a API ao terminar
```bash
docker compose down
```

## Para discutir em sala

1. Por que é melhor ter **um único lugar** que conhece o formato da API?
2. O que acontece quando o banco renomeia `"vlr"` ou muda o formato da data —
   quantos arquivos você toca?
3. Por que o domínio (`BankTransaction`) **não deve** conhecer as chaves
   `"vlr"` / `"dt"` da API?

## Ligação com o texto-base

- A camada anticorrupção protege o **modelo de domínio** de conceitos externos,
  traduzindo entre dois modelos que não deveriam se contaminar.
