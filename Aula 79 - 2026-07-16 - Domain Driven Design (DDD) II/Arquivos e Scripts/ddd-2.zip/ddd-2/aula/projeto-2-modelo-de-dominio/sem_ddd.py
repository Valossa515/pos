"""
SEM DDD — Modelo de domínio ANÊMICO.

A Biblioteca é só um saco de dados (listas públicas, sem comportamento). As
regras moram FORA, num BibliotecaService que nada obriga a usar. Resultado:
qualquer código fura as regras — passa de 5 livros, empresta um livro
indisponível, esquece de aplicar a multa.

Rode com:  python sem_ddd.py
"""


class Biblioteca:
    def __init__(self):
        self.livros = []   # lista aberta de dicts, sem proteção


class BibliotecaService:
    # As "regras" ficam aqui fora, e nada obriga a passar por elas.
    def adicionar_livro(self, biblioteca, titulo):
        biblioteca.livros.append({"titulo": titulo, "disponivel": True})

    def emprestar(self, biblioteca, titulo):
        for livro in biblioteca.livros:
            if livro["titulo"] == titulo:
                livro["disponivel"] = False   # nem checa se estava disponível

    def multa(self, dias_atraso):
        return dias_atraso * 2


def main():
    service = BibliotecaService()
    biblioteca = Biblioteca()
    for i in range(1, 6):
        service.adicionar_livro(biblioteca, f"Livro {i}")

    # PROBLEMA 1: nada impede passar de 5 livros (basta um append)
    biblioteca.livros.append({"titulo": "Livro 6", "disponivel": True})
    print("Total de livros:", len(biblioteca.livros), "-> deveria ser no máximo 5!")

    # PROBLEMA 2: emprestar um livro já indisponível
    service.emprestar(biblioteca, "Livro 1")
    service.emprestar(biblioteca, "Livro 1")   # de novo, sem bloqueio
    print("Livro 1 foi emprestado duas vezes sem impedimento.")

    # PROBLEMA 3: multa é uma conta solta que ninguém garante chamar
    print("Multa por 3 dias:", service.multa(3), "(mas dá pra esquecer de aplicar)")


if __name__ == "__main__":
    main()
