# Aula 2 — Projeto 2: Modelo Anêmico vs. Agregado (Domain Model)

> **Conceito de DDD:** Domain Model e Agregado como fronteira de consistência (Capítulos 5 e 6)
> **Domínio:** Biblioteca / Empréstimo de livros

## O que este projeto mostra

Quando há regras de negócio (invariantes), o **modelo anêmico** (dados sem
comportamento + um *service* por fora) deixa o estado corromper. O padrão
**Agregado** resolve.

As regras da Biblioteca:
1. No máximo **5 livros** no acervo.
2. Um livro **indisponível não pode ser emprestado**.
3. Devolução com atraso gera **multa**.

| Arquivo | O que demonstra |
|---|---|
| `sem_ddd.py` | `Biblioteca` **anêmica**: listas públicas e um `BibliotecaService` externo. Dá pra passar de 5 livros, emprestar um livro já emprestado e esquecer de aplicar a multa. |
| `com_ddd.py` | `Biblioteca` como **raiz de agregado**: o estado só muda por métodos (`adicionar_livro`, `emprestar`, `devolver`), que **impõem as três regras**. De fora só se lê. |

Ideia central (Cap. 6): **o agregado é a fronteira de imposição de
consistência**. De fora só se **lê**; mutar, só pela interface pública, que
valida todas as regras.

## Pré-requisitos

- **Docker Desktop** instalado e em execução (`docker --version`). Não é
  necessário ter Python na máquina — ele roda dentro do container (Python 3.14).
  Passo a passo completo do Docker em [../README.md](../README.md).

## Como executar (via Docker, Python 3.14)

### 1. Construa a imagem (uma vez)
```bash
docker compose build
```

### 2. Rode a versão SEM DDD
```bash
docker compose run --rm aula2 python projeto-2-modelo-de-dominio/sem_ddd.py
```
Observe as regras sendo furadas: o acervo chega a **6 livros**, o mesmo livro é
emprestado **duas vezes**, e a multa é uma conta solta que ninguém garante aplicar.

### 3. Rode a versão COM DDD
```bash
docker compose run --rm aula2 python projeto-2-modelo-de-dominio/com_ddd.py
```
Agora as mesmas tentativas inválidas são **barradas pelas invariantes**: o 6º
livro é recusado, emprestar um livro indisponível dá erro, e a multa é
calculada dentro do próprio domínio, na devolução.

## Para discutir em sala

1. O que é uma **invariante**? Liste as três protegidas pela `Biblioteca`.
2. Por que deixar as listas **públicas** (modelo anêmico) facilita a corrupção do estado?
3. Quando o modelo **anêmico** (Cap. 5 — Active Record / Transaction Script) é uma escolha **legítima**? (Dica: subdomínios de suporte, lógica simples.)

## Ligação com o texto-base

- Cap. 5 — Transaction Script e Active Record ("modelo de domínio anêmico"): bons para lógica simples, ruins para subdomínios core.
- Cap. 6 — Domain Model: "coloca a lógica de negócio em primeiro lugar".
- Cap. 6 — Agregado: "o agregado é um limite de imposição de consistência"; só a lógica do agregado modifica seu estado.
