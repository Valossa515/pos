"""
SEM DDD — Obsessão por primitivos

Conceitos do domínio (e-mail, CEP) são representados por tipos
primitivos: str. Consequências:

1. Validação de e-mail/CEP espalhada e fácil de esquecer de chamar.
2. Nada impede valores inválidos de entrarem no sistema.

Rode com:  python sem_ddd.py
"""


def valida_email(texto):
    # validação solta; quem garante que será chamada antes de usar?
    if "@" not in texto:
        return False
    if "." not in texto:
        return False
    return True


def valida_cep(texto):
    if len(texto) != 8:
        return False
    if not texto.isdigit():
        return False
    return True


def main():
    # 1) E-mail inválido entra no sistema porque ninguém validou aqui
    cliente_email = "fulano(arroba)email"  # inválido
    print("Cadastrando cliente com e-mail:", cliente_email)
    print("Salvo no banco mesmo sendo inválido (esqueceram de validar).")

    # 2) CEP inválido também passa
    cep = "1234"  # curto demais
    print("\nCEP informado:", cep, "-> valido?", valida_cep(cep))
    print("Mas nada impede de usar esse CEP mesmo assim.")


if __name__ == "__main__":
    main()
