# Aula 2 — Projeto 1: Value Objects

> **Conceito de DDD:** Value Object e fim da "obsessão por primitivos" (Capítulo 6)
> **Domínio:** E-commerce / Dinheiro, E-mail, CEP, Endereço

## O que este projeto mostra

Representar conceitos do domínio com tipos primitivos (`float`, `str`) é o *code smell* chamado **obsessão por primitivos**. Value Objects resolvem isso.

| Arquivo | O que demonstra |
|---|---|
| `sem_ddd.py` | Dinheiro como `float` (erro de centavos), e-mail/CEP como `str` com validação solta e esquecível. Valores inválidos entram no sistema. |
| `com_ddd.py` | Value Objects imutáveis: `Dinheiro` (centavos em `int`), `Email`, `Cep`, `Endereco`. Validação no nascimento, igualdade por valor, comportamento encapsulado. |

Três propriedades de um Value Object (Cap. 6):
1. **Imutável** — alterar um campo cria um *novo* valor.
2. **Igualdade por valor** — dois `Dinheiro` de R$ 10,00 são iguais.
3. **Validação interna** — é **impossível** criar um value object inválido.

## Pré-requisitos

- **Docker Desktop** instalado e em execução (`docker --version`). Não é
  necessário ter Python na máquina — ele roda dentro do container (Python 3.14).
  Passo a passo completo do Docker em [../README.md](../README.md).

## Como executar (via Docker, Python 3.14)

### 1. Entre na pasta da aula e construa a imagem (uma vez)
```bash
cd aula-2
docker compose build
```

### 2. Rode a versão SEM DDD
```bash
docker compose run --rm aula2 python projeto-1-value-objects/sem_ddd.py
```
Veja o clássico bug do dinheiro como float:
```
Total (float): 0.30000000000000004
É igual a 0.30? False
```
E note que um e-mail e um CEP **inválidos** entram no sistema sem resistência.

### 3. Rode a versão COM DDD
```bash
docker compose run --rm aula2 python projeto-1-value-objects/com_ddd.py
```
Agora `Dinheiro` soma centavos exatos, e `Email("fulano(arroba)email")` **nem chega a existir** — é bloqueado na origem.

## Para discutir em sala

1. Por que guardar dinheiro em **centavos (int)** em vez de reais (float)?
2. O que significa "validar no nascimento"? Que classe de bug isso elimina de uma vez?
3. Por que a **imutabilidade** torna o código mais seguro (efeitos colaterais, threads)?

## Ligação com o texto-base

- Cap. 6 — "obsessão primitiva" e o exemplo da classe `Person` antes/depois.
- Cap. 6 — "Uma oportunidade especialmente importante para introduzir um objeto de valor é ao modelar **dinheiro**."
- Cap. 6 — Value Objects são imutáveis e comparados por valor.
