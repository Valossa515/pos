# 🏪 ETL na Prática — Omnichannel de Tênis

## Cenário

A **TênisDireto**, um e-commerce nativo digital de tênis, acabou de comprar a **Rede PéFirme**, uma rede de lojas físicas com 8 unidades pelo Brasil.

O desafio: **implementar omnichannel** para que um pedido feito no site possa ser atendido pela loja física mais próxima com estoque disponível.

## O Problema de Dados

| Aspecto | TênisDireto (Digital) | Rede PéFirme (Física) |
|---|---|---|
| **Formato** | JSON | CSV (separador `;`, encoding `latin-1`) |
| **Qualidade** | Limpo, padronizado | Sujo: espaços, formatos mistos, duplicatas |
| **Identificador** | SKU slug (`nike-air-max-90-branco-42`) | Código EAN-13 (com falhas) |
| **Idioma/Padrão** | Nomes padronizados | Caixa alta, abreviações |

## Estrutura do Projeto

```
├── README.md                    ← Você está aqui
├── gerar_dados.py               ← Script que gera os dados simulados
├── dados/
│   ├── ecommerce/               ← Dados da TênisDireto (JSON)
│   │   ├── catalogo_digital.json
│   │   ├── clientes.json
│   │   └── pedidos.json
│   └── lojas_fisicas/           ← Dados da Rede PéFirme (CSV sujo)
│       ├── cadastro_lojas.csv
│       └── estoque_lojas.csv
├── notebooks/
│   ├── 01_exploracao_dados.ipynb
│   ├── 02_extracao.ipynb
│   ├── 03_transformacao.ipynb
│   ├── 04_carga.ipynb
│   └── 05_consulta_omnichannel.ipynb
```

## Como Usar

### Usando Docker (Recomendado)

A maneira mais fácil de rodar o projeto com todas as dependências corretas (Java, PySpark e Jupyter) é utilizando Docker e Docker Compose:

1. Inicie o ambiente (isso pode demorar na primeira vez para baixar as imagens e dependências):
```bash
docker compose up --build
```

2. Acesse o Jupyter Lab no seu navegador clicando ou acessando o link abaixo:
**[http://localhost:8888/](http://localhost:8888/)**

*(Para desligar o contêiner, use `Ctrl+C` no terminal ou rode `docker compose down`)*

## Etapas do ETL

1. **Exploração** — Entender os dados brutos antes de qualquer transformação
2. **Extração** — Ler múltiplas fontes (JSON + CSV) com PySpark
3. **Transformação** — Limpar, padronizar e unificar os dados
4. **Carga** — Salvar o resultado processado em formato otimizado
5. **Consulta** — Responder: "Qual loja mais próxima tem estoque para este pedido?"
